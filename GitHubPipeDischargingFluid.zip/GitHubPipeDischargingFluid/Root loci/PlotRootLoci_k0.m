clc
clear all
close all

fontsize = 15;
fontsizetitle = 15;
fontsizeticks = 12;
markersize = 2;


RealandImaginaryParts_matrixread = 'Export\RealandImaginaryParts_matrix_k0_beta01_xibart05.csv';
RealandImaginaryParts_matrix = dlmread(RealandImaginaryParts_matrixread);%creates a matrix out of the data
uvector = 0.001:0.001:30;

close all
fig = figure(); % Imaginary on the x-axis and real on the y-axis
fig.Renderer='Painters';
c = uvector;
colormap('jet');
contufinal = 10000;
for contcoord = 1:length(RealandImaginaryParts_matrix(1,:))/2
    scatter(RealandImaginaryParts_matrix(1:contufinal,contcoord+length(RealandImaginaryParts_matrix(1,:))/2),RealandImaginaryParts_matrix(1:contufinal,contcoord),markersize,c(1:contufinal),'filled')
    hold on
end
grid on;
ylim([-30 7]);
xlim([0 80]);
c = colorbar;
t=ylabel(c,'$u$','rotation',0,'interpreter','latex','FontSize',20);
t.Position(1) = t.Position(1) + 0.5;
t.Position(2) = t.Position(2) + 0.5;
caxis([uvector(1) uvector(contufinal)]);

set(gca,'fontsize',fontsizeticks);

title(['$\kappa^{}_{0} = 4\pi/5$; $\beta = 0.5$'],'interpreter','latex','Fontsize',fontsizetitle);
xlabel('$\Im(\lambda)$','interpreter','latex','FontSize',fontsize); 
ylab = ylabel('$\Re(\lambda)$','interpreter','latex','FontSize',fontsize,'rotation',0); 
ylab.Position(1) = ylab.Position(1) - 5;
ylab.Position(2) = ylab.Position(2) - 1;
set(0,'DefaultAxesTitleFontWeight','normal');

%h = legend('$N_{t}^{} = 2$','$N_{t}^{} = 3$','$N_{t}^{} = 4$','$N_{t}^{} = 5$','$N_{t}^{} = 6$','$N_{t}^{} = 7$','$N_{t}^{} = 8$','Location','northwest');

%set(h,'interpreter','latex')
%set(h,'Fontsize',fontsizeticks)

print('Export\133RL1',fig,'-dpdf')

%%
% format long g
% for cont = 1:length(RealandImaginaryParts_matrix(:,1))
%     if max(RealandImaginaryParts_matrix(cont,1:length(RealandImaginaryParts_matrix(1,:))/2)) < 10^-6
%         u = uvector(cont)
%         RealandImaginaryParts_matrix(cont,1:length(RealandImaginaryParts_matrix(1,:))/2)
%         max(RealandImaginaryParts_matrix(cont,1:length(RealandImaginaryParts_matrix(1,:))/2))
%         finalvalue = cont
%         break
%     end
% end
% 
% for cont = finalvalue:length(RealandImaginaryParts_matrix(:,1))
%     if max(RealandImaginaryParts_matrix(cont,1:length(RealandImaginaryParts_matrix(1,:))/2)) > 10^-6
%         u = uvector(cont)
%         RealandImaginaryParts_matrix(cont,1:length(RealandImaginaryParts_matrix(1,:))/2)
%         max(RealandImaginaryParts_matrix(cont,1:length(RealandImaginaryParts_matrix(1,:))/2))
%         finalvalue2 = cont
%         break
%     end
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% PIPE DISCHARGING FLUID - ROOT-LOCI CURVES %%%%%%%%%%%%%%%%%
clear all
close all
clc
%% DIMENSIONLESS PARAMETERS
% Dimensionless arclength coordinate
resolution = 2001; % Discretization of the longitudinal axis
shat = linspace(0,1,resolution); % Longitudinal axis
% Relevant dimensionless parameters for the STATIC solutions

u = 0;
gamma = 0; % = (m + M)gL^3/(EIy)
% k0 = 4*pi/5; % = MtL/(GIp)
k1 = 2; % = EIp/(EIy)
k2 = 10000; % = EAL^2/(EIy)
k3 = 0.7; % = GIp/(EIy)
k4 = 0.001; % = EI4/(EIyL^2)
mnhat = 0; % = mn/(m + M)L
xibar = 0.5; % = xbar/L
Chatstheta = 1000; % = (Csx L)/(EIy)
% Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
UseSupportSprings = 0;

% Relevant dimensionless parameters only for the DYNAMIC solutions
beta = 0.1;
Chatsy = 1000; % = (Csy L)/(EIy)
Chatsz = 1000; % = (Csz L)/(EIy)
k5 = 0.001; % = Jp/((m + M)L^2)
Ihat = 1; % = Iz/Iy
chatx = 0.0; % = (cx L^2)/sqrt(EIy(m + M))
chaty = 0.0; % = (cy L^2)/sqrt(EIy(m + M))
chatz = 0.0; % = (cz L^2)/sqrt(EIy(m + M))
chattheta = 0.0; % = ctheta/sqrt(EIy(m + M))
% Numerical integration parameters, number of shape functions and IC
% Number of shape functions
Na = 3; % Number of axial modal shapes
Nr = 4; % Number of torsional modal shapes
Nt = 8; % Number of transverse modal shapes
%% LOADING OF THE PRE-EVALUATED STATIC SOLUTIONS COEFFICIENTS
% CHANGE THE CORRESPONDENT NUMBERS!!!!!!!!!!!!
StaticSolutions_Coefficients_matrixread = 'library\StaticSolutions_Coefficients_matrix_k0.csv';
StaticSolutions_Coefficients_matrix = dlmread(StaticSolutions_Coefficients_matrixread);%creates a matrix out of the data
% Construction of the polynomial modal shapes for the static solutions reconstruction
Nas = 4; % Has to be because the static solutions are already evaluated
Nrs = 4; % Has to be because the static solutions are already evaluated
k0 = 1; % JUST TO GET THE CORRECT SHAPE FUNCTIONS
[numberofdomains,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMS_2_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMSD2_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,RMSD2_2_matrix_polynomial,shat1,shat2] = StaticSolutions_Axial_And_Rotational_Polynomial_Shapes(UseSupportSprings,Nas,Nrs,shat,mnhat,k0,xibar);
%% EIGENVALUES EVALUATION
[AMS_matrix,AMS_frequency_vector,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMS_frequency_vector,RMSD1_matrix,RMSD2_matrix,TMS_matrix,TMS_frequency_vector,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix] = DynamicalSolutions_Modal_Shapes(UseSupportSprings,Na,Nr,Nt,shat,k2,k3,k5);
k0vector = linspace(0,3*pi,30000);
RealandImaginaryParts_matrix = zeros(length(k0vector),4*(Na + 2*Nt + Nr)); %[Re(lambda),Im(lambda)]
%%
for k0cont = 1:length(k0vector)
    k0cont
    k0 = k0vector(k0cont);
    [Vector_real_parts,Vector_imaginary_parts] = RealandImaginaryParts(k0,beta,u,k0cont,StaticSolutions_Coefficients_matrix,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,numberofdomains,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2);
    RealandImaginaryParts_matrix(k0cont,1:2*(Na + 2*Nt + Nr)) = Vector_real_parts;
    RealandImaginaryParts_matrix(k0cont,2*(Na + 2*Nt + Nr)+1:(4*(Na + 2*Nt + Nr))) = Vector_imaginary_parts;
end
%% PLOT K0 = 0
close all
fig = figure(); % Imaginary on the x-axis and real on the y-axis
c = k0vector/pi;
colormap('jet');
contk0final = 30000;
for contcoord = 1:2*(Na + 2*Nt + Nr)
    scatter(RealandImaginaryParts_matrix(1:contk0final,contcoord+2*(Na + 2*Nt + Nr)),RealandImaginaryParts_matrix(1:contk0final,contcoord),10,c(1:contk0final),'filled')
    hold on
end
grid on;
% Dimensionless frequency values at u = 0
markersize = 100;
scatter(AMS_frequency_vector.*(2*pi),zeros(length(AMS_frequency_vector),1),markersize,'g','filled')
hold on
scatter(-AMS_frequency_vector.*(2*pi),zeros(length(AMS_frequency_vector),1),markersize,'g','filled')
hold on
scatter(RMS_frequency_vector.*(2*pi),zeros(length(RMS_frequency_vector),1),markersize,'b','filled')
hold on
scatter(-RMS_frequency_vector.*(2*pi),zeros(length(RMS_frequency_vector),1),markersize,'b','filled')
hold on
scatter(TMS_frequency_vector.*(2*pi),zeros(length(TMS_frequency_vector),1),markersize,'r','filled')
hold on
scatter(-TMS_frequency_vector.*(2*pi),zeros(length(TMS_frequency_vector),1),markersize,'r','filled')

ylim([min(min(RealandImaginaryParts_matrix(1:contk0final,1:2*(Na + 2*Nt + Nr)))) max(max(RealandImaginaryParts_matrix(1:contk0final,1:2*(Na + 2*Nt + Nr))))]);

c = colorbar;
t=ylabel(c,'$\kappa^{}_{0} \slash \pi$','rotation',0,'interpreter','latex','FontSize',20);
caxis([k0vector(1)/pi k0vector(contk0final)/pi]);

%CHANGE THE CORRESPONDENT NUMBERS!!!!!!!!!!!!
%dlmwrite('Export\RealandImaginaryParts_matrix_k0_beta01_xibart05.csv',RealandImaginaryParts_matrix,'delimiter',',','precision',16)
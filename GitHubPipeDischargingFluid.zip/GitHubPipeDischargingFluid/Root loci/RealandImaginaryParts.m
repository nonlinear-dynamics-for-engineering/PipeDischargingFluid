function [Vector_real_parts,Vector_imaginary_parts] = RealandImaginaryParts(k0,beta,u,contu,StaticSolutions_Coefficients_matrix,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,numberofdomains,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2)
[xisD1,xisD2,thetaxs,thetaxsD1] = RootLoci_AssembleStaticSolutions(StaticSolutions_Coefficients_matrix,contu,numberofdomains,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2,shat);
[V1,V2,V3,V4,V12,V13,V14,V15,V29,V30,V31,V32,V49,V50,V51,V52] = DynamicalSolutions_Galerkin_Matrices_Evaluation(numberofdomains,UseSupportSprings,Na,Nr,Nt,shat,k0,k1,k2,k3,k4,u,mnhat,xibar,Chatstheta,beta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,xisD1,xisD2,thetaxs,thetaxsD1,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix);
[Mlin,Clin,Klin] = DynamicalSolutions_MlinClinKlinS0_Assembly(Na,Nt,Nr,V1,V12,V29,V49,V2,V13,V30,V50,V3,V4,V14,V15,V32,V31,V52,V51);
M_Inv = inv(Mlin);
C = Clin;
K = Klin;

A = [zeros((Na + 2*Nt + Nr),(Na + 2*Nt + Nr)) eye((Na + 2*Nt + Nr),(Na + 2*Nt + Nr));-M_Inv*K -M_Inv*C]; 
Eigenvalues = eig(A);
Vector_real_parts = real(Eigenvalues);
Vector_imaginary_parts = imag(Eigenvalues);
end
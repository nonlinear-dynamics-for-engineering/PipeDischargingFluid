function [xisD1,xisD2,thetaxs,thetaxsD1] = RootLoci_AssembleStaticSolutions(StaticSolutions_Coefficients_matrix,contu,numberofdomains,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2,shat)
    Nas = length(AMS_1_matrix_polynomial(:,1)); %first one is always there
    Nrs = length(RMS_1_matrix_polynomial(:,1)); %first one is always there
    Coefficientlist = StaticSolutions_Coefficients_matrix(contu,1:end-1); %Excluding the u column
    Coefficientlist = Coefficientlist'; %Back to column vector
    if numberofdomains == 1
        %% ONE DOMAIN
        %Reconstruction of the displacements fields then assembly into one vector
        thetaxs_1 = (Coefficientlist((Nas+1):(Nas+Nrs))'*RMS_1_matrix_polynomial)';
        thetaxs_1 = thetaxs_1';
        thetaxs = thetaxs_1;
        %First and second derivatives then assembly into one vector
        xisD1_1 = (Coefficientlist(1:Nas)'*AMSD1_1_matrix_polynomial)';
        xisD1_1 = xisD1_1';
        xisD1 = xisD1_1;
        
        thetaxsD1_1 = (Coefficientlist((Nas+1):(Nas+Nrs))'*RMSD1_1_matrix_polynomial)';
        thetaxsD1_1 = thetaxsD1_1';
        thetaxsD1 = thetaxsD1_1;
        
        xisD2_1 = (Coefficientlist(1:Nas)'*AMSD2_1_matrix_polynomial)';
        xisD2_1 = xisD2_1';
        xisD2(1:length(shat1)) = xisD2_1;
    elseif numberofdomains == 2
        %% TWO DOMAINS
        %Initializing the final vectors
        xisD1 = zeros(1,length(shat));
        xisD2 = zeros(1,length(shat));
        thetaxs = zeros(1,length(shat));
        thetaxsD1 = zeros(1,length(shat));
        %Reconstruction of the displacements fields then assembly into one vector
        thetaxs_1 = (Coefficientlist((2*Nas+1):(2*Nas+Nrs))'*RMS_1_matrix_polynomial)';
        thetaxs_1 = thetaxs_1';
        thetaxs_2 = (Coefficientlist((2*Nas+Nrs + 1):(2*Nas+2*Nrs))'*RMS_2_matrix_polynomial)' + (Coefficientlist((2*Nas+1):(2*Nas+Nrs))'*RMS_1_matrix_polynomial(:,end))';
        thetaxs_2 = thetaxs_2';
        thetaxs(1:length(shat1)) = thetaxs_1;
        thetaxs((length(shat1) + 1):(length(shat1) + length(shat2) - 1)) = thetaxs_2(2:end);

        %First and second derivatives then assembly into one vector - middle point is always the average
        xisD1_1 = (Coefficientlist(1:Nas)'*AMSD1_1_matrix_polynomial)';
        xisD1_1 = xisD1_1';
        xisD1_2 = (Coefficientlist((Nas + 1):2*Nas)'*AMSD1_2_matrix_polynomial)';
        xisD1_2 = xisD1_2';
        xisD1(1:length(shat1)-1) = xisD1_1(1:end-1);
        xisD1(length(shat1)) = (xisD1_1(end) + xisD1_2(1))/2; %average
        xisD1((length(shat1) + 1):(length(shat1) + length(shat2) - 1)) = xisD1_2(2:end);
        
        thetaxsD1_1 = (Coefficientlist((2*Nas+1):(2*Nas+Nrs))'*RMSD1_1_matrix_polynomial)';
        thetaxsD1_1 = thetaxsD1_1';
        thetaxsD1_2 = (Coefficientlist((2*Nas+Nrs + 1):(2*Nas+2*Nrs))'*RMSD1_2_matrix_polynomial)';
        thetaxsD1_2 = thetaxsD1_2';
        thetaxsD1(1:length(shat1)-1) = thetaxsD1_1(1:end-1);
        thetaxsD1(length(shat1)) = (thetaxsD1_1(end) + thetaxsD1_2(1))/2; %average
        thetaxsD1((length(shat1) + 1):(length(shat1) + length(shat2) - 1)) = thetaxsD1_2(2:end);
        
        xisD2_1 = (Coefficientlist(1:Nas)'*AMSD2_1_matrix_polynomial)';
        xisD2_1 = xisD2_1';
        xisD2_2 = (Coefficientlist((Nas + 1):2*Nas)'*AMSD2_2_matrix_polynomial)';
        xisD2_2 = xisD2_2';
        xisD2(1:length(shat1)-1) = xisD2_1(1:end-1);
        xisD2(length(shat1)) = (xisD2_1(end) + xisD2_2(1))/2; %average
        xisD2((length(shat1) + 1):(length(shat1) + length(shat2) - 1)) = xisD2_2(2:end);
    end
end
function [AMS_matrix,AMS_frequency_vector,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMS_frequency_vector,RMSD1_matrix,RMSD2_matrix,TMS_matrix,TMS_frequency_vector,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix] = DynamicalSolutions_Modal_Shapes(UseSupportSprings,Na,Nr,Nt,shat,k2,k3,k5)
    if UseSupportSprings == 1
        %% TRANSVERSE MODE SHAPES - PINNED-FREE EULER-BERNOULLI BEAM + RIGID BODY
        TMS_matrix = zeros(Nt,length(shat));
        TMSD1_matrix = zeros(Nt,length(shat));
        TMSD2_matrix = zeros(Nt,length(shat));
        TMSD3_matrix = zeros(Nt,length(shat));
        TMSD4_matrix = zeros(Nt,length(shat));
        lambda_vector = zeros(Nt,1);
        TMS_frequency_vector = zeros(Nt,1);
        % Evaluation of the coefficients
        f = @(lambda) tan(lambda) - tanh(lambda);
        for i = 1:Nt
           lambda_vector(i) = fzero(f,(4*i + 1)*pi/4);
        end
        sigma_vector = (cosh(lambda_vector) - cos(lambda_vector))./(sinh(lambda_vector) - sin(lambda_vector));
        % Assembly of the modal shapes
        for i = 1:(Nt-1)
            TMS_matrix(i,:) = 1/2*(cosh(lambda_vector(i)*(1-shat)) + cos(lambda_vector(i)*(1-shat)) - sigma_vector(i)*(sinh(lambda_vector(i)*(1-shat)) + sin(lambda_vector(i)*(1-shat))));
            TMS_frequency_vector(i) = lambda_vector(i)^2/(2*pi);
            TMSD1_matrix(i,:) = 1/2*(-lambda_vector(i))*(sinh(lambda_vector(i)*(1-shat)) - sin(lambda_vector(i)*(1-shat)) - sigma_vector(i)*(cosh(lambda_vector(i)*(1-shat)) + cos(lambda_vector(i)*(1-shat))));
            TMSD2_matrix(i,:) = 1/2*(-lambda_vector(i))^2*(cosh(lambda_vector(i)*(1-shat)) - cos(lambda_vector(i)*(1-shat)) - sigma_vector(i)*(sinh(lambda_vector(i)*(1-shat)) - sin(lambda_vector(i)*(1-shat))));
            TMSD3_matrix(i,:) = 1/2*(-lambda_vector(i))^3*(sinh(lambda_vector(i)*(1-shat)) + sin(lambda_vector(i)*(1-shat)) - sigma_vector(i)*(cosh(lambda_vector(i)*(1-shat)) - cos(lambda_vector(i)*(1-shat))));
            TMSD4_matrix(i,:) = 1/2*(-lambda_vector(i))^4*(cosh(lambda_vector(i)*(1-shat)) + cos(lambda_vector(i)*(1-shat)) - sigma_vector(i)*(sinh(lambda_vector(i)*(1-shat)) + sin(lambda_vector(i)*(1-shat))));
        end
        % Rigid body mode
        TMS_matrix(Nt,:) = shat;
        TMS_frequency_vector(Nt) = 0;
        TMSD1_matrix(Nt,:) = ones(length(shat),1);
        TMSD2_matrix(Nt,:) = zeros(length(shat),1);
        TMSD3_matrix(Nt,:) = zeros(length(shat),1);
        TMSD4_matrix(Nt,:) = zeros(length(shat),1);
        %% TORSIONAL MODE SHAPES - FREE-FREE ROD + RIGID BODY
        RMS_matrix = zeros(Nr,length(shat));
        RMSD1_matrix = zeros(Nr,length(shat));
        RMSD2_matrix = zeros(Nr,length(shat));
        RMS_frequency_vector = zeros(Nr,1);
        for i = 1:(Nr-1)
            RMS_matrix(i,:) = cos(i*pi*shat);
            RMS_frequency_vector(i) = i*pi*sqrt(k3/k5)/(2*pi);
            RMSD1_matrix(i,:) = -(i*pi)*sin(i*pi*shat);
            RMSD2_matrix(i,:) = -(i*pi)^2*cos(i*pi*shat);
        end
        % Rigid body mode
        RMS_matrix(Nr,:) = ones(length(shat),1);
        RMS_frequency_vector(Nr) = 0;
        RMSD1_matrix(Nr,:) = zeros(length(shat),1);
        RMSD2_matrix(Nr,:) = zeros(length(shat),1);
        %% AXIAL MODE SHAPES - FIXED-FREE ROD
        AMS_matrix = zeros(Na,length(shat));
        AMSD1_matrix = zeros(Na,length(shat));
        AMSD2_matrix = zeros(Na,length(shat));
        AMS_frequency_vector = zeros(Na,1);
        for i = 1:Na
            AMS_matrix(i,:) = sin(pi*(2*i-1)/2*shat);
            AMS_frequency_vector(i) = ((2*i-1)*pi/2)*sqrt(k2)/(2*pi);
            AMSD1_matrix(i,:) = (pi*(2*i-1)/2)*cos(pi*(2*i-1)/2*shat);
            AMSD2_matrix(i,:) = -(pi*(2*i-1)/2)^2*sin(pi*(2*i-1)/2*shat);
        end
    end
    if UseSupportSprings == 0
        %% TRANSVERSE MODAL SHAPES - CANTILEVERED EULER-BERNOULLI BEAM
        TMS_matrix = zeros(Nt,length(shat));
        TMSD1_matrix = zeros(Nt,length(shat));
        TMSD2_matrix = zeros(Nt,length(shat));
        TMSD3_matrix = zeros(Nt,length(shat));
        TMSD4_matrix = zeros(Nt,length(shat));
        lambda_vector = zeros(Nt,1);
        TMS_frequency_vector = zeros(Nt,1);
        % Evaluation of the coefficients
        f = @(lambda) cos(lambda)*cosh(lambda) + 1;
        for i = 1:Nt
           lambda_vector(i) = fzero(f,(2*i-1)*pi/2);
        end
        sigma_vector = (cosh(lambda_vector) + cos(lambda_vector)) ./ (sinh(lambda_vector) + sin(lambda_vector));

        % Assembly of the modal shapes
        for i = 1:Nt
            TMS_matrix(i,:) = (cosh(lambda_vector(i)*shat) - cos(lambda_vector(i)*shat) - sigma_vector(i)*(sinh(lambda_vector(i)*shat) - sin(lambda_vector(i)*shat)))/2;
            TMS_frequency_vector(i) = lambda_vector(i)^2/(2*pi);
            TMSD1_matrix(i,:) =  (lambda_vector(i))*(sinh(lambda_vector(i)*shat) + sin(lambda_vector(i)*shat) - sigma_vector(i)*(cosh(lambda_vector(i)*shat) - cos(lambda_vector(i)*shat)))/2;
            TMSD2_matrix(i,:) = (lambda_vector(i)^2)*(cosh(lambda_vector(i)*shat) + cos(lambda_vector(i)*shat) - sigma_vector(i)*(sinh(lambda_vector(i)*shat) + sin(lambda_vector(i)*shat)))/2;
            TMSD3_matrix(i,:) = (lambda_vector(i)^3)*(sinh(lambda_vector(i)*shat) - sin(lambda_vector(i)*shat) - sigma_vector(i)*(cosh(lambda_vector(i)*shat) + cos(lambda_vector(i)*shat)))/2;
            TMSD4_matrix(i,:) = (lambda_vector(i)^4)*(cosh(lambda_vector(i)*shat) - cos(lambda_vector(i)*shat) - sigma_vector(i)*(sinh(lambda_vector(i)*shat) - sin(lambda_vector(i)*shat)))/2;
        end
        %% TORSIONAL MODE SHAPES - FIXED-FREE ROD
        RMS_matrix = zeros(Nr,length(shat));
        RMSD1_matrix = zeros(Nr,length(shat));
        RMSD2_matrix = zeros(Nr,length(shat));
        RMS_frequency_vector = zeros(Nr,1);
        for i = 1:Nr
            RMS_matrix(i,:) = sin(pi*(2*i-1)/2*shat);
            RMS_frequency_vector(i) = ((2*i-1)*pi/2)*sqrt(k3/k5)/(2*pi);
            RMSD1_matrix(i,:) = (pi*(2*i-1)/2)*cos(pi*(2*i-1)/2*shat);
            RMSD2_matrix(i,:) = -(pi*(2*i-1)/2)^2*sin(pi*(2*i-1)/2*shat);
        end
        %% AXIAL MODE SHAPES - FIXED-FREE ROD
        AMS_matrix = zeros(Na,length(shat));
        AMSD1_matrix = zeros(Na,length(shat));
        AMSD2_matrix = zeros(Na,length(shat));
        AMS_frequency_vector = zeros(Na,1);
        for i = 1:Na
            AMS_matrix(i,:) = sin(pi*(2*i-1)/2*shat);
            AMS_frequency_vector(i) = ((2*i-1)*pi/2)*sqrt(k2)/(2*pi);
            AMSD1_matrix(i,:) = (pi*(2*i-1)/2)*cos(pi*(2*i-1)/2*shat);
            AMSD2_matrix(i,:) = -(pi*(2*i-1)/2)^2*sin(pi*(2*i-1)/2*shat);
        end
    end
end
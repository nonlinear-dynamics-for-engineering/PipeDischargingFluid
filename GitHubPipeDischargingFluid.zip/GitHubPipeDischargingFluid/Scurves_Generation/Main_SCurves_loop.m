%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% PIPE DISCHARGING FLUID - S-SHAPES CURVES %%%%%%%%%%%%%%%%%
clear all
close all
clc
%% DIMENSIONLESS PARAMETERS
% Dimensionless arclength coordinate
resolution = 1001; % Discretization of the longitudinal axis
shat = linspace(0,1,resolution); % Longitudinal axis
% Relevant dimensionless parameters for the STATIC solutions
for countercaso = 10:14
    if countercaso == 1 %111
        gamma = 0; % = (m + M)gL^3/(EIy)
		k0 = 0; % = MtL/(GIp)
		xibart = 1.0; % = xbart/L
		k1 = 2; % = EIp/(EIy)
		k2 = 10000; % = EAL^2/(EIy)
		k3 = 0.7; % = GIp/(EIy)
		k4 = 0.001; % = EI4/(EIyL^2)
		mnhat = 0; % = mn/(m + M)L
		xibar = 0.5; % = xbar/L
		Chatstheta = 1000; % = (Csx L)/(EIy)
		% Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
		UseSupportSprings = 0;
    elseif countercaso == 2 %121
		gamma = 50; % = (m + M)gL^3/(EIy)
		k0 = 0; % = MtL/(GIp)
		xibart = 1.0; % = xbart/L
		k1 = 2; % = EIp/(EIy)
		k2 = 10000; % = EAL^2/(EIy)
		k3 = 0.7; % = GIp/(EIy)
		k4 = 0.001; % = EI4/(EIyL^2)
		mnhat = 0; % = mn/(m + M)L
		xibar = 0.5; % = xbar/L
		Chatstheta = 1000; % = (Csx L)/(EIy)
		% Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
		UseSupportSprings = 0;
    elseif countercaso == 3 %131
        gamma = 0; % = (m + M)gL^3/(EIy)
		k0 = pi/2; % = MtL/(GIp)
		xibart = 1.0; % = xbart/L
		k1 = 2; % = EIp/(EIy)
		k2 = 10000; % = EAL^2/(EIy)
		k3 = 0.7; % = GIp/(EIy)
		k4 = 0.001; % = EI4/(EIyL^2)
		mnhat = 0; % = mn/(m + M)L
		xibar = 0.5; % = xbar/L
		Chatstheta = 1000; % = (Csx L)/(EIy)
		% Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
		UseSupportSprings = 0;
    elseif countercaso == 4 %132
        gamma = 0; % = (m + M)gL^3/(EIy)
		k0 = 3*pi/4; % = MtL/(GIp)
		xibart = 1.0; % = xbart/L
		k1 = 2; % = EIp/(EIy)
		k2 = 10000; % = EAL^2/(EIy)
		k3 = 0.7; % = GIp/(EIy)
		k4 = 0.001; % = EI4/(EIyL^2)
		mnhat = 0; % = mn/(m + M)L
		xibar = 0.5; % = xbar/L
		Chatstheta = 1000; % = (Csx L)/(EIy)
		% Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
		UseSupportSprings = 0;
    elseif countercaso == 5 %133
        gamma = 0; % = (m + M)gL^3/(EIy)
		k0 = 4*pi/5; % = MtL/(GIp)
		xibart = 1.0; % = xbart/L
		k1 = 2; % = EIp/(EIy)
		k2 = 10000; % = EAL^2/(EIy)
		k3 = 0.7; % = GIp/(EIy)
		k4 = 0.001; % = EI4/(EIyL^2)
		mnhat = 0; % = mn/(m + M)L
		xibar = 0.5; % = xbar/L
		Chatstheta = 1000; % = (Csx L)/(EIy)
		% Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
		UseSupportSprings = 0;
    elseif countercaso == 6 %134
        gamma = 0; % = (m + M)gL^3/(EIy)
		k0 = 3*pi/2; % = MtL/(GIp)
		xibart = 1.0; % = xbart/L
		k1 = 2; % = EIp/(EIy)
		k2 = 10000; % = EAL^2/(EIy)
		k3 = 0.7; % = GIp/(EIy)
		k4 = 0.001; % = EI4/(EIyL^2)
		mnhat = 0; % = mn/(m + M)L
		xibar = 0.5; % = xbar/L
		Chatstheta = 1000; % = (Csx L)/(EIy)
		% Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
		UseSupportSprings = 0;
    elseif countercaso == 7 %135
        gamma = 0; % = (m + M)gL^3/(EIy)
		k0 = pi; % = MtL/(GIp)
		xibart = 0.5; % = xbart/L
		k1 = 2; % = EIp/(EIy)
		k2 = 10000; % = EAL^2/(EIy)
		k3 = 0.7; % = GIp/(EIy)
		k4 = 0.001; % = EI4/(EIyL^2)
		mnhat = 0; % = mn/(m + M)L
		xibar = 0.5; % = xbar/L
		Chatstheta = 1000; % = (Csx L)/(EIy)
		% Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
		UseSupportSprings = 0;
    elseif countercaso == 8 %136
        gamma = 0; % = (m + M)gL^3/(EIy)
		k0 = 6*pi/4; % = MtL/(GIp)
		xibart = 0.5; % = xbart/L
		k1 = 2; % = EIp/(EIy)
		k2 = 10000; % = EAL^2/(EIy)
		k3 = 0.7; % = GIp/(EIy)
		k4 = 0.001; % = EI4/(EIyL^2)
		mnhat = 0; % = mn/(m + M)L
		xibar = 0.5; % = xbar/L
		Chatstheta = 1000; % = (Csx L)/(EIy)
		% Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
		UseSupportSprings = 0;
    elseif countercaso == 9 %137
        gamma = 0; % = (m + M)gL^3/(EIy)
		k0 = 8*pi/5; % = MtL/(GIp)
		xibart = 0.5; % = xbart/L
		k1 = 2; % = EIp/(EIy)
		k2 = 10000; % = EAL^2/(EIy)
		k3 = 0.7; % = GIp/(EIy)
		k4 = 0.001; % = EI4/(EIyL^2)
		mnhat = 0; % = mn/(m + M)L
		xibar = 0.5; % = xbar/L
		Chatstheta = 1000; % = (Csx L)/(EIy)
		% Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
		UseSupportSprings = 0;
    elseif countercaso == 10 %138
        gamma = 0; % = (m + M)gL^3/(EIy)
		k0 = 6*pi/2; % = MtL/(GIp)
		xibart = 0.5; % = xbart/L
		k1 = 2; % = EIp/(EIy)
		k2 = 10000; % = EAL^2/(EIy)
		k3 = 0.7; % = GIp/(EIy)
		k4 = 0.001; % = EI4/(EIyL^2)
		mnhat = 0; % = mn/(m + M)L
		xibar = 0.5; % = xbar/L
		Chatstheta = 1000; % = (Csx L)/(EIy)
		% Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
		UseSupportSprings = 0;
    elseif countercaso == 11 %141
		gamma = 0; % = (m + M)gL^3/(EIy)
		k0 = 0; % = MtL/(GIp)  
		xibart = 1.0; % = xbart/L
		k1 = 2; % = EIp/(EIy)
		k2 = 5000; % = EAL^2/(EIy)
		k3 = 0.7; % = GIp/(EIy)
		k4 = 0.001; % = EI4/(EIyL^2)
		mnhat = 0; % = mn/(m + M)L
		xibar = 0.5; % = xbar/L
		Chatstheta = 1000; % = (Csx L)/(EIy)
		% Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
		UseSupportSprings = 0;
    elseif countercaso == 12 %142
        gamma = 0; % = (m + M)gL^3/(EIy)
		k0 = 0; % = MtL/(GIp)  
		xibart = 1.0; % = xbart/L
		k1 = 2; % = EIp/(EIy)
		k2 = 1000; % = EAL^2/(EIy)
		k3 = 0.7; % = GIp/(EIy)
		k4 = 0.001; % = EI4/(EIyL^2)
		mnhat = 0; % = mn/(m + M)L
		xibar = 0.5; % = xbar/L
		Chatstheta = 1000; % = (Csx L)/(EIy)
		% Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
		UseSupportSprings = 0;
    elseif countercaso == 13 %151
        gamma = 0; % = (m + M)gL^3/(EIy)
		k0 = 0; % = MtL/(GIp)  
		xibart = 1.0; % = xbart/L
		k1 = 2; % = EIp/(EIy)
		k2 = 10000; % = EAL^2/(EIy) 
		k3 = 0.7; % = GIp/(EIy)
		k4 = 0.001; % = EI4/(EIyL^2)
		mnhat = 0.2; % = mn/(m + M)L
		xibar = 0.5; % = xbar/L
		Chatstheta = 1000; % = (Csx L)/(EIy) 
		% Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
		UseSupportSprings = 0;
    elseif countercaso == 14 %152
		gamma = 0; % = (m + M)gL^3/(EIy)
		k0 = 0; % = MtL/(GIp)  
		xibart = 1.0; % = xbart/L
		k1 = 2; % = EIp/(EIy)
		k2 = 10000; % = EAL^2/(EIy) 
		k3 = 0.7; % = GIp/(EIy)
		k4 = 0.001; % = EI4/(EIyL^2)
		mnhat = 0.2; % = mn/(m + M)L
		xibar = 1.0; % = xbar/L
		Chatstheta = 1000; % = (Csx L)/(EIy) 
		% Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
		UseSupportSprings = 0;
    end
    % k0, xibart and gamma are already considered in the static solutions. They do not appear explicitly here
    % Relevant dimensionless parameters only for the DYNAMIC solutions
	Chatsy = 1000; % = (Csy L)/(EIy)
	Chatsz = 1000; % = (Csz L)/(EIy)
	k5 = 0.001; % = Jp/((m + M)L^2)
	Ihat = 1; % = Iz/Iy
	chatx = 0.0; % = (cx L^2)/sqrt(EIy(m + M))
	chaty = 0.0; % = (cy L^2)/sqrt(EIy(m + M))
	chatz = 0.0; % = (cz L^2)/sqrt(EIy(m + M))
	chattheta = 0.0; % = ctheta/sqrt(EIy(m + M))
	% Numerical integration parameters, number of shape functions and IC
	% Number of shape functions
	Na = 3; % Number of axial modal shapes
	Nr = 4; % Number of torsional modal shapes
    %% LOADING OF THE PRE-EVALUATED STATIC SOLUTIONS COEFFICIENTS AND STATIC SOLUTIONS CONSTRUCTION
    if countercaso == 1 %111
        StaticSolutions_Coefficients_matrixread = 'library\StaticSolutions_Coefficients_matrix_111.csv';
        StaticSolutions_Coefficients_matrix = dlmread(StaticSolutions_Coefficients_matrixread);%creates a matrix out of the data
    elseif countercaso == 2 %121
        StaticSolutions_Coefficients_matrixread = 'library\StaticSolutions_Coefficients_matrix_121.csv';
        StaticSolutions_Coefficients_matrix = dlmread(StaticSolutions_Coefficients_matrixread);%creates a matrix out of the data
    elseif countercaso == 3 %131
        StaticSolutions_Coefficients_matrixread = 'library\StaticSolutions_Coefficients_matrix_131.csv';
        StaticSolutions_Coefficients_matrix = dlmread(StaticSolutions_Coefficients_matrixread);%creates a matrix out of the data
    elseif countercaso == 4 %132
        StaticSolutions_Coefficients_matrixread = 'library\StaticSolutions_Coefficients_matrix_132.csv';
        StaticSolutions_Coefficients_matrix = dlmread(StaticSolutions_Coefficients_matrixread);%creates a matrix out of the data
    elseif countercaso == 5 %133
        StaticSolutions_Coefficients_matrixread = 'library\StaticSolutions_Coefficients_matrix_133.csv';
        StaticSolutions_Coefficients_matrix = dlmread(StaticSolutions_Coefficients_matrixread);%creates a matrix out of the data
    elseif countercaso == 6 %134
        StaticSolutions_Coefficients_matrixread = 'library\StaticSolutions_Coefficients_matrix_134.csv';
        StaticSolutions_Coefficients_matrix = dlmread(StaticSolutions_Coefficients_matrixread);%creates a matrix out of the data
    elseif countercaso == 7 %135
        StaticSolutions_Coefficients_matrixread = 'library\StaticSolutions_Coefficients_matrix_135.csv';
        StaticSolutions_Coefficients_matrix = dlmread(StaticSolutions_Coefficients_matrixread);%creates a matrix out of the data
    elseif countercaso == 8 %136
        StaticSolutions_Coefficients_matrixread = 'library\StaticSolutions_Coefficients_matrix_136.csv';
        StaticSolutions_Coefficients_matrix = dlmread(StaticSolutions_Coefficients_matrixread);%creates a matrix out of the data
    elseif countercaso == 9 %137
        StaticSolutions_Coefficients_matrixread = 'library\StaticSolutions_Coefficients_matrix_137.csv';
        StaticSolutions_Coefficients_matrix = dlmread(StaticSolutions_Coefficients_matrixread);%creates a matrix out of the data
    elseif countercaso == 10 %138
        StaticSolutions_Coefficients_matrixread = 'library\StaticSolutions_Coefficients_matrix_138.csv';
        StaticSolutions_Coefficients_matrix = dlmread(StaticSolutions_Coefficients_matrixread);%creates a matrix out of the data
    elseif countercaso == 11 %141
        StaticSolutions_Coefficients_matrixread = 'library\StaticSolutions_Coefficients_matrix_141.csv';
        StaticSolutions_Coefficients_matrix = dlmread(StaticSolutions_Coefficients_matrixread);%creates a matrix out of the data
    elseif countercaso == 12 %142
        StaticSolutions_Coefficients_matrixread = 'library\StaticSolutions_Coefficients_matrix_142.csv';
        StaticSolutions_Coefficients_matrix = dlmread(StaticSolutions_Coefficients_matrixread);%creates a matrix out of the data
    elseif countercaso == 13 %151
        StaticSolutions_Coefficients_matrixread = 'library\StaticSolutions_Coefficients_matrix_151.csv';
        StaticSolutions_Coefficients_matrix = dlmread(StaticSolutions_Coefficients_matrixread);%creates a matrix out of the data
    elseif countercaso == 14 %152
        StaticSolutions_Coefficients_matrixread = 'library\StaticSolutions_Coefficients_matrix_152.csv';
        StaticSolutions_Coefficients_matrix = dlmread(StaticSolutions_Coefficients_matrixread);%creates a matrix out of the data
    end
    % Construction of the polynomial modal shapes for the static solutions reconstruction
Nas = 4; % Has to be because the static solutions are already evaluated
Nrs = 4; % Has to be because the static solutions are already evaluated
[casenumber,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMS_2_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,AMS_3_matrix_polynomial,AMSD1_3_matrix_polynomial,AMSD2_3_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMSD2_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,RMSD2_2_matrix_polynomial,RMS_3_matrix_polynomial,RMSD1_3_matrix_polynomial,RMSD2_3_matrix_polynomial,shat1,shat2,shat3] = StaticSolutions_Axial_And_Rotational_Polynomial_Shapes(UseSupportSprings,Nas,Nrs,shat,mnhat,xibar,k0,xibart);
    %%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%% S-STABILITY CURVES %%%%%%%%%%%%%%%%%%%%%%%%%%%
    betaresolution = 1000;
    ucrit_functions_all_flutter = nan(105,betaresolution);
    ucrit_functions_all_divergence = nan(105,betaresolution);
    tic
    for Nt = 8:8% Change here for all curves
        disp(Nt)
		% Dynamical modal shapes, do not mix them up
		[AMS_matrix,~,AMSD1_matrix,AMSD2_matrix,RMS_matrix,~,RMSD1_matrix,RMSD2_matrix,TMS_matrix,~,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix] = DynamicalSolutions_Modal_Shapes(UseSupportSprings,Na,Nr,Nt,shat,k2,k3,k5);
		[ucrit_functions,~] = SCurves_flutter(k0,xibart,StaticSolutions_Coefficients_matrix,betaresolution,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,casenumber,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMS_2_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,AMS_3_matrix_polynomial,AMSD1_3_matrix_polynomial,AMSD2_3_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMSD2_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,RMSD2_2_matrix_polynomial,RMS_3_matrix_polynomial,RMSD1_3_matrix_polynomial,RMSD2_3_matrix_polynomial,shat1,shat2,shat3);
		ucrit_functions_all_flutter((Nt-1)*15-14:(Nt-1)*15,:) = ucrit_functions;
		[ucrit_functions,betavector] = SCurves_divergence(k0,xibart,StaticSolutions_Coefficients_matrix,betaresolution,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,casenumber,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMS_2_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,AMS_3_matrix_polynomial,AMSD1_3_matrix_polynomial,AMSD2_3_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMSD2_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,RMSD2_2_matrix_polynomial,RMS_3_matrix_polynomial,RMSD1_3_matrix_polynomial,RMSD2_3_matrix_polynomial,shat1,shat2,shat3);
		ucrit_functions_all_divergence((Nt-1)*15-14:(Nt-1)*15,:) = ucrit_functions;
    end
    toc
    if countercaso == 1 %111
        dlmwrite('Export\ucrit_functions_flutter_111.csv',ucrit_functions_all_flutter,'delimiter',',','precision',16)
        dlmwrite('Export\ucrit_functions_divergence_111.csv',ucrit_functions_all_divergence,'delimiter',',','precision',16)
        dlmwrite('Export\betavector.csv',betavector,'delimiter',',','precision',16)
    elseif countercaso == 2 %121
        dlmwrite('Export\ucrit_functions_flutter_121.csv',ucrit_functions_all_flutter,'delimiter',',','precision',16)
        dlmwrite('Export\ucrit_functions_divergence_121.csv',ucrit_functions_all_divergence,'delimiter',',','precision',16)
        dlmwrite('Export\betavector.csv',betavector,'delimiter',',','precision',16)
    elseif countercaso == 3 %131
        dlmwrite('Export\ucrit_functions_flutter_131.csv',ucrit_functions_all_flutter,'delimiter',',','precision',16)
        dlmwrite('Export\ucrit_functions_divergence_131.csv',ucrit_functions_all_divergence,'delimiter',',','precision',16)
        dlmwrite('Export\betavector.csv',betavector,'delimiter',',','precision',16)
    elseif countercaso == 4 %132
        dlmwrite('Export\ucrit_functions_flutter_132.csv',ucrit_functions_all_flutter,'delimiter',',','precision',16)
        dlmwrite('Export\ucrit_functions_divergence_132.csv',ucrit_functions_all_divergence,'delimiter',',','precision',16)
        dlmwrite('Export\betavector.csv',betavector,'delimiter',',','precision',16)
    elseif countercaso == 5 %133
        dlmwrite('Export\ucrit_functions_flutter_133.csv',ucrit_functions_all_flutter,'delimiter',',','precision',16)
        dlmwrite('Export\ucrit_functions_divergence_133.csv',ucrit_functions_all_divergence,'delimiter',',','precision',16)
        dlmwrite('Export\betavector.csv',betavector,'delimiter',',','precision',16)
    elseif countercaso == 6 %134
        dlmwrite('Export\ucrit_functions_flutter_134.csv',ucrit_functions_all_flutter,'delimiter',',','precision',16)
        dlmwrite('Export\ucrit_functions_divergence_134.csv',ucrit_functions_all_divergence,'delimiter',',','precision',16)
        dlmwrite('Export\betavector.csv',betavector,'delimiter',',','precision',16)
    elseif countercaso == 7 %135
        dlmwrite('Export\ucrit_functions_flutter_135.csv',ucrit_functions_all_flutter,'delimiter',',','precision',16)
        dlmwrite('Export\ucrit_functions_divergence_135.csv',ucrit_functions_all_divergence,'delimiter',',','precision',16)
        dlmwrite('Export\betavector.csv',betavector,'delimiter',',','precision',16)
    elseif countercaso == 8 %136
        dlmwrite('Export\ucrit_functions_flutter_136.csv',ucrit_functions_all_flutter,'delimiter',',','precision',16)
        dlmwrite('Export\ucrit_functions_divergence_136.csv',ucrit_functions_all_divergence,'delimiter',',','precision',16)
        dlmwrite('Export\betavector.csv',betavector,'delimiter',',','precision',16)
    elseif countercaso == 9 %137
        dlmwrite('Export\ucrit_functions_flutter_137.csv',ucrit_functions_all_flutter,'delimiter',',','precision',16)
        dlmwrite('Export\ucrit_functions_divergence_137.csv',ucrit_functions_all_divergence,'delimiter',',','precision',16)
        dlmwrite('Export\betavector.csv',betavector,'delimiter',',','precision',16)
    elseif countercaso == 10 %138
        dlmwrite('Export\ucrit_functions_flutter_138.csv',ucrit_functions_all_flutter,'delimiter',',','precision',16)
        dlmwrite('Export\ucrit_functions_divergence_138.csv',ucrit_functions_all_divergence,'delimiter',',','precision',16)
        dlmwrite('Export\betavector.csv',betavector,'delimiter',',','precision',16)
    elseif countercaso == 11 %141
        dlmwrite('Export\ucrit_functions_flutter_141.csv',ucrit_functions_all_flutter,'delimiter',',','precision',16)
        dlmwrite('Export\ucrit_functions_divergence_141.csv',ucrit_functions_all_divergence,'delimiter',',','precision',16)
        dlmwrite('Export\betavector.csv',betavector,'delimiter',',','precision',16)
    elseif countercaso == 12 %142
        dlmwrite('Export\ucrit_functions_flutter_142.csv',ucrit_functions_all_flutter,'delimiter',',','precision',16)
        dlmwrite('Export\ucrit_functions_divergence_142.csv',ucrit_functions_all_divergence,'delimiter',',','precision',16)
        dlmwrite('Export\betavector.csv',betavector,'delimiter',',','precision',16)
    elseif countercaso == 13 %151
        dlmwrite('Export\ucrit_functions_flutter_151.csv',ucrit_functions_all_flutter,'delimiter',',','precision',16)
        dlmwrite('Export\ucrit_functions_divergence_151.csv',ucrit_functions_all_divergence,'delimiter',',','precision',16)
        dlmwrite('Export\betavector.csv',betavector,'delimiter',',','precision',16)
    elseif countercaso == 14 %152
        dlmwrite('Export\ucrit_functions_flutter_152.csv',ucrit_functions_all_flutter,'delimiter',',','precision',16)
        dlmwrite('Export\ucrit_functions_divergence_152.csv',ucrit_functions_all_divergence,'delimiter',',','precision',16)
        dlmwrite('Export\betavector.csv',betavector,'delimiter',',','precision',16)
    end
end
        
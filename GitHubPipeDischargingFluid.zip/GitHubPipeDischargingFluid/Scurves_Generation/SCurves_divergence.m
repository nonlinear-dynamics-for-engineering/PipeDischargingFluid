function [ucrit_functions,betavector] = SCurves_divergence(numberofdomains,k0,StaticSolutions_Coefficients_matrix,betaresolution,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2)
    tol = 10^-3;
    betavector = linspace(0.001,1.0,betaresolution);
    ucrit_function1 = nan(1,betaresolution); 
    ucrit_function2 = nan(1,betaresolution); 
    ucrit_function3 = nan(1,betaresolution); 
    ucrit_function4 = nan(1,betaresolution); 
    ucrit_function5 = nan(1,betaresolution); 
    ucrit_function6 = nan(1,betaresolution);
    ucrit_function7 = nan(1,betaresolution);
    ucrit_function8 = nan(1,betaresolution);
    ucrit_function9 = nan(1,betaresolution);
    ucrit_function10 = nan(1,betaresolution);
    ucrit_function11 = nan(1,betaresolution);
    ucrit_function12 = nan(1,betaresolution);
    ucrit_function13 = nan(1,betaresolution);
    ucrit_function14 = nan(1,betaresolution);
    ucrit_function15 = nan(1,betaresolution);

    uvector = 0.01:0.01:30;
    parfor betacont = 1:betaresolution
        betacont
        beta = betavector(betacont);
        end_contu1 = 0;
        end_contu2 = 0;
        end_contu3 = 0;
        end_contu4 = 0;
        end_contu5 = 0;
        end_contu6 = 0;
        end_contu7 = 0;
        end_contu8 = 0;
        end_contu9 = 0;
        end_contu10 = 0;
        end_contu11 = 0;
        end_contu12 = 0;
        end_contu13 = 0;
        end_contu14 = 0;
        end_contu15 = 0;
        %% FIRST UCRIT - contu1 COUNTER
        for contu1 = 1:length(uvector)
            if end_contu1 == 0
                u = uvector(contu1);
                [Vector_real_parts,Vector_imaginary_parts] = RealandImaginaryParts(k0,beta,u,contu1,StaticSolutions_Coefficients_matrix,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,numberofdomains,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2);
                [Max_real_part,positionmax] = max(Vector_real_parts);
                Correspondent_Imaginary_part = Vector_imaginary_parts(positionmax);
                if Max_real_part > tol && abs(Correspondent_Imaginary_part) < 10^-6 %1
                    ucrit = u;
                    ucrit_function1(1,betacont) = ucrit;
                    end_contu1 = 1;
                    %% SECOND UCRIT - contu2 COUNTER
                    for contu2 = contu1+1:length(uvector)
                        if end_contu2 == 0
                            u = uvector(contu2);
                            [Vector_real_parts,~] = RealandImaginaryParts(k0,beta,u,contu2,StaticSolutions_Coefficients_matrix,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,numberofdomains,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2);
                            [Max_real_part,~] = max(Vector_real_parts);
                            if Max_real_part < tol %2
                                ucrit = u;
                                ucrit_function2(1,betacont) = ucrit;
                                end_contu2 = 1;
                                %% THIRD UCRIT - contu3 COUNTER
                                for contu3 = contu2+1:length(uvector)
                                    if end_contu3 == 0
                                        u = uvector(contu3);
                                        [Vector_real_parts,Vector_imaginary_parts] = RealandImaginaryParts(k0,beta,u,contu3,StaticSolutions_Coefficients_matrix,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,numberofdomains,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2);
                                        [Max_real_part,positionmax] = max(Vector_real_parts);
                                        Correspondent_Imaginary_part = Vector_imaginary_parts(positionmax);
                                        if Max_real_part > tol && abs(Correspondent_Imaginary_part) < 10^-6 %3
                                            ucrit = u;
                                            ucrit_function3(1,betacont) = ucrit;
                                            end_contu3 = 1;
                                            %% FOURTH UCRIT - contu4 COUNTER
                                            for contu4 = contu3+1:length(uvector)
                                                if end_contu4 == 0
                                                    u = uvector(contu4);
                                                    [Vector_real_parts,~] = RealandImaginaryParts(k0,beta,u,contu4,StaticSolutions_Coefficients_matrix,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,numberofdomains,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2);
                                                    [Max_real_part,~] = max(Vector_real_parts);
                                                    if Max_real_part < tol %4
                                                        ucrit = u;
                                                        ucrit_function4(1,betacont) = ucrit;
                                                        end_contu4 = 1;
                                                        %% FIFTH UCRIT - contu5 COUNTER
                                                        for contu5 = contu4+1:length(uvector)
                                                            if end_contu5 == 0
                                                                u = uvector(contu5);
                                                                [Vector_real_parts,Vector_imaginary_parts] = RealandImaginaryParts(k0,beta,u,contu5,StaticSolutions_Coefficients_matrix,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,numberofdomains,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2);
                                                                [Max_real_part,positionmax] = max(Vector_real_parts);
                                                                Correspondent_Imaginary_part = Vector_imaginary_parts(positionmax);
                                                                if Max_real_part > tol && abs(Correspondent_Imaginary_part) < 10^-6 %5
                                                                    ucrit = u;
                                                                    ucrit_function5(1,betacont) = ucrit;
                                                                    end_contu5 = 1;
                                                                    %% SIXTH UCRIT - contu6 COUNTER
                                                                    for contu6 = contu5+1:length(uvector)
                                                                        if end_contu6 == 0
                                                                            u = uvector(contu6);
                                                                            [Vector_real_parts,~] = RealandImaginaryParts(k0,beta,u,contu6,StaticSolutions_Coefficients_matrix,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,numberofdomains,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2);
                                                                            [Max_real_part,~] = max(Vector_real_parts);
                                                                            if Max_real_part < tol %6
                                                                                ucrit = u;
                                                                                ucrit_function6(1,betacont) = ucrit;
                                                                                end_contu6 = 1;
                                                                                %% SEVENTH UCRIT - contu7 COUNTER
                                                                                for contu7 = contu6+1:length(uvector)
                                                                                    if end_contu7 == 0
                                                                                        u = uvector(contu7);
                                                                                        [Vector_real_parts,Vector_imaginary_parts] = RealandImaginaryParts(k0,beta,u,contu7,StaticSolutions_Coefficients_matrix,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,numberofdomains,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2);
                                                                                        [Max_real_part,positionmax] = max(Vector_real_parts);
                                                                                        Correspondent_Imaginary_part = Vector_imaginary_parts(positionmax);
                                                                                        if Max_real_part > tol && abs(Correspondent_Imaginary_part) < 10^-6 %7
                                                                                            ucrit = u;
                                                                                            ucrit_function7(1,betacont) = ucrit;
                                                                                            end_contu7 = 1;
                                                                                            %% EIGTH UCRIT - contu8 COUNTER
                                                                                            for contu8 = contu7+1:length(uvector)
                                                                                                if end_contu8 == 0
                                                                                                    u = uvector(contu8);
                                                                                                    [Vector_real_parts,~] = RealandImaginaryParts(k0,beta,u,contu8,StaticSolutions_Coefficients_matrix,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,numberofdomains,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2);
                                                                                                    [Max_real_part,~] = max(Vector_real_parts);
                                                                                                    if Max_real_part < tol %8
                                                                                                        ucrit = u;
                                                                                                        ucrit_function8(1,betacont) = ucrit;
                                                                                                        end_contu8 = 1;
                                                                                                        %% NINTH UCRIT - contu9 COUNTER
                                                                                                        for contu9 = contu8+1:length(uvector)
                                                                                                            if end_contu9 == 0
                                                                                                                u = uvector(contu9);
                                                                                                                [Vector_real_parts,Vector_imaginary_parts] = RealandImaginaryParts(k0,beta,u,contu9,StaticSolutions_Coefficients_matrix,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,numberofdomains,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2);
                                                                                                                [Max_real_part,positionmax] = max(Vector_real_parts);
                                                                                                                Correspondent_Imaginary_part = Vector_imaginary_parts(positionmax);
                                                                                                                if Max_real_part > tol && abs(Correspondent_Imaginary_part) < 10^-6 %9
                                                                                                                    ucrit = u;
                                                                                                                    ucrit_function9(1,betacont) = ucrit;
                                                                                                                    end_contu9 = 1;
                                                                                                                    %% TENTH UCRIT - contu10 COUNTER
                                                                                                                    for contu10 = contu9+1:length(uvector)
                                                                                                                        if end_contu10 == 0
                                                                                                                            u = uvector(contu10);
                                                                                                                            [Vector_real_parts,~] = RealandImaginaryParts(k0,beta,u,contu10,StaticSolutions_Coefficients_matrix,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,numberofdomains,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2);
                                                                                                                            [Max_real_part,~] = max(Vector_real_parts);
                                                                                                                            if Max_real_part < tol %10
                                                                                                                                ucrit = u;
                                                                                                                                ucrit_function10(1,betacont) = ucrit;
                                                                                                                                end_contu10 = 1;
                                                                                                                                %% ELEVENTH UCRIT - contu11 COUNTER
                                                                                                                                for contu11 = contu10+1:length(uvector)
                                                                                                                                    if end_contu11 == 0
                                                                                                                                        u = uvector(contu11);
                                                                                                                                        [Vector_real_parts,Vector_imaginary_parts] = RealandImaginaryParts(k0,beta,u,contu11,StaticSolutions_Coefficients_matrix,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,numberofdomains,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2);
                                                                                                                                        [Max_real_part,positionmax] = max(Vector_real_parts);
                                                                                                                                        Correspondent_Imaginary_part = Vector_imaginary_parts(positionmax);
                                                                                                                                        if Max_real_part > tol && abs(Correspondent_Imaginary_part) < 10^-6 %11
                                                                                                                                            ucrit = u;
                                                                                                                                            ucrit_function11(1,betacont) = ucrit;
                                                                                                                                            end_contu11 = 1;
                                                                                                                                            %% TWELFTH UCRIT - contu12 COUNTER
                                                                                                                                            for contu12 = contu11+1:length(uvector)
                                                                                                                                                if end_contu12 == 0
                                                                                                                                                    u = uvector(contu12);
                                                                                                                                                    [Vector_real_parts,~] = RealandImaginaryParts(k0,beta,u,contu12,StaticSolutions_Coefficients_matrix,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,numberofdomains,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2);
                                                                                                                                                    [Max_real_part,~] = max(Vector_real_parts);
                                                                                                                                                    if Max_real_part < tol %12
                                                                                                                                                        ucrit = u;
                                                                                                                                                        ucrit_function12(1,betacont) = ucrit;
                                                                                                                                                        end_contu12 = 1;
                                                                                                                                                        %% THIRTEENTH UCRIT - contu13 COUNTER
                                                                                                                                                        for contu13 = contu12+1:length(uvector)
                                                                                                                                                            if end_contu13 == 0
                                                                                                                                                                u = uvector(contu13);
                                                                                                                                                                [Vector_real_parts,Vector_imaginary_parts] = RealandImaginaryParts(k0,beta,u,contu13,StaticSolutions_Coefficients_matrix,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,numberofdomains,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2);
                                                                                                                                                                [Max_real_part,positionmax] = max(Vector_real_parts);
                                                                                                                                                                Correspondent_Imaginary_part = Vector_imaginary_parts(positionmax);
                                                                                                                                                                if Max_real_part > tol && abs(Correspondent_Imaginary_part) < 10^-6 %13
                                                                                                                                                                    ucrit = u;
                                                                                                                                                                    ucrit_function13(1,betacont) = ucrit;
                                                                                                                                                                    end_contu13 = 1;
                                                                                                                                                                    %% FOURTEENTH UCRIT - contu14 COUNTER
                                                                                                                                                                    for contu14 = contu13+1:length(uvector)
                                                                                                                                                                        if end_contu14 == 0
                                                                                                                                                                            u = uvector(contu14);
                                                                                                                                                                            [Vector_real_parts,~] = RealandImaginaryParts(k0,beta,u,contu14,StaticSolutions_Coefficients_matrix,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,numberofdomains,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2);
                                                                                                                                                                            [Max_real_part,~] = max(Vector_real_parts);
                                                                                                                                                                            if Max_real_part < tol %14
                                                                                                                                                                                ucrit = u;
                                                                                                                                                                                ucrit_function14(1,betacont) = ucrit;
                                                                                                                                                                                end_contu14 = 1;
                                                                                                                                                                                %% FIFTEENTH UCRIT - contu15 COUNTER
                                                                                                                                                                                for contu15 = contu14+1:length(uvector)
                                                                                                                                                                                    if end_contu15 == 0
                                                                                                                                                                                        u = uvector(contu15);
                                                                                                                                                                                        [Vector_real_parts,Vector_imaginary_parts] = RealandImaginaryParts(k0,beta,u,contu15,StaticSolutions_Coefficients_matrix,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,numberofdomains,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2);
                                                                                                                                                                                        [Max_real_part,positionmax] = max(Vector_real_parts);
                                                                                                                                                                                        Correspondent_Imaginary_part = Vector_imaginary_parts(positionmax);
                                                                                                                                                                                        if Max_real_part > tol && abs(Correspondent_Imaginary_part) < 10^-6 %15
                                                                                                                                                                                            ucrit = u;
                                                                                                                                                                                            ucrit_function15(1,betacont) = ucrit;
                                                                                                                                                                                            end_contu15 = 1;
                                                                                                                                                                                        end
                                                                                                                                                                                    end
                                                                                                                                                                                end
                                                                                                                                                                            end
                                                                                                                                                                        end
                                                                                                                                                                    end
                                                                                                                                                                end
                                                                                                                                                            end
                                                                                                                                                        end
                                                                                                                                                    end
                                                                                                                                                end
                                                                                                                                            end
                                                                                                                                        end
                                                                                                                                    end
                                                                                                                                end
                                                                                                                            end
                                                                                                                        end
                                                                                                                    end
                                                                                                                end
                                                                                                            end
                                                                                                        end
                                                                                                    end
                                                                                                end
                                                                                            end
                                                                                        end
                                                                                    end
                                                                                end
                                                                            end
                                                                        end
                                                                    end
                                                                end
                                                            end
                                                        end
                                                    end
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end  
    ucrit_functions = nan(15,betaresolution);
    ucrit_functions(1,:) = ucrit_function1;
    ucrit_functions(2,:) = ucrit_function2;
    ucrit_functions(3,:) = ucrit_function3;
    ucrit_functions(4,:) = ucrit_function4;
    ucrit_functions(5,:) = ucrit_function5;
    ucrit_functions(6,:) = ucrit_function6;
    ucrit_functions(7,:) = ucrit_function7;
    ucrit_functions(8,:) = ucrit_function8;
    ucrit_functions(9,:) = ucrit_function9;
    ucrit_functions(10,:) = ucrit_function10;
    ucrit_functions(11,:) = ucrit_function11;
    ucrit_functions(12,:) = ucrit_function12;
    ucrit_functions(13,:) = ucrit_function13;
    ucrit_functions(14,:) = ucrit_function14;
    ucrit_functions(15,:) = ucrit_function15;
end
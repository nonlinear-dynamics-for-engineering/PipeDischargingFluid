clc
clear all
close all

fontsize = 22;
fontsizetitle = 18;
fontsizeticks = 13;
markersize = 80;


ucrit_functionsREFread = 'references\reference inextensible vertical 50.csv';
ucrit_functionsREF = dlmread(ucrit_functionsREFread);%creates a matrix out of the data
betavectorREFread = 'references\betavector.csv';
betavectorREF = dlmread(betavectorREFread);%creates a matrix out of the data

% CHANGE THE CORRESPONDENT NUMBERS!!!!!!!!!!!!
ucrit_functions_flutterread = 'Export\ucrit_functions_flutter_121.csv';
ucrit_functions_flutter = dlmread(ucrit_functions_flutterread);%creates a matrix out of the data
ucrit_functions_divergenceread = 'Export\ucrit_functions_divergence_121.csv';
ucrit_functions_divergence = dlmread(ucrit_functions_divergenceread);%creates a matrix out of the data
betavectorread = 'Export\betavector.csv';
betavector = dlmread(betavectorread);%creates a matrix out of the data


colorvector = ["k" "g" "b" "c" "m" "y" "r"];
grayColor = [.4 .4 .4];
fig = figure();
fig.Renderer='Painters';
scatter(betavectorREF,ucrit_functionsREF(1,:),markersize,grayColor,'marker','.','HandleVisibility','on')
hold on
scatter(betavectorREF,ucrit_functionsREF(2,:),markersize,grayColor,'marker','.','HandleVisibility','off')
scatter(betavectorREF,ucrit_functionsREF(3,:),markersize,grayColor,'marker','.','HandleVisibility','off')
scatter(betavectorREF,ucrit_functionsREF(4,:),markersize,grayColor,'marker','.','HandleVisibility','off')
scatter(betavectorREF,ucrit_functionsREF(5,:),markersize,grayColor,'marker','.','HandleVisibility','off')
scatter(betavectorREF,ucrit_functionsREF(6,:),markersize,grayColor,'marker','.','HandleVisibility','off')
scatter(betavectorREF,ucrit_functionsREF(7,:),markersize,grayColor,'marker','.','HandleVisibility','off')

% scatter(betavectorREF,ucrit_functionsREF(91,:),markersize,grayColor,'marker','.','HandleVisibility','on')
% hold on
% scatter(betavectorREF,ucrit_functionsREF(92,:),markersize,grayColor,'marker','.','HandleVisibility','off')
% scatter(betavectorREF,ucrit_functionsREF(93,:),markersize,grayColor,'marker','.','HandleVisibility','off')
% scatter(betavectorREF,ucrit_functionsREF(94,:),markersize,grayColor,'marker','.','HandleVisibility','off')
% scatter(betavectorREF,ucrit_functionsREF(95,:),markersize,grayColor,'marker','.','HandleVisibility','off')
% scatter(betavectorREF,ucrit_functionsREF(96,:),markersize,grayColor,'marker','.','HandleVisibility','off')
% scatter(betavectorREF,ucrit_functionsREF(97,:),markersize,grayColor,'marker','.','HandleVisibility','off')
% scatter(betavectorREF,ucrit_functionsREF(98,:),markersize,grayColor,'marker','.','HandleVisibility','off')
% scatter(betavectorREF,ucrit_functionsREF(99,:),markersize,grayColor,'marker','.','HandleVisibility','off')
% scatter(betavectorREF,ucrit_functionsREF(100,:),markersize,grayColor,'marker','.','HandleVisibility','off')
% scatter(betavectorREF,ucrit_functionsREF(101,:),markersize,grayColor,'marker','.','HandleVisibility','off')
% scatter(betavectorREF,ucrit_functionsREF(102,:),markersize,grayColor,'marker','.','HandleVisibility','off')
% scatter(betavectorREF,ucrit_functionsREF(103,:),markersize,grayColor,'marker','.','HandleVisibility','off')
% scatter(betavectorREF,ucrit_functionsREF(104,:),markersize,grayColor,'marker','.','HandleVisibility','off')
% scatter(betavectorREF,ucrit_functionsREF(105,:),markersize,grayColor,'marker','.','HandleVisibility','off')
for i = 8:8
%     scatter(betavector,ucrit_functions_divergence((i-1)*15-14 + 0,:),markersize,'b','marker','.','HandleVisibility','on')
%     hold on
%     scatter(betavector,ucrit_functions_divergence((i-1)*15-14 + 1,:),markersize,'b','marker','.','HandleVisibility','off')
%     scatter(betavector,ucrit_functions_divergence((i-1)*15-14 + 2,:),markersize,'b','marker','.','HandleVisibility','off')
%     scatter(betavector,ucrit_functions_divergence((i-1)*15-14 + 3,:),markersize,'b','marker','.','HandleVisibility','off')
%     scatter(betavector,ucrit_functions_divergence((i-1)*15-14 + 4,:),markersize,'b','marker','.','HandleVisibility','off')
%     scatter(betavector,ucrit_functions_divergence((i-1)*15-14 + 5,:),markersize,'b','marker','.','HandleVisibility','off')
%     scatter(betavector,ucrit_functions_divergence((i-1)*15-14 + 6,:),markersize,'b','marker','.','HandleVisibility','off')
%     scatter(betavector,ucrit_functions_divergence((i-1)*15-14 + 7,:),markersize,'b','marker','.','HandleVisibility','off')
%     scatter(betavector,ucrit_functions_divergence((i-1)*15-14 + 8,:),markersize,'b','marker','.','HandleVisibility','off')
%     scatter(betavector,ucrit_functions_divergence((i-1)*15-14 + 9,:),markersize,'b','marker','.','HandleVisibility','off')
%     scatter(betavector,ucrit_functions_divergence((i-1)*15-14 + 10,:),markersize,'b','marker','.','HandleVisibility','off')
%     scatter(betavector,ucrit_functions_divergence((i-1)*15-14 + 11,:),markersize,'b','marker','.','HandleVisibility','off')
%     scatter(betavector,ucrit_functions_divergence((i-1)*15-14 + 12,:),markersize,'b','marker','.','HandleVisibility','off')
%     scatter(betavector,ucrit_functions_divergence((i-1)*15-14 + 13,:),markersize,'b','marker','.','HandleVisibility','off')
%     scatter(betavector,ucrit_functions_divergence((i-1)*15-14 + 14,:),markersize,'b','marker','.','HandleVisibility','off')
    
    scatter(betavector,ucrit_functions_flutter((i-1)*15-14 + 0,:),markersize,colorvector(i-1),'marker','.','HandleVisibility','on')
    hold on
    scatter(betavector,ucrit_functions_flutter((i-1)*15-14 + 1,:),markersize,colorvector(i-1),'marker','.','HandleVisibility','off')
    scatter(betavector,ucrit_functions_flutter((i-1)*15-14 + 2,:),markersize,colorvector(i-1),'marker','.','HandleVisibility','off')
    scatter(betavector,ucrit_functions_flutter((i-1)*15-14 + 3,:),markersize,colorvector(i-1),'marker','.','HandleVisibility','off')
    scatter(betavector,ucrit_functions_flutter((i-1)*15-14 + 4,:),markersize,colorvector(i-1),'marker','.','HandleVisibility','off')
    scatter(betavector,ucrit_functions_flutter((i-1)*15-14 + 5,:),markersize,colorvector(i-1),'marker','.','HandleVisibility','off')
    scatter(betavector,ucrit_functions_flutter((i-1)*15-14 + 6,:),markersize,colorvector(i-1),'marker','.','HandleVisibility','off')
    scatter(betavector,ucrit_functions_flutter((i-1)*15-14 + 7,:),markersize,colorvector(i-1),'marker','.','HandleVisibility','off')
    scatter(betavector,ucrit_functions_flutter((i-1)*15-14 + 8,:),markersize,colorvector(i-1),'marker','.','HandleVisibility','off')
    scatter(betavector,ucrit_functions_flutter((i-1)*15-14 + 9,:),markersize,colorvector(i-1),'marker','.','HandleVisibility','off')
    scatter(betavector,ucrit_functions_flutter((i-1)*15-14 + 10,:),markersize,colorvector(i-1),'marker','.','HandleVisibility','off')
    scatter(betavector,ucrit_functions_flutter((i-1)*15-14 + 11,:),markersize,colorvector(i-1),'marker','.','HandleVisibility','off')
    scatter(betavector,ucrit_functions_flutter((i-1)*15-14 + 12,:),markersize,colorvector(i-1),'marker','.','HandleVisibility','off')
    scatter(betavector,ucrit_functions_flutter((i-1)*15-14 + 13,:),markersize,colorvector(i-1),'marker','.','HandleVisibility','off')
    scatter(betavector,ucrit_functions_flutter((i-1)*15-14 + 14,:),markersize,colorvector(i-1),'marker','.','HandleVisibility','off')
end
set(gca,'fontsize',fontsizeticks);

title(['$\gamma$ = ',num2str(50)],'interpreter','latex','Fontsize',fontsizetitle);
%title(['$N_{a}^{} = 3$, $N_{r}^{} = 4$'],'interpreter','latex','Fontsize',fontsizetitle);
xlabel('$\beta$','interpreter','latex','FontSize',fontsize); 
ylabel('$u_{c}$','interpreter','latex','FontSize',fontsize,'rotation',0); 

set(0,'DefaultAxesTitleFontWeight','normal');

ylim([0 30]);

%h = legend('$N_{t}^{} = 2$','$N_{t}^{} = 3$','$N_{t}^{} = 4$','$N_{t}^{} = 5$','$N_{t}^{} = 6$','$N_{t}^{} = 7$','$N_{t}^{} = 8$','Location','northwest');
h = legend('$N = 8$ - Pa\"{i}doussis (1970)','$N_{a}^{} = 3$; $N_{r}^{} = 4$; $N_{t}^{} = 8$ - present model','Location','southeast');
%h = legend('$\kappa_{0}^{} = 0$ ','$\kappa_{0}^{} = 1.45 \pi$; $\bar{\xi}_{T}^{} = 0.5$ - divergence','$\kappa_{0}^{} = 3 \pi$; $\bar{\xi}_{T}^{} = 0.5$ - flutter','Location','northwest');
%h = legend('$\kappa_{0}^{} = 0$ ','$\kappa_{0}^{} = 1.45\pi$; $\bar{\xi}_{T}^{} = 0.5$','Location','northwest');
%h = legend('$\kappa_{2}^{} = 10000$; ','$\kappa_{2}^{} = 5000$','Location','northwest');
%h = legend('$\hat{m}_{n}^{} = 0$; ','$\hat{m}_{n}^{} = 0.2$; $\bar{\xi}_{}^{} = 1.0$','Location','northwest');
%h = legend('$\hat{c}_{x,y,z}^{} = 0$; ','$\hat{m}_{n}^{} = 0.2$; $\bar{\xi}_{}^{} = 1.0$ - divergence','$\hat{m}_{n}^{} = 0.2$; $\bar{\xi}_{}^{} = 1.0$ - flutter','Location','northwest');
set(h,'interpreter','latex')
set(h,'Fontsize',fontsizeticks)

print('Export\Scurves_121',fig,'-dpdf')
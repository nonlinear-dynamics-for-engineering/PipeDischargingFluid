%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% PIPE DISCHARGING FLUID - S-SHAPES CURVES %%%%%%%%%%%%%%%%%
clear all
close all
clc
%% DIMENSIONLESS PARAMETERS
% Dimensionless arclength coordinate
resolution = 1001; % Discretization of the longitudinal axis
shat = linspace(0,1,resolution); % Longitudinal axis
% Relevant dimensionless parameters for the STATIC solutions

gamma = 50; % = (m + M)gL^3/(EIy)
k0 = 0; % = MtL/(GIp)
k1 = 2; % = EIp/(EIy)
k2 = 10000; % = EAL^2/(EIy)
k3 = 0.7; % = GIp/(EIy)
k4 = 0.001; % = EI4/(EIyL^2)
mnhat = 0; % = mn/(m + M)L
xibar = 1.0; % = xbar/L
Chatstheta = 1000; % = (Csx L)/(EIy)
% Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
UseSupportSprings = 0;

% Relevant dimensionless parameters only for the DYNAMIC solutions
Chatsy = 1000; % = (Csy L)/(EIy)
Chatsz = 1000; % = (Csz L)/(EIy)
k5 = 0.001; % = Jp/((m + M)L^2)
Ihat = 1; % = Iz/Iy
chatx = 0.0; % = (cx L^2)/sqrt(EIy(m + M))
chaty = 0.0; % = (cy L^2)/sqrt(EIy(m + M))
chatz = 0.0; % = (cz L^2)/sqrt(EIy(m + M))
chattheta = 0.0; % = ctheta/sqrt(EIy(m + M))
% Numerical integration parameters, number of shape functions and IC
% Number of shape functions
Na = 3; % Number of axial modal shapes
Nr = 4; % Number of torsional modal shapes
%% LOADING OF THE PRE-EVALUATED STATIC SOLUTIONS COEFFICIENTS
% CHANGE THE CORRESPONDENT NUMBERS!!!!!!!!!!!!
StaticSolutions_Coefficients_matrixread = 'library\StaticSolutions_Coefficients_matrix_121.csv';
StaticSolutions_Coefficients_matrix = dlmread(StaticSolutions_Coefficients_matrixread);%creates a matrix out of the data
% Construction of the polynomial modal shapes for the static solutions reconstruction
Nas = 4; % Has to be because the static solutions are already evaluated
Nrs = 4; % Has to be because the static solutions are already evaluated
[numberofdomains,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMS_2_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMSD2_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,RMSD2_2_matrix_polynomial,shat1,shat2] = StaticSolutions_Axial_And_Rotational_Polynomial_Shapes(UseSupportSprings,Nas,Nrs,shat,mnhat,k0,xibar);
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% S-STABILITY CURVES %%%%%%%%%%%%%%%%%%%%%%%%%%%
betaresolution = 1000;
ucrit_functions_all_flutter = nan(105,betaresolution);
ucrit_functions_all_divergence = nan(105,betaresolution);
tic
for Nt = 8:8% Change here for all curves
    disp(Nt)
    % Dynamical modal shapes, do not mix them up
    [AMS_matrix,~,AMSD1_matrix,AMSD2_matrix,RMS_matrix,~,RMSD1_matrix,RMSD2_matrix,TMS_matrix,~,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix] = DynamicalSolutions_Modal_Shapes(UseSupportSprings,Na,Nr,Nt,shat,k2,k3,k5);
    [ucrit_functions,~] = SCurves_flutter(numberofdomains,k0,StaticSolutions_Coefficients_matrix,betaresolution,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2);
    ucrit_functions_all_flutter((Nt-1)*15-14:(Nt-1)*15,:) = ucrit_functions;
    [ucrit_functions,betavector] = SCurves_divergence(numberofdomains,k0,StaticSolutions_Coefficients_matrix,betaresolution,UseSupportSprings,Na,Nr,Nt,shat,k1,k2,k3,k4,mnhat,xibar,Chatstheta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix,AMS_1_matrix_polynomial,AMSD1_1_matrix_polynomial,AMSD2_1_matrix_polynomial,AMSD1_2_matrix_polynomial,AMSD2_2_matrix_polynomial,RMS_1_matrix_polynomial,RMSD1_1_matrix_polynomial,RMS_2_matrix_polynomial,RMSD1_2_matrix_polynomial,shat1,shat2);
    ucrit_functions_all_divergence((Nt-1)*15-14:(Nt-1)*15,:) = ucrit_functions;
end
toc
colorvector = ["r" "g" "b" "c" "m" "y" "k"];

fig = figure();
for i = 8:8
    scatter(betavector,ucrit_functions_all_divergence((i-1)*15-14 + 0,:),'b')
    hold on
    scatter(betavector,ucrit_functions_all_divergence((i-1)*15-14 + 1,:),'b')
    scatter(betavector,ucrit_functions_all_divergence((i-1)*15-14 + 2,:),'b')
    scatter(betavector,ucrit_functions_all_divergence((i-1)*15-14 + 3,:),'b')
    scatter(betavector,ucrit_functions_all_divergence((i-1)*15-14 + 4,:),'b')
    scatter(betavector,ucrit_functions_all_divergence((i-1)*15-14 + 5,:),'b')
    scatter(betavector,ucrit_functions_all_divergence((i-1)*15-14 + 6,:),'b')
    scatter(betavector,ucrit_functions_all_divergence((i-1)*15-14 + 7,:),'b')
    scatter(betavector,ucrit_functions_all_divergence((i-1)*15-14 + 8,:),'b')
    scatter(betavector,ucrit_functions_all_divergence((i-1)*15-14 + 9,:),'b')
    scatter(betavector,ucrit_functions_all_divergence((i-1)*15-14 + 10,:),'b')
    scatter(betavector,ucrit_functions_all_divergence((i-1)*15-14 + 11,:),'b')
    scatter(betavector,ucrit_functions_all_divergence((i-1)*15-14 + 12,:),'b')
    scatter(betavector,ucrit_functions_all_divergence((i-1)*15-14 + 13,:),'b')
    scatter(betavector,ucrit_functions_all_divergence((i-1)*15-14 + 14,:),'b')
    
    scatter(betavector,ucrit_functions_all_flutter((i-1)*15-14 + 0,:),'r')
    scatter(betavector,ucrit_functions_all_flutter((i-1)*15-14 + 1,:),'r')
    scatter(betavector,ucrit_functions_all_flutter((i-1)*15-14 + 2,:),'r')
    scatter(betavector,ucrit_functions_all_flutter((i-1)*15-14 + 3,:),'r')
    scatter(betavector,ucrit_functions_all_flutter((i-1)*15-14 + 4,:),'r')
    scatter(betavector,ucrit_functions_all_flutter((i-1)*15-14 + 5,:),'r')
    scatter(betavector,ucrit_functions_all_flutter((i-1)*15-14 + 6,:),'r')
    scatter(betavector,ucrit_functions_all_flutter((i-1)*15-14 + 7,:),'r')
    scatter(betavector,ucrit_functions_all_flutter((i-1)*15-14 + 8,:),'r')
    scatter(betavector,ucrit_functions_all_flutter((i-1)*15-14 + 9,:),'r')
    scatter(betavector,ucrit_functions_all_flutter((i-1)*15-14 + 10,:),'r')
    scatter(betavector,ucrit_functions_all_flutter((i-1)*15-14 + 11,:),'r')
    scatter(betavector,ucrit_functions_all_flutter((i-1)*15-14 + 12,:),'r')
    scatter(betavector,ucrit_functions_all_flutter((i-1)*15-14 + 13,:),'r')
    scatter(betavector,ucrit_functions_all_flutter((i-1)*15-14 + 14,:),'r')
    

end
ylim([0 30])
% CHANGE THE CORRESPONDENT NUMBERS!!!!!!!!!!!!
dlmwrite('Export\ucrit_functions_flutter_121.csv',ucrit_functions_all_flutter,'delimiter',',','precision',16)
dlmwrite('Export\ucrit_functions_divergence_121.csv',ucrit_functions_all_divergence,'delimiter',',','precision',16)
dlmwrite('Export\betavector.csv',betavector,'delimiter',',','precision',16)
        
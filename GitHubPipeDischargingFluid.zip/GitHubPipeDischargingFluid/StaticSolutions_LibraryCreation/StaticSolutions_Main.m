function [Asnvector,Dsnvector] = StaticSolutions_Main(UseSupportSprings,numberofdomains,Nas,Nrs,gamma,k0,k1,k2,k3,k4,mnhat,Chatstheta,u,MaxIterations_fsolve,MaxFunctionEvaluations_fsolve,AMS_1_matrix,AMSD1_1_matrix,AMSD2_1_matrix,AMS_2_matrix,AMSD1_2_matrix,AMSD2_2_matrix,RMS_1_matrix,RMSD1_1_matrix,RMSD2_1_matrix,RMS_2_matrix,RMSD1_2_matrix,RMSD2_2_matrix,shat1,shat2)
    %% EVALUATION OF THE COEFFICIENTS FOR THE NONLINEAR ALGEBRAIC EQUATIONS 
    [V1s,V2s,V3s,V4s,V5s,V6s,V7s,V8s,V9s,V10s,V11s,V12s,V13s,V14s,V15s,V16s,V17s,V18s,V19s,V20s] = StaticSolutions_Galerkin_Matrices_Evaluation(numberofdomains,UseSupportSprings,shat1,shat2,Nas,Nrs,gamma,k0,k1,k2,k3,k4,u,mnhat,Chatstheta,AMS_1_matrix,AMSD1_1_matrix,AMSD2_1_matrix,AMS_2_matrix,AMSD1_2_matrix,AMSD2_2_matrix,RMS_1_matrix,RMSD1_1_matrix,RMSD2_1_matrix,RMS_2_matrix,RMSD1_2_matrix,RMSD2_2_matrix);
    %% SOLVING THE NONLINEAR SYSTEM OF ALGEBRAIC EQUATIONS - ONE, TWO OR THREE DOMAINS
    %% ONE DOMAIN - Eqn set Is
    if numberofdomains == 1
        %Initial guesses for the gen. coord. - solutions of the linear case
        Gs0 = zeros(1*(Nas + Nrs),1);
        Gs0(1) = (gamma - u^2)/k2;
        Gs0(2) = -gamma/(2*k2);
        Gs0(Nas + 1) = k0;
        if UseSupportSprings == 1
            Gs0(Nas + Nrs) = k0*k3/Chatstheta;
        end
        %Obtaining the solutions
        options = optimoptions('fsolve'); 
        options.MaxIterations = MaxIterations_fsolve;
        options.MaxFunctionEvaluations = MaxFunctionEvaluations_fsolve;
        Gssol = fsolve(@(Gs) StaticSolutions_Nonlinear_Algebraic_Equations_I(Gs,V1s,V2s,V3s,V4s,V5s,V6s,V7s), Gs0,options);
        %Exporting coefficients
        Asnvector = Gssol(1:Nas);
        Dsnvector = Gssol(Nas + 1:Nas + Nrs);
    end
    %% TWO DOMAINS - Eqn set IIs
    if numberofdomains == 2
        %Initial guesses for the gen. coord. - solutions of the linear case
        Gs0 = zeros(2*(Nas + Nrs),1);
        Gs0(1) = (gamma - u^2)/k2;
        Gs0(Nas + 1) = (gamma - u^2)/k2;

        Gs0(2) = -gamma/(2*k2);
        Gs0(Nas + 2) = -gamma/(2*k2);

        Gs0(2*Nas + 1) = k0;
        Gs0(2*Nas + Nrs + 1) = k0;
        if UseSupportSprings == 1
            Gs0(2*Nas + Nrs) = k0*k3/Chatstheta;
        end
        %Obtaining the solutions
        options = optimoptions('fsolve'); 
        options.MaxIterations = MaxIterations_fsolve;
        options.MaxFunctionEvaluations = MaxFunctionEvaluations_fsolve;
        Gssol = fsolve(@(Gs) StaticSolutions_Nonlinear_Algebraic_Equations_II(Gs,V1s,V2s,V3s,V4s,V5s,V6s,V7s,V8s,V9s,V10s,V11s,V12s,V13s,V14s,V15s,V16s,V17s,V18s,V19s,V20s), Gs0,options);
        %Exporting coefficients
        Asnvector = Gssol(1:2*Nas);
        Dsnvector = Gssol(2*Nas + 1:2*Nas + 2*Nrs);
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%% PIPE DISCHARGING FLUID - STATIC SOLUTIONS LIBRARY %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
clc
%% MAIN SETUP
% Dimensionless arclength coordinate
resolution = 1001; % Discretization of the longitudinal axis
shat = linspace(0,1,resolution); % Longitudinal axis
% Relevant dimensionless parameters for the STATIC solutions
for countercaso = 1:14
    if countercaso == 1 %111
        gamma = 0; % = (m + M)gL^3/(EIy)
        k0 = 0; % = MtL/(GIp) 
        xibart = 1.0; % = xbart/L 
        k1 = 2; % = EIp/(EIy)
        k2 = 10000; % = EAL^2/(EIy)
        k3 = 0.7; % = GIp/(EIy)
        k4 = 0.001; % = EI4/(EIyL^2)
        mnhat = 0; % = mn/(m + M)L
        xibar = 0.5; % = xbar/L
        Chatstheta = 1000; % = (Csx L)/(EIy)
        % Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
        UseSupportSprings = 0;
    elseif countercaso == 2 %121
        gamma = 50; % = (m + M)gL^3/(EIy)
        k0 = 0; % = MtL/(GIp)
        xibart = 1.0; % = xbart/L
        k1 = 2; % = EIp/(EIy)
        k2 = 10000; % = EAL^2/(EIy)
        k3 = 0.7; % = GIp/(EIy)
        k4 = 0.001; % = EI4/(EIyL^2)
        mnhat = 0; % = mn/(m + M)L
        xibar = 0.5; % = xbar/L
        Chatstheta = 1000; % = (Csx L)/(EIy)
        % Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
        UseSupportSprings = 0;
    elseif countercaso == 3 %131
        gamma = 0; % = (m + M)gL^3/(EIy)
        k0 = pi/2; % = MtL/(GIp)
        xibart = 1.0; % = xbart/L
        k1 = 2; % = EIp/(EIy)
        k2 = 10000; % = EAL^2/(EIy)
        k3 = 0.7; % = GIp/(EIy)
        k4 = 0.001; % = EI4/(EIyL^2)
        mnhat = 0; % = mn/(m + M)L
        xibar = 0.5; % = xbar/L
        Chatstheta = 1000; % = (Csx L)/(EIy)
        % Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
        UseSupportSprings = 0;
    elseif countercaso == 4 %132
        gamma = 0; % = (m + M)gL^3/(EIy)
        k0 = 3*pi/4; % = MtL/(GIp)
        xibart = 1.0; % = xbart/L
        k1 = 2; % = EIp/(EIy)
        k2 = 10000; % = EAL^2/(EIy)
        k3 = 0.7; % = GIp/(EIy)
        k4 = 0.001; % = EI4/(EIyL^2)
        mnhat = 0; % = mn/(m + M)L
        xibar = 0.5; % = xbar/L
        Chatstheta = 1000; % = (Csx L)/(EIy)
        % Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
        UseSupportSprings = 0;
    elseif countercaso == 5 %133
        gamma = 0; % = (m + M)gL^3/(EIy)
        k0 = 4*pi/5; % = MtL/(GIp)
        xibart = 1.0; % = xbart/L
        k1 = 2; % = EIp/(EIy)
        k2 = 10000; % = EAL^2/(EIy)
        k3 = 0.7; % = GIp/(EIy)
        k4 = 0.001; % = EI4/(EIyL^2)
        mnhat = 0; % = mn/(m + M)L
        xibar = 0.5; % = xbar/L
        Chatstheta = 1000; % = (Csx L)/(EIy)
        % Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
        UseSupportSprings = 0;
    elseif countercaso == 6 %134
        gamma = 0; % = (m + M)gL^3/(EIy)
        k0 = 3*pi/2; % = MtL/(GIp)
        xibart = 1.0; % = xbart/L
        k1 = 2; % = EIp/(EIy)
        k2 = 10000; % = EAL^2/(EIy)
        k3 = 0.7; % = GIp/(EIy)
        k4 = 0.001; % = EI4/(EIyL^2)
        mnhat = 0; % = mn/(m + M)L
        xibar = 0.5; % = xbar/L
        Chatstheta = 1000; % = (Csx L)/(EIy)
        % Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
        UseSupportSprings = 0;
    elseif countercaso == 7 %135
        gamma = 0; % = (m + M)gL^3/(EIy)
        k0 = pi; % = MtL/(GIp)
        xibart = 0.5; % = xbart/L
        k1 = 2; % = EIp/(EIy)
        k2 = 10000; % = EAL^2/(EIy)
        k3 = 0.7; % = GIp/(EIy)
        k4 = 0.001; % = EI4/(EIyL^2)
        mnhat = 0; % = mn/(m + M)L
        xibar = 0.5; % = xbar/L
        Chatstheta = 1000; % = (Csx L)/(EIy)
        % Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
        UseSupportSprings = 0;
    elseif countercaso == 8 %136
        gamma = 0; % = (m + M)gL^3/(EIy)
        k0 = 6*pi/4; % = MtL/(GIp)
        xibart = 0.5; % = xbart/L
        k1 = 2; % = EIp/(EIy)
        k2 = 10000; % = EAL^2/(EIy)
        k3 = 0.7; % = GIp/(EIy)
        k4 = 0.001; % = EI4/(EIyL^2)
        mnhat = 0; % = mn/(m + M)L
        xibar = 0.5; % = xbar/L
        Chatstheta = 1000; % = (Csx L)/(EIy)
        % Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
        UseSupportSprings = 0;
    elseif countercaso == 9 %137
        gamma = 0; % = (m + M)gL^3/(EIy)
        k0 = 8*pi/5; % = MtL/(GIp)
        xibart = 0.5; % = xbart/L
        k1 = 2; % = EIp/(EIy)
        k2 = 10000; % = EAL^2/(EIy)
        k3 = 0.7; % = GIp/(EIy)
        k4 = 0.001; % = EI4/(EIyL^2)
        mnhat = 0; % = mn/(m + M)L
        xibar = 0.5; % = xbar/L
        Chatstheta = 1000; % = (Csx L)/(EIy)
        % Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
        UseSupportSprings = 0;
    elseif countercaso == 10 %138
        gamma = 0; % = (m + M)gL^3/(EIy)
        k0 = 6*pi/2; % = MtL/(GIp)
        xibart = 0.5; % = xbart/L
        k1 = 2; % = EIp/(EIy)
        k2 = 10000; % = EAL^2/(EIy)
        k3 = 0.7; % = GIp/(EIy)
        k4 = 0.001; % = EI4/(EIyL^2)
        mnhat = 0; % = mn/(m + M)L
        xibar = 0.5; % = xbar/L
        Chatstheta = 1000; % = (Csx L)/(EIy)
        % Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
        UseSupportSprings = 0;
    elseif countercaso == 11 %141
        gamma = 0; % = (m + M)gL^3/(EIy)
        k0 = 0; % = MtL/(GIp)  
        xibart = 1.0; % = xbart/L
        k1 = 2; % = EIp/(EIy)
        k2 = 5000; % = EAL^2/(EIy)
        k3 = 0.7; % = GIp/(EIy)
        k4 = 0.001; % = EI4/(EIyL^2)
        mnhat = 0; % = mn/(m + M)L
        xibar = 0.5; % = xbar/L
        Chatstheta = 1000; % = (Csx L)/(EIy)
        % Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
        UseSupportSprings = 0;
    elseif countercaso == 12 %142
        gamma = 0; % = (m + M)gL^3/(EIy)
        k0 = 0; % = MtL/(GIp)  
        xibart = 1.0; % = xbart/L
        k1 = 2; % = EIp/(EIy)
        k2 = 1000; % = EAL^2/(EIy)
        k3 = 0.7; % = GIp/(EIy)
        k4 = 0.001; % = EI4/(EIyL^2)
        mnhat = 0; % = mn/(m + M)L
        xibar = 0.5; % = xbar/L
        Chatstheta = 1000; % = (Csx L)/(EIy)
        % Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
        UseSupportSprings = 0;
    elseif countercaso == 13 %151
        gamma = 0; % = (m + M)gL^3/(EIy)
        k0 = 0; % = MtL/(GIp)  
        xibart = 1.0; % = xbart/L
        k1 = 2; % = EIp/(EIy)
        k2 = 10000; % = EAL^2/(EIy) 
        k3 = 0.7; % = GIp/(EIy)
        k4 = 0.001; % = EI4/(EIyL^2)
        mnhat = 0.2; % = mn/(m + M)L
        xibar = 0.5; % = xbar/L
        Chatstheta = 1000; % = (Csx L)/(EIy) 
        % Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
        UseSupportSprings = 0;
    elseif countercaso == 14 %152
        gamma = 0; % = (m + M)gL^3/(EIy)
        k0 = 0; % = MtL/(GIp)  
        xibart = 1.0; % = xbart/L
        k1 = 2; % = EIp/(EIy)
        k2 = 10000; % = EAL^2/(EIy) 
        k3 = 0.7; % = GIp/(EIy)
        k4 = 0.001; % = EI4/(EIyL^2)
        mnhat = 0.2; % = mn/(m + M)L
        xibar = 1.0; % = xbar/L
        Chatstheta = 1000; % = (Csx L)/(EIy) 
        % Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
        UseSupportSprings = 0;
    end
    %% AXIAL AND TORSIONAL STATIC SOLUTIONS
    % Number of shapes in each static solution
    Nas = 4; % Number of axial shapes for the static configuration
    Nrs = 4; % Number of torsional shapes for the static configuration
    % Solver options for the fsolve and solution evaluation
    MaxIterations_fsolve = 400; %400 is default
    MaxFunctionEvaluations_fsolve = 2000; %2000 is default
    % Polynomial shapes and derivatives
    [casenumber,AMS_1_matrix,AMSD1_1_matrix,AMSD2_1_matrix,AMS_2_matrix,AMSD1_2_matrix,AMSD2_2_matrix,AMS_3_matrix,AMSD1_3_matrix,AMSD2_3_matrix,RMS_1_matrix,RMSD1_1_matrix,RMSD2_1_matrix,RMS_2_matrix,RMSD1_2_matrix,RMSD2_2_matrix,RMS_3_matrix,RMSD1_3_matrix,RMSD2_3_matrix,shat1,shat2,shat3] = StaticSolutions_Axial_And_Rotational_Polynomial_Shapes(UseSupportSprings,Nas,Nrs,shat,mnhat,xibar,k0,xibart);
    countercaso
    %% LOOP u variation with fixed k0
    disp('______________________________________________________')
    disp('______________________________________________________')
    disp('EVALUATING THE MAIN LOOP VARYING u...')
    disp('______________________________________________________')
    disp('______________________________________________________')
    tmainloop = tic; 
    uvector = 0.01:0.01:30;

    if casenumber==111 || casenumber==211 || casenumber==311 || casenumber==411 %Cases with one domain
        StaticSolutions_Coefficients_matrix = zeros(length(uvector),(Nas + Nrs + 1)); %[Asn,Dsn,u]
        for ucont = 1:length(uvector)
            u = uvector(ucont)
            [Asnvector,Dsnvector] = StaticSolutions_Main(UseSupportSprings,Nas,Nrs,shat,gamma,k0,xibart,k1,k2,k3,k4,mnhat,xibar,Chatstheta,u,MaxIterations_fsolve,MaxFunctionEvaluations_fsolve,casenumber,AMS_1_matrix,AMSD1_1_matrix,AMSD2_1_matrix,AMS_2_matrix,AMSD1_2_matrix,AMSD2_2_matrix,AMS_3_matrix,AMSD1_3_matrix,AMSD2_3_matrix,RMS_1_matrix,RMSD1_1_matrix,RMSD2_1_matrix,RMS_2_matrix,RMSD1_2_matrix,RMSD2_2_matrix,RMS_3_matrix,RMSD1_3_matrix,RMSD2_3_matrix,shat1,shat2,shat3);
            StaticSolutions_Coefficients_matrix(ucont,1:Nas) = Asnvector;
            StaticSolutions_Coefficients_matrix(ucont,(Nas + 1):(Nas + Nrs)) = Dsnvector;
            StaticSolutions_Coefficients_matrix(ucont,Nas + Nrs + 1) = u;
        end
    elseif casenumber==221 || casenumber==321 || casenumber==421 || casenumber==422 || casenumber==423 %Cases with two domains
        StaticSolutions_Coefficients_matrix = zeros(length(uvector),(2*Nas + 2*Nrs + 1)); %[A_1sn,A_2sn,D_1sn,D_2sn,u]
        for ucont = 1:length(uvector)
            u = uvector(ucont)
            [Asnvector,Dsnvector] = StaticSolutions_Main(UseSupportSprings,Nas,Nrs,shat,gamma,k0,xibart,k1,k2,k3,k4,mnhat,xibar,Chatstheta,u,MaxIterations_fsolve,MaxFunctionEvaluations_fsolve,casenumber,AMS_1_matrix,AMSD1_1_matrix,AMSD2_1_matrix,AMS_2_matrix,AMSD1_2_matrix,AMSD2_2_matrix,AMS_3_matrix,AMSD1_3_matrix,AMSD2_3_matrix,RMS_1_matrix,RMSD1_1_matrix,RMSD2_1_matrix,RMS_2_matrix,RMSD1_2_matrix,RMSD2_2_matrix,RMS_3_matrix,RMSD1_3_matrix,RMSD2_3_matrix,shat1,shat2,shat3);
            StaticSolutions_Coefficients_matrix(ucont,1:2*Nas) = Asnvector;
            StaticSolutions_Coefficients_matrix(ucont,(2*Nas + 1):2*(Nas + Nrs)) = Dsnvector;
            StaticSolutions_Coefficients_matrix(ucont,2*Nas + 2*Nrs + 1) = u;
        end
    elseif casenumber==431 || casenumber==432 %Cases with three domains
        StaticSolutions_Coefficients_matrix = zeros(length(uvector),(3*Nas + 3*Nrs + 1)); %[A_1sn,A_2sn,A_3sn,D_1sn,D_2sn,D_3sn,u]
        for ucont = 1:length(uvector)
            u = uvector(ucont)
            [Asnvector,Dsnvector] = StaticSolutions_Main(UseSupportSprings,Nas,Nrs,shat,gamma,k0,xibart,k1,k2,k3,k4,mnhat,xibar,Chatstheta,u,MaxIterations_fsolve,MaxFunctionEvaluations_fsolve,casenumber,AMS_1_matrix,AMSD1_1_matrix,AMSD2_1_matrix,AMS_2_matrix,AMSD1_2_matrix,AMSD2_2_matrix,AMS_3_matrix,AMSD1_3_matrix,AMSD2_3_matrix,RMS_1_matrix,RMSD1_1_matrix,RMSD2_1_matrix,RMS_2_matrix,RMSD1_2_matrix,RMSD2_2_matrix,RMS_3_matrix,RMSD1_3_matrix,RMSD2_3_matrix,shat1,shat2,shat3);
            StaticSolutions_Coefficients_matrix(ucont,1:3*Nas) = Asnvector;
            StaticSolutions_Coefficients_matrix(ucont,(3*Nas + 1):3*(Nas + Nrs)) = Dsnvector;
            StaticSolutions_Coefficients_matrix(ucont,3*Nas + 3*Nrs + 1) = u;
        end
    end
    %% CSV EXPORTS
    if countercaso == 1 %111
        dlmwrite('library\StaticSolutions_Coefficients_matrix_111.csv',StaticSolutions_Coefficients_matrix,'delimiter',',','precision',16)
    elseif countercaso == 2 %121
        dlmwrite('library\StaticSolutions_Coefficients_matrix_121.csv',StaticSolutions_Coefficients_matrix,'delimiter',',','precision',16)
    elseif countercaso == 3 %131
        dlmwrite('library\StaticSolutions_Coefficients_matrix_131.csv',StaticSolutions_Coefficients_matrix,'delimiter',',','precision',16)
    elseif countercaso == 4 %132
        dlmwrite('library\StaticSolutions_Coefficients_matrix_132.csv',StaticSolutions_Coefficients_matrix,'delimiter',',','precision',16)
    elseif countercaso == 5 %133
        dlmwrite('library\StaticSolutions_Coefficients_matrix_133.csv',StaticSolutions_Coefficients_matrix,'delimiter',',','precision',16)
    elseif countercaso == 6 %134
        dlmwrite('library\StaticSolutions_Coefficients_matrix_134.csv',StaticSolutions_Coefficients_matrix,'delimiter',',','precision',16)
    elseif countercaso == 7 %135
        dlmwrite('library\StaticSolutions_Coefficients_matrix_135.csv',StaticSolutions_Coefficients_matrix,'delimiter',',','precision',16)
    elseif countercaso == 8 %136
        dlmwrite('library\StaticSolutions_Coefficients_matrix_136.csv',StaticSolutions_Coefficients_matrix,'delimiter',',','precision',16)
    elseif countercaso == 9 %137
        dlmwrite('library\StaticSolutions_Coefficients_matrix_137.csv',StaticSolutions_Coefficients_matrix,'delimiter',',','precision',16)
    elseif countercaso == 10 %138
        dlmwrite('library\StaticSolutions_Coefficients_matrix_138.csv',StaticSolutions_Coefficients_matrix,'delimiter',',','precision',16)
    elseif countercaso == 11 %141
        dlmwrite('library\StaticSolutions_Coefficients_matrix_141.csv',StaticSolutions_Coefficients_matrix,'delimiter',',','precision',16)
    elseif countercaso == 12 %142
        dlmwrite('library\StaticSolutions_Coefficients_matrix_142.csv',StaticSolutions_Coefficients_matrix,'delimiter',',','precision',16)
    elseif countercaso == 13 %151
        dlmwrite('library\StaticSolutions_Coefficients_matrix_151.csv',StaticSolutions_Coefficients_matrix,'delimiter',',','precision',16)
    elseif countercaso == 14 %152
        dlmwrite('library\StaticSolutions_Coefficients_matrix_152.csv',StaticSolutions_Coefficients_matrix,'delimiter',',','precision',16)
    end
end
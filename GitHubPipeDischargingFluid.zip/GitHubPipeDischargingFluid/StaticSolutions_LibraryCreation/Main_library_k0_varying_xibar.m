%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%% PIPE DISCHARGING FLUID - STATIC SOLUTIONS LIBRARY %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
clc
%% MAIN SETUP
% Dimensionless arclength coordinate
resolution = 1001; % Discretization of the longitudinal axis
shat = linspace(0,1,resolution); % Longitudinal axis
% Relevant dimensionless parameters for the STATIC solutions

mnhat = 0; % = mn/(m + M)L
u = 0;
gamma = 0; % = (m + M)gL^3/(EIy)
k1 = 2; % = EIp/(EIy)
k2 = 10000; % = EAL^2/(EIy)
k3 = 0.7; % = GIp/(EIy)
k4 = 0.001; % = EI4/(EIyL^2)
Chatstheta = 1000; % = (Csx L)/(EIy)
% Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC. Also affects the initial guess for the fsolve.
UseSupportSprings = 0;
%% AXIAL AND TORSIONAL STATIC SOLUTIONS
% Number of shapes in each static solution
Nas = 4; % Number of axial shapes for the static configuration
Nrs = 4; % Number of torsional shapes for the static configuration
% Solver options for the fsolve and solution evaluation
MaxIterations_fsolve = 400; %400 is default
MaxFunctionEvaluations_fsolve = 2000; %2000 is default
%% MAIN LOOPS VARYING K0 AND XIBAR
disp('______________________________________________________')
disp('______________________________________________________')
disp('EVALUATING THE MAIN LOOP VARYING k0 and xibar...')
disp('______________________________________________________')
disp('______________________________________________________')
k0vector = 0:0.01*pi:5*pi;
xibarvector = 0.01:0.01:1;

StaticSolutions_Coefficients_matrix = zeros(length(k0vector),length(xibarvector),(2*Nas + 2*Nrs + 2)); %[A_1sn,A_2sn,D_1sn,D_2sn,k0,xibar] %A_2sn = D_2sn = 0 in the case of only one domain
tmainloop = tic; 
for xibarcont = 1:length(xibarvector)
    
xibar = xibarvector(xibarcont);
% Polynomial shapes and derivatives
k0 = 1;% JUST TO GET THE CORRECT SHAPE FUNCTIONS
[numberofdomains,AMS_1_matrix,AMSD1_1_matrix,AMSD2_1_matrix,AMS_2_matrix,AMSD1_2_matrix,AMSD2_2_matrix,RMS_1_matrix,RMSD1_1_matrix,RMSD2_1_matrix,RMS_2_matrix,RMSD1_2_matrix,RMSD2_2_matrix,shat1,shat2] = StaticSolutions_Axial_And_Rotational_Polynomial_Shapes(UseSupportSprings,Nas,Nrs,shat,mnhat,k0,xibar);


if numberofdomains == 1 %Cases with one domain
    for k0cont = 1:length(k0vector)
        k0cont
        k0 = k0vector(k0cont);
        [Asnvector,Dsnvector] = StaticSolutions_Main(UseSupportSprings,numberofdomains,Nas,Nrs,gamma,k0,k1,k2,k3,k4,mnhat,Chatstheta,u,MaxIterations_fsolve,MaxFunctionEvaluations_fsolve,AMS_1_matrix,AMSD1_1_matrix,AMSD2_1_matrix,AMS_2_matrix,AMSD1_2_matrix,AMSD2_2_matrix,RMS_1_matrix,RMSD1_1_matrix,RMSD2_1_matrix,RMS_2_matrix,RMSD1_2_matrix,RMSD2_2_matrix,shat1,shat2);
        StaticSolutions_Coefficients_matrix(k0cont,xibarcont,1:Nas) = Asnvector;
        StaticSolutions_Coefficients_matrix(k0cont,xibarcont,(2*Nas + 1):2*Nas + Nrs) = Dsnvector;
        StaticSolutions_Coefficients_matrix(k0cont,xibarcont,2*Nas + 2*Nrs + 1) = k0;
        StaticSolutions_Coefficients_matrix(k0cont,xibarcont,2*Nas + 2*Nrs + 2) = xibar;
    end
elseif numberofdomains == 2 %Cases with two domains
    for k0cont = 1:length(k0vector)
        k0cont
        k0 = k0vector(k0cont);
        [Asnvector,Dsnvector] = StaticSolutions_Main(UseSupportSprings,numberofdomains,Nas,Nrs,gamma,k0,k1,k2,k3,k4,mnhat,Chatstheta,u,MaxIterations_fsolve,MaxFunctionEvaluations_fsolve,AMS_1_matrix,AMSD1_1_matrix,AMSD2_1_matrix,AMS_2_matrix,AMSD1_2_matrix,AMSD2_2_matrix,RMS_1_matrix,RMSD1_1_matrix,RMSD2_1_matrix,RMS_2_matrix,RMSD1_2_matrix,RMSD2_2_matrix,shat1,shat2);
        StaticSolutions_Coefficients_matrix(k0cont,xibarcont,1:2*Nas) = Asnvector;
        StaticSolutions_Coefficients_matrix(k0cont,xibarcont,(2*Nas + 1):2*(Nas + Nrs)) = Dsnvector;
        StaticSolutions_Coefficients_matrix(k0cont,xibarcont,2*Nas + 2*Nrs + 1) = k0;
        StaticSolutions_Coefficients_matrix(k0cont,xibarcont,2*Nas + 2*Nrs + 2) = xibar;
    end
end
toc(tmainloop);
%CHANGE THE CORRESPONDENT NUMBERS!!!!!!!!!!!!
dlmwrite('libraryforrootloci\StaticSolutions_Coefficients_matrix_k0_xibar.csv',StaticSolutions_Coefficients_matrix,'delimiter',',','precision',16)
end
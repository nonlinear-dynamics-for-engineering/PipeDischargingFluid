function [V1s,V2s,V3s,V4s,V5s,V6s,V7s,V8s,V9s,V10s,V11s,V12s,V13s,V14s,V15s,V16s,V17s,V18s,V19s,V20s] = StaticSolutions_Galerkin_Matrices_Evaluation(numberofdomains,UseSupportSprings,shat1,shat2,Nas,Nrs,gamma,k0,k1,k2,k3,k4,u,mnhat,Chatstheta,AMS_1_matrix,AMSD1_1_matrix,AMSD2_1_matrix,AMS_2_matrix,AMSD1_2_matrix,AMSD2_2_matrix,RMS_1_matrix,RMSD1_1_matrix,RMSD2_1_matrix,RMS_2_matrix,RMSD1_2_matrix,RMSD2_2_matrix)
    disp('------------------------------------------------------')
    tic
    if numberofdomains == 1
        disp('Evaluating Galerkin Matrices Coefficients For Eqn Set Number Is...');
        %% COEFFICIENTS - EQUATIONS FOR Asn_1
        V1s = zeros(Nas,Nas);
        for k = 1:Nas
            for n = 1:Nas
                V1s(k,n) = k2*trapz(shat1,AMSD2_1_matrix(n,:).*AMS_1_matrix(k,:)) ...
                    - k2*AMSD1_1_matrix(n,end)*AMS_1_matrix(k,end);
            end
        end
        V2s = zeros(Nas,Nrs,Nrs);
        for k = 1:Nas
            for n = 1:Nrs
                for m = 1:Nrs
                    V2s(k,n,m) = k1*trapz(shat1,RMSD1_1_matrix(n,:).*RMSD2_1_matrix(m,:).*AMS_1_matrix(k,:)) ...
                        - (1/2)*k1*RMSD1_1_matrix(n,end)*RMSD1_1_matrix(m,end)*AMS_1_matrix(k,end);
                end
            end
        end
        V3s = zeros(Nas,1);
        for k = 1:Nas
            V3s(k) = gamma*trapz(shat1,AMS_1_matrix(k,:)) ...
                + gamma*mnhat*AMS_1_matrix(k,end) ...
                - (u^2)*AMS_1_matrix(k,end);
        end
        %% COEFFICIENTS - EQUATIONS FOR Dsn_1
        V4s = zeros(Nrs,Nas,Nrs);
        for k = 1:Nrs
            for n = 1:Nas
                for m = 1:Nrs
                    V4s(k,n,m) = k1*trapz(shat1,Numerical_Derivative(AMSD1_1_matrix(n,:).*RMSD1_1_matrix(m,:),shat1).*RMS_1_matrix(k,:)) ...
                        - k1*AMSD1_1_matrix(n,end)*RMSD1_1_matrix(m,end)*RMS_1_matrix(k,end) ...
                        + UseSupportSprings*k1*AMSD1_1_matrix(n,1)*RMSD1_1_matrix(m,1)*RMS_1_matrix(k,1);
                end
            end
        end
        V5s = zeros(Nrs,Nrs,Nrs,Nrs);
        for k = 1:Nrs
            for n = 1:Nrs
                for m = 1:Nrs
                    for p = 1:Nrs
                        V5s(k,n,m,p) = (1/2)*k4*trapz(shat1,Numerical_Derivative(RMSD1_1_matrix(n,:).*RMSD1_1_matrix(m,:).*RMSD1_1_matrix(p,:),shat1).*RMS_1_matrix(k,:)) ...
                            - (1/2)*k4*RMSD1_1_matrix(n,end)*RMSD1_1_matrix(m,end)*RMSD1_1_matrix(p,end)*RMS_1_matrix(k,end) ...
                            + UseSupportSprings*(1/2)*k4*RMSD1_1_matrix(n,1)*RMSD1_1_matrix(m,1)*RMSD1_1_matrix(p,1)*RMS_1_matrix(k,1);
                    end
                end
            end
        end
        V6s = zeros(Nrs,Nrs);
        for k = 1:Nrs
            for n = 1:Nrs
                V6s(k,n) = k3*trapz(shat1,RMSD2_1_matrix(n,:).*RMS_1_matrix(k,:)) ...
                    - k3*RMSD1_1_matrix(n,end)*RMS_1_matrix(k,end) ...
                    + UseSupportSprings*k3*RMSD1_1_matrix(n,1)*RMS_1_matrix(k,1) ...
                    - UseSupportSprings*Chatstheta*RMS_1_matrix(n,1)*RMS_1_matrix(k,1);
            end
        end
        V7s = zeros(Nrs,Nrs);
        for k = 1:Nrs
            V7s(k) = k0*k3*RMS_1_matrix(k,end);
        end
        V8s = nan; %Only for the export
        V9s = nan; %Only for the export
        V10s = nan; %Only for the export
        V11s = nan; %Only for the export
        V12s = nan; %Only for the export
        V13s = nan; %Only for the export
        V14s = nan; %Only for the export
        V15s = nan; %Only for the export
        V16s = nan; %Only for the export
        V17s = nan; %Only for the export
        V18s = nan; %Only for the export
        V19s = nan; %Only for the export
        V20s = nan; %Only for the export
    end
    if numberofdomains == 2
        disp('Evaluating Galerkin Matrices Coefficients For Eqn Set Number IIs...');
        %% COEFFICIENTS - EQUATIONS FOR Asn_1
        V1s = zeros(Nas,Nas);
        for k = 1:Nas
            for n = 1:Nas
                V1s(k,n) = k2*trapz(shat1,AMSD2_1_matrix(n,:).*AMS_1_matrix(k,:)) ...
                    - k2*AMSD1_1_matrix(n,end)*AMS_1_matrix(k,end);
            end
        end
        V2s = zeros(Nas,Nrs,Nrs);
        for k = 1:Nas
            for n = 1:Nrs
                for m = 1:Nrs
                    V2s(k,n,m) = k1*trapz(shat1,RMSD1_1_matrix(n,:).*RMSD2_1_matrix(m,:).*AMS_1_matrix(k,:)) ...
                        - (1/2)*k1*RMSD1_1_matrix(n,end)*RMSD1_1_matrix(m,end)*AMS_1_matrix(k,end);
                end
            end
        end
        V3s = zeros(Nas,Nas);
        for k = 1:Nas
            for n = 1:Nas
                V3s(k,n) = k2*AMSD1_2_matrix(n,1)*AMS_1_matrix(k,end);
            end
        end
        V4s = zeros(Nas,Nrs,Nrs);
        for k = 1:Nas
            for n = 1:Nrs
                for m = 1:Nrs
                    V4s(k,n,m) = (1/2)*k1*RMSD1_2_matrix(n,1)*RMSD1_2_matrix(m,1)*AMS_1_matrix(k,end);
                end
            end
        end
        V5s = zeros(Nas,1);
        for k = 1:Nas
            V5s(k) = gamma*trapz(shat1,AMS_1_matrix(k,:)) ...
                + gamma*mnhat*AMS_1_matrix(k,end);
        end
        %% COEFFICIENTS - EQUATIONS FOR Asn_2
        V6s = zeros(Nas,Nas);
        for k = 1:Nas
            for n = 1:Nas
                V6s(k,n) = k2*trapz(shat2,AMSD2_2_matrix(n,:).*AMS_2_matrix(k,:)) ...
                    + k2*AMSD1_2_matrix(n,1)*AMS_2_matrix(k,1) ...
                    - k2*AMSD1_2_matrix(n,end)*AMS_2_matrix(k,end);
            end
        end
        V7s = zeros(Nas,Nrs,Nrs);
        for k = 1:Nas
            for n = 1:Nrs
                for m = 1:Nrs
                    V7s(k,n,m) = k1*trapz(shat2,RMSD1_2_matrix(n,:).*RMSD2_2_matrix(m,:).*AMS_2_matrix(k,:)) ...
                        + (1/2)*k1*RMSD1_2_matrix(n,1)*RMSD1_2_matrix(m,1)*AMS_2_matrix(k,1) ...
                        - (1/2)*k1*RMSD1_2_matrix(n,end)*RMSD1_2_matrix(m,end)*AMS_2_matrix(k,end);
                end
            end
        end
        V8s = nan; %Only for the export
        V9s = nan; %Only for the export
        V10s = zeros(Nas,1);
        for k = 1:Nas
            V10s(k) = gamma*trapz(shat2,AMS_2_matrix(k,:)) ...
                - (u^2)*AMS_2_matrix(k,end);
        end
        %% COEFFICIENTS - EQUATIONS FOR Dsn_1
        V11s = zeros(Nrs,Nas,Nrs);
        for k = 1:Nrs
            for n = 1:Nas
                for m = 1:Nrs
                    V11s(k,n,m) = k1*trapz(shat1,Numerical_Derivative(AMSD1_1_matrix(n,:).*RMSD1_1_matrix(m,:),shat1).*RMS_1_matrix(k,:)) ...
                        - k1*AMSD1_1_matrix(n,end)*RMSD1_1_matrix(m,end)*RMS_1_matrix(k,end) ...
                        + UseSupportSprings*k1*AMSD1_1_matrix(n,1)*RMSD1_1_matrix(m,1)*RMS_1_matrix(k,1);
                end
            end
        end
        V12s = zeros(Nrs,Nrs,Nrs,Nrs);
        for k = 1:Nrs
            for n = 1:Nrs
                for m = 1:Nrs
                    for p = 1:Nrs
                        V12s(k,n,m,p) = (1/2)*k4*trapz(shat1,Numerical_Derivative(RMSD1_1_matrix(n,:).*RMSD1_1_matrix(m,:).*RMSD1_1_matrix(p,:),shat1).*RMS_1_matrix(k,:)) ...
                            - (1/2)*k4*RMSD1_1_matrix(n,end)*RMSD1_1_matrix(m,end)*RMSD1_1_matrix(p,end)*RMS_1_matrix(k,end) ...
                            + UseSupportSprings*(1/2)*k4*RMSD1_1_matrix(n,1)*RMSD1_1_matrix(m,1)*RMSD1_1_matrix(p,1)*RMS_1_matrix(k,1);
                    end
                end
            end
        end
        V13s = zeros(Nrs,Nrs);
        for k = 1:Nrs
            for n = 1:Nrs
                V13s(k,n) = k3*trapz(shat1,RMSD2_1_matrix(n,:).*RMS_1_matrix(k,:)) ...
                    - k3*RMSD1_1_matrix(n,end)*RMS_1_matrix(k,end) ...
                    + UseSupportSprings*k3*RMSD1_1_matrix(n,1)*RMS_1_matrix(k,1) ...
                    - UseSupportSprings*Chatstheta*RMS_1_matrix(n,1)*RMS_1_matrix(k,1);
            end
        end
        V14s = zeros(Nrs,Nas,Nrs);
        for k = 1:Nrs
            for n = 1:Nas
                for m = 1:Nrs
                    V14s(k,n,m) = k1*AMSD1_2_matrix(n,1)*RMSD1_2_matrix(m,1)*RMS_1_matrix(k,end);
                end
            end
        end
        V15s = zeros(Nrs,Nrs,Nrs,Nrs);
        for k = 1:Nrs
            for n = 1:Nrs
                for m = 1:Nrs
                    for p = 1:Nrs
                        V15s(k,n,m,p) = (1/2)*k4*RMSD1_2_matrix(n,1)*RMSD1_2_matrix(m,1)*RMSD1_2_matrix(p,1)*RMS_1_matrix(k,end);
                    end
                end
            end
        end
        V16s = zeros(Nrs,Nrs);
        for k = 1:Nrs
            for n = 1:Nrs
                V16s(k,n) = k3*RMSD1_2_matrix(n,1)*RMS_1_matrix(k,end);
            end
        end
        V17s = zeros(Nrs,Nrs);
        for k = 1:Nrs
            V17s(k) = k0*k3*RMS_1_matrix(k,end);
        end
        %% COEFFICIENTS - EQUATIONS FOR Dsn_2
        V18s = zeros(Nrs,Nas,Nrs);
        for k = 1:Nrs
            for n = 1:Nas
                for m = 1:Nrs
                    V18s(k,n,m) = k1*trapz(shat2,Numerical_Derivative(AMSD1_2_matrix(n,:).*RMSD1_2_matrix(m,:),shat2).*RMS_2_matrix(k,:)) ...
                        + k1*AMSD1_2_matrix(n,1)*RMSD1_2_matrix(m,1)*RMS_2_matrix(k,1) ...
                        - k1*AMSD1_2_matrix(n,end)*RMSD1_2_matrix(m,end)*RMS_2_matrix(k,end);
                end
            end
        end
        V19s = zeros(Nrs,Nrs,Nrs,Nrs);
        for k = 1:Nrs
            for n = 1:Nrs
                for m = 1:Nrs
                    for p = 1:Nrs
                        V19s(k,n,m,p) = (1/2)*k4*trapz(shat2,Numerical_Derivative(RMSD1_2_matrix(n,:).*RMSD1_2_matrix(m,:).*RMSD1_2_matrix(p,:),shat2).*RMS_2_matrix(k,:)) ...
                            + (1/2)*k4*RMSD1_2_matrix(n,1)*RMSD1_2_matrix(m,1)*RMSD1_2_matrix(p,1)*RMS_2_matrix(k,1) ...
                            - (1/2)*k4*RMSD1_2_matrix(n,end)*RMSD1_2_matrix(m,end)*RMSD1_2_matrix(p,end)*RMS_2_matrix(k,end);
                    end
                end
            end
        end
        V20s = zeros(Nrs,Nrs);
        for k = 1:Nrs
            for n = 1:Nrs
                V20s(k,n) = k3*trapz(shat2,RMSD2_2_matrix(n,:).*RMS_2_matrix(k,:)) ...
                    + k3*RMSD1_2_matrix(n,1)*RMS_2_matrix(k,1) ...
                    - k3*RMSD1_2_matrix(n,end)*RMS_2_matrix(k,end);
            end
        end
    end
    toc
end
using DelimitedFiles

cd(@__DIR__)
Nas = 4
Nrs = 4

name = "StaticSolutions_Nonlinear_Algebraic_Equations_II.m"
file = open(name,"w") # w -> write

write(file,"function Nonlinear_Algebraic_Equations_Value_Vector = StaticSolutions_Nonlinear_Algebraic_Equations_II(Gs,V1s,V2s,V3s,V4s,V5s,V6s,V7s,V8s,V9s,V10s,V11s,V12s,V13s,V14s,V15s,V16s,V17s,V18s,V19s,V20s) \r\n") #\r -> indicate the end of lines; \n -> break line

#Writing the generalized coordinates Asn and Dsn using the correspondent vector Gs
for k = 1:Nas
    write(file,"A_1s$k = Gs($k); \r\n")
end
for k = 1:Nas
    local entry1 = Nas + k
    write(file,"A_2s$k = Gs($entry1); \r\n")
end
for k = 1:Nrs
    local entry1 = 2*Nas + k
    write(file,"D_1s$k = Gs($entry1); \r\n")
end
for k = 1:Nrs
    local entry1 = 2*Nas + Nrs + k
    write(file,"D_2s$k = Gs($entry1); \r\n")
end

############################### k = 1:Nas (A_1s) ##################################
for k = 1:Nas
    write(file,"Nonlinear_Algebraic_Equations_Value_Vector($k,1) = ")

    # Sum A_1s,n
    for n = 1:Nas
        write(file,"A_1s$n*V1s($k,$n) + ")
    end
    # SumSum D_1s,n D_1s,m
    for n = 1:Nrs
        for m = 1:Nrs
            write(file,"D_1s$n*D_1s$m*V2s($k,$n,$m) + ")
        end
    end
    # Sum A_2s,n
    for n = 1:Nas
        write(file,"A_2s$n*V3s($k,$n) + ")
    end
    # SumSum D_2s,n D_2s,m
    for n = 1:Nrs
        for m = 1:Nrs
            write(file,"D_2s$n*D_2s$m*V4s($k,$n,$m) + ")
        end
    end
    # Constant term in the end
    write(file,"V5s($k); \r\n")
end
############################### k = 1:Nas (A_2s) ##################################
for k = 1:Nas
    local entry1 = Nas + k
    write(file,"Nonlinear_Algebraic_Equations_Value_Vector($entry1,1) = ")

    # Sum A_2s,n
    for n = 1:Nas
        write(file,"A_2s$n*V6s($k,$n) + ")
    end
    # SumSum D_2s,n D_2s,m
    for n = 1:Nrs
        for m = 1:Nrs
            write(file,"D_2s$n*D_2s$m*V7s($k,$n,$m) + ")
        end
    end
    # Constant term in the end
    write(file,"V10s($k); \r\n") # V8s and V9s are zero
end
################################# k = 1:Nrs (D_1s) #####################################
for k = 1:Nrs
    local entry1 = 2*Nas + k
    write(file,"Nonlinear_Algebraic_Equations_Value_Vector($entry1,1) = ")

    # SumSum A_1s,n D_1s,m
    for n = 1:Nas
        for m = 1:Nrs
            write(file,"A_1s$n*D_1s$m*V11s($k,$n,$m) + ")
        end
    end
    # SumSumSum D_1s,n D_1s,m D_1s,p
    for n = 1:Nrs
        for m = 1:Nrs
            for p = 1:Nrs
                write(file,"D_1s$n*D_1s$m*D_1s$p*V12s($k,$n,$m,$p) + ")
            end
        end
    end
    # Sum D_1s,n
    for n = 1:Nrs
        write(file,"D_1s$n*V13s($k,$n) + ")
    end
    # SumSum A_2s,n D_2s,m
    for n = 1:Nas
        for m = 1:Nrs
            write(file,"A_2s$n*D_2s$m*V14s($k,$n,$m) + ")
        end
    end
    # SumSumSum D_2s,n D_2s,m D_2s,p
    for n = 1:Nrs
        for m = 1:Nrs
            for p = 1:Nrs
                write(file,"D_2s$n*D_2s$m*D_2s$p*V15s($k,$n,$m,$p) + ")
            end
        end
    end
    # Sum D_2s,n
    for n = 1:Nrs
        write(file,"D_2s$n*V16s($k,$n) + ")
    end
    # Constant term in the end
    write(file,"V17s($k); \r\n")
end
################################# k = 1:Nrs (D_2s) #####################################
for k = 1:Nrs
    local entry1 = 2*Nas + Nrs + k
    write(file,"Nonlinear_Algebraic_Equations_Value_Vector($entry1,1) = ")

    # SumSum A_2s,n D_2s,m
    for n = 1:Nas
        for m = 1:Nrs
            write(file,"A_2s$n*D_2s$m*V18s($k,$n,$m) + ")
        end
    end
    # SumSumSum D_2s,n D_2s,m D_2s,p
    for n = 1:Nrs
        for m = 1:Nrs
            for p = 1:Nrs
                write(file,"D_2s$n*D_2s$m*D_2s$p*V19s($k,$n,$m,$p) + ")
            end
        end
    end
    # Sum D_2s,n
    for n = 1:Nrs
        if n < Nrs
            write(file,"D_2s$n*V20s($k,$n) + ")
        else
            write(file,"D_2s$n*V20s($k,$n); \r\n")
        end
    end
end
write(file,"end")
close(file)

function [Mlin,Clin,Klin] = DynamicalSolutions_MlinClinKlinS0_Assembly(Na,Nt,Nr,V1,V12,V29,V49,V2,V13,V30,V50,V3,V4,V14,V15,V32,V31,V52,V51)
     disp('------------------------------------------------------');
     disp('Evaluating Mlin, Clin and Klin matrices and S0 vector...');
     tic
    %% Mlin ASSEMBLY
    Mlin = zeros((Na + 2*Nt + Nr),(Na + 2*Nt + Nr));
    Mlin(1:Na,1:Na) = V1;
    Mlin((Na + 1):(Na + Nt),(Na + 1):(Na + Nt)) = V12;
    Mlin((Na + Nt + 1):(Na + 2*Nt),(Na + Nt + 1):(Na + 2*Nt)) = V29;
    Mlin((Na + 2*Nt + 1):(Na + 2*Nt + Nr),(Na + 2*Nt + 1):(Na + 2*Nt + Nr)) = V49;
    %% Clin ASSEMBLY
    Clin = zeros((Na + 2*Nt + Nr),(Na + 2*Nt + Nr));
    Clin(1:Na,1:Na) = V2;
    Clin((Na + 1):(Na + Nt),(Na + 1):(Na + Nt)) = V13;
    Clin((Na + Nt + 1):(Na + 2*Nt),(Na + Nt + 1):(Na + 2*Nt)) = V30;
    Clin((Na + 2*Nt + 1):(Na + 2*Nt + Nr),(Na + 2*Nt + 1):(Na + 2*Nt + Nr)) = V50;
    %% Klin ASSEMBLY
    Klin = zeros((Na + 2*Nt + Nr),(Na + 2*Nt + Nr));
    %Main diagonal
    Klin(1:Na,1:Na) = V3;
    Klin((Na + 1):(Na + Nt),(Na + 1):(Na + Nt)) = V14;
    Klin((Na + Nt + 1):(Na + 2*Nt),(Na + Nt + 1):(Na + 2*Nt)) = V31;
    Klin((Na + 2*Nt + 1):(Na + 2*Nt + Nr),(Na + 2*Nt + 1):(Na + 2*Nt + Nr)) = V51;
    %Antidiagonal
    Klin(1:Na,(Na + 2*Nt + 1):(Na + 2*Nt + Nr)) = V4;
    Klin((Na + 1):(Na + Nt),(Na + Nt + 1):(Na + 2*Nt)) = V15;
    Klin((Na + Nt + 1):(Na + 2*Nt),(Na + 1):(Na + Nt)) = V32;
    Klin((Na + 2*Nt + 1):(Na + 2*Nt + Nr),1:Na) = V52;
end
function [vectorD] = Numerical_Derivative(vector,x)  
    delta = x(2)-x(1);
    vectorD = zeros(1,length(x));
    vectorD(1) = (vector(2) - vector(1))/delta;
    vectorD(end) = (vector(end) - vector(end-1))/delta;
    for i = 2:(length(x)-1)
        vectorD(i) = (vector(i+1) - vector(i-1))/(2*delta);
    end
end
using DelimitedFiles

cd(@__DIR__)
Na = 3
Nr = 4
Nt = 7

name = "DynamicalSolutions_ODEs.m"
file = open(name,"w") # w -> write

write(file,"function dq = DynamicalSolutions_ODEs(q,t,Mlin,Clin,Klin,V47,V39,V59,V9,V10,V19,V20,V25,V26,V21,V27,V28,V36,V38,V45,V46,V37,V43,V44,V58,V5,V8,V11,V6,V7,V16,V17,V22,V23,V24,V18,V33,V35,V41,V34,V40,V42,V54,V55,V57,V61,V56,V62,V53,V60) \r\n") #\r -> indicate the end of lines; \n -> break line
##########################################
# Nonlinear Mass Matrix - Mnl
entry1 = Na + 2*Nt + Nr
write(file,"M = zeros($entry1,$entry1); \r\n")
write(file,"C = zeros($entry1,$entry1); \r\n")
write(file,"K = zeros($entry1,$entry1); \r\n")
write(file,"Mnl = zeros($entry1,$entry1); \r\n") # Mnl = [Mnl11,Mnl12,Mnl13,Mnl14;Mnl21,Mnl22,Mnl23,Mnl24;Mnl31,Mnl32,Mnl33,Mnl34;Mnl41,Mnl42,Mnl43,Mnl44]
write(file,"Mnl33 = zeros($Nt,$Nt); \r\n")
write(file,"Mnl34 = zeros($Nt,$Nr); \r\n")
write(file,"Mnl43 = zeros($Nr,$Nt); \r\n")
for lin = 1:Nt
    for col = 1:Nt

        write(file,"Mnl33($lin,$col) = ")
        for cont1 = 1:Nt
            local entry1 = Na + cont1 # B
            for cont2 = 1:Nt
                local entry2 = Na + cont2 # B

                if cont1 == Nt && cont2 == Nt
                    write(file,"q($entry1,1)*q($entry2,1)*V47($lin,$cont1,$cont2,$col); \r\n")
                else
                    write(file,"q($entry1,1)*q($entry2,1)*V47($lin,$cont1,$cont2,$col) + ")
                end
                
            end
        end

    end
end
for lin = 1:Nt
    for col = 1:Nr

        write(file,"Mnl34($lin,$col) = ")
        for cont1 = 1:Nt
            local entry1 = Na + cont1 # B

            if cont1 == Nt
                write(file,"q($entry1,1)*V39($lin,$cont1,$col); \r\n")
            else
                write(file,"q($entry1,1)*V39($lin,$cont1,$col) + ")
            end
            
        end

    end
end
for lin = 1:Nr
    for col = 1:Nt

        write(file,"Mnl43($lin,$col) = ")
        for cont1 = 1:Nt
            local entry1 = Na + cont1 # B

            if cont1 == Nt
                write(file,"q($entry1,1)*V59($lin,$cont1,$col); \r\n")
            else
                write(file,"q($entry1,1)*V59($lin,$cont1,$col) + ")
            end
            
        end

    end
end
entry1 = Na + Nt + 1
entry2 = Na + 2*Nt
entry3 = Na + 2*Nt + 1
entry4 = Na + 2*Nt + Nr
write(file,"Mnl($entry1:$entry2,$entry1:$entry2) = Mnl33; \r\n")
write(file,"Mnl($entry1:$entry2,$entry3:$entry4) = Mnl34; \r\n")
write(file,"Mnl($entry3:$entry4,$entry1:$entry2) = Mnl43; \r\n")
##########################################
# Nonlinear Damping Matrix - Cnl
entry1 = Na + 2*Nt + Nr
write(file,"Cnl = zeros($entry1,$entry1); \r\n") # Cnl = [Cnl11,Cnl12,Cnl13,Cnl14;Cnl21,Cnl22,Cnl23,Cnl24;Cnl31,Cnl32,Cnl33,Cnl34;Cnl41,Cnl42,Cnl43,Cnl44]
write(file,"Cnl12 = zeros($Na,$Nt); \r\n")
write(file,"Cnl13 = zeros($Na,$Nt); \r\n")
write(file,"Cnl21 = zeros($Nt,$Na); \r\n")
write(file,"Cnl22 = zeros($Nt,$Nt); \r\n")
write(file,"Cnl23 = zeros($Nt,$Nt); \r\n")
write(file,"Cnl24 = zeros($Nt,$Nr); \r\n")
write(file,"Cnl31 = zeros($Nt,$Na); \r\n")
write(file,"Cnl32 = zeros($Nt,$Nt); \r\n")
write(file,"Cnl33 = zeros($Nt,$Nt); \r\n")
write(file,"Cnl34 = zeros($Nt,$Nr); \r\n")
write(file,"Cnl42 = zeros($Nr,$Nt); \r\n")
for lin = 1:Na
    for col = 1:Nt

        write(file,"Cnl12($lin,$col) = ")
        for cont1 = 1:Nt
            local entry1 = Na + cont1 # B

            if cont1 == Nt
                write(file,"q($entry1,1)*V9($lin,$col,$cont1); \r\n")
            else
                write(file,"q($entry1,1)*V9($lin,$col,$cont1) + ") 
            end
            
        end

    end
end
for lin = 1:Na
    for col = 1:Nt

        write(file,"Cnl13($lin,$col) = ")
        for cont1 = 1:Nt
            local entry1 = Na + Nt + cont1 # C

            if cont1 == Nt
                write(file,"q($entry1,1)*V10($lin,$col,$cont1); \r\n")
            else
                write(file,"q($entry1,1)*V10($lin,$col,$cont1) + ")
            end
            
        end

    end
end
for lin = 1:Nt
    for col = 1:Na

        write(file,"Cnl21($lin,$col) = ")
        for cont1 = 1:Nt
            local entry1 = Na + cont1 # B

            if cont1 == Nt
                write(file,"q($entry1,1)*V19($lin,$col,$cont1); \r\n")
            else
                write(file,"q($entry1,1)*V19($lin,$col,$cont1) + ")
            end
            
        end

    end
end
for lin = 1:Nt
    for col = 1:Nt

        write(file,"Cnl22($lin,$col) = ")
        for cont1 = 1:Na
            local entry1 = cont1 # A

            write(file,"q($entry1,1)*V20($lin,$cont1,$col) + ")
            
        end

        for cont1 = 1:Nt
            local entry1 = Na + cont1 # B
            for cont2 = 1:Nt
                local entry2 = Na + cont2 # B

                write(file,"q($entry1,1)*q($entry2,1)*V25($lin,$col,$cont1,$cont2) + ")
                
            end
        end

        for cont1 = 1:Nt
            local entry1 = Na + Nt + cont1 # C
            for cont2 = 1:Nt
                local entry2 = Na + Nt + cont2 # C

                if cont1 == Nt && cont2 == Nt
                    write(file,"q($entry1,1)*q($entry2,1)*V26($lin,$col,$cont1,$cont2); \r\n")
                else
                    write(file,"q($entry1,1)*q($entry2,1)*V26($lin,$col,$cont1,$cont2) + ")
                end
                
            end
        end

    end
end
for lin = 1:Nt
    for col = 1:Nt

        write(file,"Cnl23($lin,$col) = ")
        for cont1 = 1:Nt
            local entry1 = Na + cont1 # B
            for cont2 = 1:Nt
                local entry2 = Na + Nt + cont2 # C
                
                write(file,"q($entry1,1)*q($entry2,1)*V27($lin,$cont1,$col,$cont2) + ")
            
            end
        end

        for cont1 = 1:Nt
            local entry1 = Na + cont1 # B
            for cont2 = 1:Nt
                local entry2 = 2*Na + 3*Nt + Nr + cont2 # Cdot
                
                if cont1 == Nt && cont2 == Nt
                    write(file,"q($entry1,1)*q($entry2,1)*V28($lin,$cont1,$cont2,$col); \r\n")
                else
                    write(file,"q($entry1,1)*q($entry2,1)*V28($lin,$cont1,$cont2,$col) + ")
                end
            
            end
        end

    end
end
for lin = 1:Nt
    for col = 1:Nr

        write(file,"Cnl24($lin,$col) = ")
        for cont1 = 1:Nt
            local entry1 = 2*Na + 3*Nt + Nr + cont1 # Cdot
                
                if cont1 == Nt
                    write(file,"q($entry1,1)*V21($lin,$cont1,$col); \r\n")
                else
                    write(file,"q($entry1,1)*V21($lin,$cont1,$col) + ")
                end
            
        end

    end
end
for lin = 1:Nt
    for col = 1:Na

        write(file,"Cnl31($lin,$col) = ")
        for cont1 = 1:Nt
            local entry1 = Na + Nt + cont1 # C

            if cont1 == Nt
                write(file,"q($entry1,1)*V36($lin,$col,$cont1); \r\n")
            else
                write(file,"q($entry1,1)*V36($lin,$col,$cont1) + ")
            end
            
        end

    end
end
for lin = 1:Nt
    for col = 1:Nt

        write(file,"Cnl32($lin,$col) = ")
        for cont1 = 1:Nt
            local entry1 = Na + cont1 # B
            for cont2 = 1:Nt
                local entry2 = Na + Nt + cont2 # C
               
                if cont1 == Nt && cont2 == Nt
                    write(file,"q($entry1,1)*q($entry2,1)*V45($lin,$cont1,$col,$cont2); \r\n")
                else
                    write(file,"q($entry1,1)*q($entry2,1)*V45($lin,$cont1,$col,$cont2) + ")
                end
            
            end
        end

    end
end
for lin = 1:Nt
    for col = 1:Nt

        write(file,"Cnl33($lin,$col) = ")
        for cont1 = 1:Na
            local entry1 = cont1 # A

            write(file,"q($entry1,1)*V37($lin,$cont1,$col) + ")
            
        end

        for cont1 = 1:Nt
            local entry1 = Na + Nt + cont1 # C
            for cont2 = 1:Nt
                local entry2 = Na + Nt + cont2 # C
               
                write(file,"q($entry1,1)*q($entry2,1)*V43($lin,$col,$cont1,$cont2) + ")
            
            end
        end

        for cont1 = 1:Nt
            local entry1 = Na + cont1 # B
            for cont2 = 1:Nt
                local entry2 = Na + cont2 # B
               
                write(file,"q($entry1,1)*q($entry2,1)*V44($lin,$cont1,$cont2,$col) + ")
            
            end
        end

        for cont1 = 1:Nt
            local entry1 = Na + cont1 # B
            for cont2 = 1:Nt
                local entry2 = 2*Na + 2*Nt + Nr + cont2 # Bdot

                if cont1 == Nt && cont2 == Nt
                    write(file,"q($entry1,1)*q($entry2,1)*V46($lin,$cont1,$cont2,$col); \r\n")
                else
                    write(file,"q($entry1,1)*q($entry2,1)*V46($lin,$cont1,$cont2,$col) + ")
                end

            end
        end
        
    end
end
for lin = 1:Nt
    for col = 1:Nr

        write(file,"Cnl34($lin,$col) = ")
        for cont1 = 1:Nt
            local entry1 = 2*Na + 2*Nt + Nr + cont1 # Bdot
                
                if cont1 == Nt
                    write(file,"q($entry1,1)*V38($lin,$cont1,$col); \r\n")
                else
                    write(file,"q($entry1,1)*V38($lin,$cont1,$col) + ")
                end
            
        end

    end
end
for lin = 1:Nr
    for col = 1:Nt

        write(file,"Cnl42($lin,$col) = ")
        for cont1 = 1:Nt
            local entry1 = 2*Na + 3*Nt + Nr + cont1 # Cdot

            if cont1 == Nt
                write(file,"q($entry1,1)*V58($lin,$col,$cont1); \r\n")
            else
                write(file,"q($entry1,1)*V58($lin,$col,$cont1) + ")
            end

        end
            
    end
end
entry1 = Na + 1
entry2 = Na + Nt
entry3 = Na + Nt + 1
entry4 = Na + 2*Nt
entry5 = Na + 2*Nt + 1
entry6 = Na + 2*Nt + Nr
write(file,"Cnl(1:$Na,$entry1:$entry2) = Cnl12; \r\n")
write(file,"Cnl(1:$Na,$entry3:$entry4) = Cnl13; \r\n")
write(file,"Cnl($entry1:$entry2,1:$Na) = Cnl21; \r\n")
write(file,"Cnl($entry1:$entry2,$entry1:$entry2) = Cnl22; \r\n")
write(file,"Cnl($entry1:$entry2,$entry3:$entry4) = Cnl23; \r\n")
write(file,"Cnl($entry1:$entry2,$entry5:$entry6) = Cnl24; \r\n")
write(file,"Cnl($entry3:$entry4,1:$Na) = Cnl31; \r\n")
write(file,"Cnl($entry3:$entry4,$entry1:$entry2) = Cnl32; \r\n")
write(file,"Cnl($entry3:$entry4,$entry3:$entry4) = Cnl33; \r\n")
write(file,"Cnl($entry3:$entry4,$entry5:$entry6) = Cnl34; \r\n")
write(file,"Cnl($entry5:$entry6,$entry1:$entry2) = Cnl42; \r\n")
##########################################
# Nonlinear Stiffness Matrix - Knl
entry1 = Na + 2*Nt + Nr
write(file,"Knl = zeros($entry1,$entry1); \r\n") # Knl = [Knl11,Knl12,Knl13,Knl14;Knl21,Knl22,Knl23,Knl24;Knl31,Knl32,Knl33,Knl34;Knl41,Knl42,Knl43,Knl44]
write(file,"Knl12 = zeros($Na,$Nt); \r\n")
write(file,"Knl13 = zeros($Na,$Nt); \r\n")
write(file,"Knl14 = zeros($Na,$Nr); \r\n")
write(file,"Knl22 = zeros($Nt,$Nt); \r\n")
write(file,"Knl24 = zeros($Nt,$Nr); \r\n")
write(file,"Knl33 = zeros($Nt,$Nt); \r\n")
write(file,"Knl34 = zeros($Nt,$Nr); \r\n")
write(file,"Knl42 = zeros($Nr,$Nt); \r\n")
write(file,"Knl43 = zeros($Nr,$Nt); \r\n")
write(file,"Knl44 = zeros($Nr,$Nr); \r\n")
for lin = 1:Na
    for col = 1:Nt

        write(file,"Knl12($lin,$col) = ")
        for cont1 = 1:Nt
            local entry1 = Na + cont1 # B

            write(file,"q($entry1,1)*V5($lin,$col,$cont1) + ")
            
        end

        for cont1 = 1:Nt
            local entry1 = Na + Nt + cont1 # C

            if cont1 == Nt
                write(file,"q($entry1,1)*V8($lin,$col,$cont1); \r\n")
            else
                write(file,"q($entry1,1)*V8($lin,$col,$cont1) + ")
            end
            
        end

    end
end
for lin = 1:Na
    for col = 1:Nt

        write(file,"Knl13($lin,$col) = ")
        for cont1 = 1:Nt
            local entry1 = Na + Nt + cont1 # C

            if cont1 == Nt
                write(file,"q($entry1,1)*V6($lin,$col,$cont1); \r\n")
            else
                write(file,"q($entry1,1)*V6($lin,$col,$cont1) + ")
            end
            
        end

    end
end
for lin = 1:Na
    for col = 1:Nr

        write(file,"Knl14($lin,$col) = ")
        for cont1 = 1:Nr
            local entry1 = Na + 2*Nt + cont1 # D

            write(file,"q($entry1,1)*V7($lin,$col,$cont1) + ")
            
        end

        for cont1 = 1:Nt
            local entry1 = Na + cont1 # B
            for cont2 = 1:Nt
                local entry2 = Na + Nt + cont2 # C
                
                if cont1 == Nt && cont2 == Nt
                    write(file,"q($entry1,1)*q($entry2,1)*V11($lin,$cont1,$cont2,$col); \r\n")
                else
                    write(file,"q($entry1,1)*q($entry2,1)*V11($lin,$cont1,$cont2,$col) + ")
                end

            end
        end

    end
end
for lin = 1:Nt
    for col = 1:Nt

        write(file,"Knl22($lin,$col) = ")
        for cont1 = 1:Na
            local entry1 = cont1 # A

            write(file,"q($entry1,1)*V16($lin,$cont1,$col) + ")
            
        end

        for cont1 = 1:Nr
            local entry1 = Na + 2*Nt + cont1 # D

            write(file,"q($entry1,1)*V17($lin,$col,$cont1) + ")
            
        end

        for cont1 = 1:Nt
            local entry1 = Na + cont1 # B
            for cont2 = 1:Nt
                local entry2 = Na + cont2 # B
            
                write(file,"q($entry1,1)*q($entry2,1)*V22($lin,$col,$cont1,$cont2) + ")
            
            end
        end

        for cont1 = 1:Nt
            local entry1 = Na + Nt + cont1 # C
            for cont2 = 1:Nt
                local entry2 = Na + Nt + cont2 # C
            
                write(file,"q($entry1,1)*q($entry2,1)*V23($lin,$col,$cont1,$cont2) + ")
            
            end
        end

        for cont1 = 1:Nr
            local entry1 = Na + 2*Nt + cont1 # D
            for cont2 = 1:Nr
                local entry2 = Na + 2*Nt + cont2 # D
               
                if cont1 == Nr && cont2 == Nr
                    write(file,"q($entry1,1)*q($entry2,1)*V24($lin,$col,$cont1,$cont2); \r\n")
                else
                    write(file,"q($entry1,1)*q($entry2,1)*V24($lin,$col,$cont1,$cont2) + ")
                end
            
            end
        end

    end
end
for lin = 1:Nt
    for col = 1:Nr

        write(file,"Knl24($lin,$col) = ")
        for cont1 = 1:Nt
            local entry1 = Na + Nt + cont1 # C

            if cont1 == Nt
                write(file,"q($entry1,1)*V18($lin,$cont1,$col); \r\n")
            else
                write(file,"q($entry1,1)*V18($lin,$cont1,$col) + ")
            end
            
        end

    end
end
for lin = 1:Nt
    for col = 1:Nt

        write(file,"Knl33($lin,$col) = ")
        for cont1 = 1:Na
            local entry1 = cont1 # A

            write(file,"q($entry1,1)*V33($lin,$cont1,$col) + ")
            
        end

        for cont1 = 1:Nr
            local entry1 = Na + 2*Nt + cont1 # D

            write(file,"q($entry1,1)*V34($lin,$col,$cont1) + ")
            
        end

        for cont1 = 1:Nt
            local entry1 = Na + Nt + cont1 # C
            for cont2 = 1:Nt
                local entry2 = Na + Nt + cont2 # C
               
                write(file,"q($entry1,1)*q($entry2,1)*V40($lin,$col,$cont1,$cont2) + ")
            
            end
        end

        for cont1 = 1:Nt
            local entry1 = Na + cont1 # B
            for cont2 = 1:Nt
                local entry2 = Na + cont2 # B
               
                write(file,"q($entry1,1)*q($entry2,1)*V41($lin,$cont1,$cont2,$col) + ")
            
            end
        end

        for cont1 = 1:Nr
            local entry1 = Na + 2*Nt + cont1 # D
            for cont2 = 1:Nr
                local entry2 = Na + 2*Nt + cont2 # D
               
                if cont1 == Nr && cont2 == Nr
                    write(file,"q($entry1,1)*q($entry2,1)*V42($lin,$col,$cont1,$cont2); \r\n")
                else
                    write(file,"q($entry1,1)*q($entry2,1)*V42($lin,$col,$cont1,$cont2) + ")
                end
            
            end
        end

    end
end
for lin = 1:Nt
    for col = 1:Nr

        write(file,"Knl34($lin,$col) = ")
        for cont1 = 1:Nt
            local entry1 = Na + cont1 # B

            if cont1 == Nt
                write(file,"q($entry1,1)*V35($lin,$cont1,$col); \r\n")
            else
                write(file,"q($entry1,1)*V35($lin,$cont1,$col) + ")
            end
            
        end

    end
end
for lin = 1:Nr
    for col = 1:Nt

        write(file,"Knl42($lin,$col) = ")
        for cont1 = 1:Nt
            local entry1 = Na + cont1 # B

            write(file,"q($entry1,1)*V55($lin,$col,$cont1) + ")
            
        end

        for cont1 = 1:Nt
            local entry1 = Na + Nt + cont1 # C

            if cont1 == Nt
                write(file,"q($entry1,1)*V57($lin,$col,$cont1); \r\n")
            else
                write(file,"q($entry1,1)*V57($lin,$col,$cont1) + ")
            end
            
        end

    end
end
for lin = 1:Nr
    for col = 1:Nt

        write(file,"Knl43($lin,$col) = ")
        for cont1 = 1:Nt
            local entry1 = Na + Nt + cont1 # C

            if cont1 == Nt
                write(file,"q($entry1,1)*V56($lin,$col,$cont1); \r\n")
            else
                write(file,"q($entry1,1)*V56($lin,$col,$cont1) + ")
            end
            
        end

    end
end
for lin = 1:Nr
    for col = 1:Nr

        write(file,"Knl44($lin,$col) = ")
        for cont1 = 1:Nr
            local entry1 = Na + 2*Nt + cont1 # D

            write(file,"q($entry1,1)*V53($lin,$col,$cont1) + ")
            
        end

        for cont1 = 1:Na
            local entry1 = cont1 # A
        
            write(file,"q($entry1,1)*V54($lin,$cont1,$col) + ")
            
        end

        for cont1 = 1:Nr
            local entry1 = Na + 2*Nt + cont1 # D
            for cont2 = 1:Nr
                local entry2 = Na + 2*Nt + cont2 # D
               
                write(file,"q($entry1,1)*q($entry2,1)*V60($lin,$col,$cont1,$cont2) + ")
            
            end
        end

        for cont1 = 1:Nt
            local entry1 = Na + cont1 # B
            for cont2 = 1:Nt
                local entry2 = Na + cont2 # B
               
                write(file,"q($entry1,1)*q($entry2,1)*V61($lin,$cont1,$cont2,$col) + ")
            
            end
        end

        for cont1 = 1:Nt
            local entry1 = Na + Nt + cont1 # C
            for cont2 = 1:Nt
                local entry2 = Na + Nt + cont2 # C
               
                if cont1 == Nt && cont2 == Nt
                    write(file,"q($entry1,1)*q($entry2,1)*V62($lin,$cont1,$cont2,$col); \r\n")
                else
                    write(file,"q($entry1,1)*q($entry2,1)*V62($lin,$cont1,$cont2,$col) + ")
                end
            
            end
        end
        
    end
end
entry1 = Na + 1
entry2 = Na + Nt
entry3 = Na + Nt + 1
entry4 = Na + 2*Nt
entry5 = Na + 2*Nt + 1
entry6 = Na + 2*Nt + Nr
write(file,"Knl(1:$Na,$entry1:$entry2) = Knl12; \r\n")
write(file,"Knl(1:$Na,$entry3:$entry4) = Knl13; \r\n")
write(file,"Knl(1:$Na,$entry5:$entry6) = Knl14; \r\n")
write(file,"Knl($entry1:$entry2,$entry1:$entry2) = Knl22; \r\n")
write(file,"Knl($entry1:$entry2,$entry5:$entry6) = Knl24; \r\n")
write(file,"Knl($entry3:$entry4,$entry3:$entry4) = Knl33; \r\n")
write(file,"Knl($entry3:$entry4,$entry5:$entry6) = Knl34; \r\n")
write(file,"Knl($entry5:$entry6,$entry1:$entry2) = Knl42; \r\n")
write(file,"Knl($entry5:$entry6,$entry3:$entry4) = Knl43; \r\n")
write(file,"Knl($entry5:$entry6,$entry5:$entry6) = Knl44; \r\n")

# Definitive M, C and K matrices
write(file,"M = Mlin + Mnl; \r\n")
write(file,"C = Clin + Cnl; \r\n")
write(file,"K = Klin + Knl; \r\n")
write(file,"Minv = inv(M); \r\n")

write(file,"t \r\n")

# Final first order system assembly
entry1 = Na + 2*Nt + Nr
write(file,"A = [zeros($entry1,$entry1) eye($entry1,$entry1);-Minv*K -Minv*C]; \r\n")
write(file,"dq = A*q; \r\n")
write(file,"end")
close(file)
function [t,q,AMS_frequency_vector,RMS_frequency_vector,TMS_frequency_vector,x0,xid,eta,zeta,thetaxd] = DynamicalSolutions_Main(numberofdomains,PlotModalShapeFunctions,UseSupportSprings,Na,Nr,Nt,shat,k0,k1,k2,k3,k4,u,mnhat,xibar,Chatstheta,beta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,xis,xisD1,xisD2,thetaxs,thetaxsD1,thetaxsD2,time,InitialConditions)
    disp('______________________________________________________')
    disp('EVALUATION OF THE DYNAMICAL SOLUTIONS')
    tdynamicalsolutions = tic;
    %% MODAL SHAPES
    [InitialConditions,AMS_matrix,AMS_frequency_vector,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMS_frequency_vector,RMSD1_matrix,RMSD2_matrix,TMS_matrix,TMS_frequency_vector,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix] = DynamicalSolutions_Modal_Shapes(InitialConditions,UseSupportSprings,Na,Nr,Nt,shat,k2,k3,k5);
    %% PLOTS OF THE MODAL SHAPES
    if PlotModalShapeFunctions == 1
        fig = figure();
        fig.Renderer='Painters';
        subplot(3,1,1)
        for i = 1:Na
            plot(shat,AMS_matrix(i,:),'linewidth',1.0)
            ax = gca;
            %ax.YLim = [min(xis) max(xis)];
            % ax.YTick = [ ];
            %ax.XLim = [shat(1) shat(end)];
            % ax.XTick = [ ];
            ax.YAxis.FontSize = 12;
            ax.XAxis.FontSize = 12;
            ylab = ylabel('$\phi^{}_{n}$','rotation',0,'interpreter','latex','FontSize',20);
            %ylab.Position(1) = ylab.Position(1) -0.01;
            %ylab.Position(2) = ylab.Position(2) + 1;
            xlab = xlabel('$\hat{s}$','rotation',0,'interpreter','latex','FontSize',20);
            hold on
        end
        subplot(3,1,2)
        for i = 1:Nr
            plot(shat,RMS_matrix(i,:),'linewidth',1.0)
            ax = gca;
            %ax.YLim = [min(xis) max(xis)];
            % ax.YTick = [ ];
            %ax.XLim = [shat(1) shat(end)];
            % ax.XTick = [ ];
            ax.YAxis.FontSize = 12;
            ax.XAxis.FontSize = 12;
            ylab = ylabel('$\Theta^{}_{n}$','rotation',0,'interpreter','latex','FontSize',20);
            %ylab.Position(1) = ylab.Position(1) -0.01;
            %ylab.Position(2) = ylab.Position(2) + 1;
            xlab = xlabel('$\hat{s}$','rotation',0,'interpreter','latex','FontSize',20);
            hold on
        end
        subplot(3,1,3)
        for i = 1:Nt
            plot(shat,TMS_matrix(i,:),'linewidth',1.0)
                ax = gca;
            %ax.YLim = [min(xis) max(xis)];
            % ax.YTick = [ ];
            %ax.XLim = [shat(1) shat(end)];
            % ax.XTick = [ ];
            ax.YAxis.FontSize = 12;
            ax.XAxis.FontSize = 12;
            ylab = ylabel('$\psi^{}_{n}$','rotation',0,'interpreter','latex','FontSize',20);
            %ylab.Position(1) = ylab.Position(1) -0.01;
            %ylab.Position(2) = ylab.Position(2) + 1;
            xlab = xlabel('$\hat{s}$','rotation',0,'interpreter','latex','FontSize',20);
            hold on
        end
        print('Export\ModalShapes',fig,'-dpdf','-fillpage')
    end
    close all
    %% EVALUATION OF THE COEFFICIENTS FOR THE ORDINARY DIFFERENTIAL EQUATIONS
    [V1,V2,V3,V4,V5,V6,V7,V8,V9,V10,V11,V12,V13,V14,V15,V16,V17,V18,V19,V20,V21,V22,V23,V24,V25,V26,V27,V28,V29,V30,V31,V32,V33,V34,V35,V36,V37,V38,V39,V40,V41,V42,V43,V44,V45,V46,V47,V49,V50,V51,V52,V53,V54,V55,V56,V57,V58,V59,V60,V61,V62] = DynamicalSolutions_Galerkin_Matrices_Evaluation(numberofdomains,UseSupportSprings,Na,Nr,Nt,shat,k0,k1,k2,k3,k4,u,mnhat,xibar,Chatstheta,beta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,xisD1,xisD2,thetaxs,thetaxsD1,TMS_matrix,TMSD1_matrix,TMSD2_matrix,TMSD3_matrix,TMSD4_matrix,AMS_matrix,AMSD1_matrix,AMSD2_matrix,RMS_matrix,RMSD1_matrix,RMSD2_matrix);
    %% Mlin, Clin AND Klin MATRICES AND S0 VECTOR
    [Mlin,Clin,Klin] = DynamicalSolutions_MlinClinKlinS0_Assembly(Na,Nt,Nr,V1,V12,V29,V49,V2,V13,V30,V50,V3,V4,V14,V15,V32,V31,V52,V51);
    %% NUMERICAL INTEGRATION OF THE EQUATIONS OF MOTION
    disp('------------------------------------------------------');
    disp('Integrating the Equations of Motion...');
    tic
    dq = @(t,q) DynamicalSolutions_ODEs(q,t,Mlin,Clin,Klin,V47,V39,V59,V9,V10,V19,V20,V25,V26,V21,V27,V28,V36,V38,V45,V46,V37,V43,V44,V58,V5,V8,V11,V6,V7,V16,V17,V22,V23,V24,V18,V33,V35,V41,V34,V40,V42,V54,V55,V57,V61,V56,V62,V53,V60); % Model
    [t,q] = ode45(dq,time,InitialConditions); % Simulation
    toc
    disp('______________________________________________________')
    % Displacements assembly
    x0 = zeros(length(shat),length(t));
    for i = 1:length(time)
        x0(:,i) = linspace(0,1,length(shat));
    end
    xid = (q(:,1:Na)*AMS_matrix)';
    eta = (q(:,(Na+1):(Na + Nt))*TMS_matrix)';
    zeta = (q(:,(Na + Nt + 1):(Na + 2*Nt))*TMS_matrix)';
    thetaxd = (q(:,(Na + 2*Nt + 1):(Na + 2*Nt + Nr))*RMS_matrix)';
    toc(tdynamicalsolutions);
end
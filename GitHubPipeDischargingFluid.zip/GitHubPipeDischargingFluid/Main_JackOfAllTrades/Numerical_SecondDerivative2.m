function [vectorD2] = Numerical_SecondDerivative2(vector,shat,mnhat,xibar,k0)  
    %% ONE DOMAIN
    if (mnhat==0 && k0==0) || xibar == 1
        delta = shat(2)-shat(1);
        vectorD2 = zeros(1,length(shat));
        vectorD2(1) = (1*vector(1) - 2*vector(2) + vector(3))/delta^2;
        vectorD2(end) = (1*vector(end) -2*vector(end-1) + 1*vector(end-2))/delta^2;
        for i = 2:(length(shat)-1)
            vectorD2(i) = (-2*vector(i) + 1*vector(i+1) + 1*vector(i-1))/(delta^2);
        end
    end
    %% TWO DOMAINS
    if (mnhat~=0 || k0~=0) && xibar > 0 && xibar < 1
        LD = xibar;
        %Domain definition
        shat1 = shat(1:round((length(shat)-1)*LD) + 1);
        shat2 = shat(round((length(shat)-1)*LD) + 1:end);
        %Separate vector into two
        vector_1 = vector(1:round((length(shat)-1)*LD) + 1);
        vector_2 = vector(round((length(shat)-1)*LD) + 1:end);
        %Very slight correction of LD to match the vector entries
        LD = shat1(end);
        %Numerical derivative in the first domain
        delta_1 = shat1(2)-shat1(1);
        vectorD2_1 = zeros(1,length(shat1));
        vectorD2_1(1) = (1*vector_1(1) - 2*vector_1(2) + vector_1(3))/delta_1^2;
        vectorD2_1(end-1) = (1*vector_1(end-1) -2*vector_1(end-2) + 1*vector_1(end-3))/delta_1^2;
        vectorD2_1(end) = (1*vector_1(end) -2*vector_1(end-1) + 1*vector_1(end-2))/delta_1^2;
        for i = 2:(length(shat1)-2)
            vectorD2_1(i) = (-2*vector_1(i) + 1*vector_1(i+1) + 1*vector_1(i-1))/(delta_1^2);
        end
        %Numerical derivative in the second domain
        delta_2 = shat2(2)-shat2(1);
        vectorD2_2 = zeros(1,length(shat2));
        vectorD2_2(1) = (1*vector_2(1) - 2*vector_2(2) + vector_2(3))/delta_2^2;
        vectorD2_2(2) = (1*vector_2(2) - 2*vector_2(3) + vector_2(4))/delta_2^2;
        vectorD2_2(end) = (1*vector_2(end) -2*vector_2(end-1) + 1*vector_2(end-2))/delta_2^2;
        for i = 3:(length(shat2)-1)
            vectorD2_2(i) = (-2*vector_2(i) + 1*vector_2(i+1) + 1*vector_2(i-1))/(delta_2^2);
        end
        vectorD2(1:length(shat1)-1) = vectorD2_1(1:end-1);
        vectorD2(length(shat1)) = (vectorD2_1(end-1) + vectorD2_2(2))/2;
        vectorD2((length(shat1)+1):(length(shat1) + length(shat2) - 1)) = vectorD2_2(2:end);
    end
end
using DelimitedFiles

cd(@__DIR__)
Nas = 4
Nrs = 4

name = "StaticSolutions_Nonlinear_Algebraic_Equations_I.m"
file = open(name,"w") # w -> write

write(file,"function Nonlinear_Algebraic_Equations_Value_Vector = StaticSolutions_Nonlinear_Algebraic_Equations_I(Gs,V1s,V2s,V3s,V4s,V5s,V6s,V7s) \r\n") #\r -> indicate the end of lines; \n -> break line

#Writing the generalized coordinates Asn and Dsn using the correspondent vector Gs
for k = 1:Nas
    write(file,"A_1s$k = Gs($k); \r\n")
end
for k = 1:Nrs
    local entry1 = Nas + k
    write(file,"D_1s$k = Gs($entry1); \r\n")
end
############################### k = 1:Nas (A_1s) ##################################
for k = 1:Nas
    write(file,"Nonlinear_Algebraic_Equations_Value_Vector($k,1) = ")

    # Sum A_1s,n
    for n = 1:Nas
        write(file,"A_1s$n*V1s($k,$n) + ")
    end
    # SumSum D_1s,n D_1s,m
    for n = 1:Nrs
        for m = 1:Nrs
            write(file,"D_1s$n*D_1s$m*V2s($k,$n,$m) + ")
        end
    end
    # Constant term in the end
    write(file,"V3s($k); \r\n")
end
################################# k = 1:Nrs (D_1s) #####################################
for k = 1:Nrs
    local entry1 = Nas + k
    write(file,"Nonlinear_Algebraic_Equations_Value_Vector($entry1,1) = ")

    # SumSum A_1s,n D_1s,m
    for n = 1:Nas
        for m = 1:Nrs
            write(file,"A_1s$n*D_1s$m*V4s($k,$n,$m) + ")
        end
    end
    # SumSumSum D_1s,n D_1s,m D_1s,p
    for n = 1:Nrs
        for m = 1:Nrs
            for p = 1:Nrs
                write(file,"D_1s$n*D_1s$m*D_1s$p*V5s($k,$n,$m,$p) + ")
            end
        end
    end
    # Sum D_1s,n
    for n = 1:Nrs
        write(file,"D_1s$n*V6s($k,$n) + ")
    end
    # Constant term in the end
    write(file,"V7s($k); \r\n")
end
write(file,"end")
close(file)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% PIPE DISCHARGING FLUID - MAIN %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all 
clc
%% MAIN SETUP
% Dimensionless arclength coordinate
resolution = 1001; % Discretization of the longitudinal axis
shat = linspace(0,1,resolution); % Longitudinal axis
% Relevant dimensionless parameters for the STATIC solutions

gamma = 0; % = (m + M)gL^3/(EIy) 
u = 20; % = sqrt(M/EIy)UL 

k0 = 0; % = MtL/(GIp)
mnhat = 0; % = mn/(m + M)L
xibar = 0.5; % = xbar/L -> controls both additions

k1 = 2; % = EIp/(EIy)
k2 = 1000; % = EAL^2/(EIy)
k3 = 0.7; % = GIp/(EIy)
k4 = 0.001; % = EI4/(EIyL^2)
Chatstheta = 10; % = (Csx L)/(EIy)
% Relevant dimensionless parameters only for the DYNAMIC solutions
beta = 0.2; % M/(m + M)
Chatsy = 1000; % = (Csy L)/(EIy)
Chatsz = 1000; % = (Csz L)/(EIy)
k5 = 0.001; % = Jp/((m + M)L^2)
Ihat = 1; % = Iz/Iy
chatx = 0.0; % = (cx L^2)/sqrt(EIy(m + M))
chaty = 0.0; % = (cy L^2)/sqrt(EIy(m + M))
chatz = 0.0; % = (cz L^2)/sqrt(EIy(m + M))
chattheta = 0.0; % = ctheta/sqrt(EIy(m + M))
% Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC (for dynamic and static). Also affects the initial guess for the fsolve.
UseSupportSprings = 0;
% Numerical integration parameters, number of shape functions and IC
% Number of shape functions
Na = 3; % Number of axial modal shapes
Nr = 4; % Number of torsional modal shapes
Nt = 7; % Number of transverse modal shapes
% Simulation time
tf = 10; % Total simulation time
dt = 0.001; % Time step in the output
n = tf/dt+1; % Number of time steps
time = linspace(0,tf,n); % Time vector
% Initial conditions - No initial torsion shape for 3D initial conditions is inside DynamicalSolutions_Modal_Shapes.m
InitialConditions = zeros(2*(Na + 2*Nt + Nr),1);
InitialConditions(Na) = 1; % Inextensibility related initial shape
InitialConditions(Na + 1) = 0.002; 
InitialConditions(Na + Nt + 2) = 0.002;  
% Plot options on(1)/off(0)
PlotPolynomialShapes = 1; % Static
PlotStaticSolutions = 1; % Static
PlotModalShapeFunctions = 1; % Dynamic
PlotDynamicSolutions = 1; % Dynamic
Make3DAnimation = 1; % Dynamic
%% AXIAL AND TORSIONAL STATIC SOLUTIONS
%Number of shapes in each static solution
Nas = 4; % Number of axial shapes for the static configuration
Nrs = 4; % Number of torsional shapes for the static configuration
%Solver options for the fsolve and solution evaluation
MaxIterations_fsolve = 400; %400 is default
MaxFunctionEvaluations_fsolve = 2000; %2000 is default
[xis,xisD1,xisD2,thetaxs,thetaxsD1,thetaxsD2,numberofdomains] = StaticSolutions_Main(PlotPolynomialShapes,UseSupportSprings,Nas,Nrs,shat,gamma,k0,k1,k2,k3,k4,mnhat,xibar,Chatstheta,u,MaxIterations_fsolve,MaxFunctionEvaluations_fsolve);
%% PLOTS OF THE AXIAL AND TORSIONAL STATIC SOLUTIONS
if PlotStaticSolutions == 1
    %Analytical static axial solution for the linear problem
    if xibar==1 || mnhat==0
        xisanal = -gamma/(2*k2)*shat.^2 + (gamma - u^2 + mnhat*gamma)/k2*shat;
    elseif xibar>0 && xibar<1 %Only executes if mnhat~=0
        LD = xibar;
        shat1plot = shat(1:round((length(shat)-1)*LD) + 1);
        shat2plot = shat(round((length(shat)-1)*LD) + 2:end); %first entry of the second vector is ignored
        %Very slight correction of xibar to match the vector entries
        xibar_plot = shat1plot(end); %Name change because I dont want to change the actual value
        xisanal_1 = -gamma/(2*k2)*shat1plot.^2 + (gamma - u^2 + mnhat*gamma)/k2*shat1plot;
        xisanal_2 = -gamma/(2*k2)*shat2plot.^2 + (gamma - u^2)/k2*shat2plot + mnhat*gamma*xibar_plot/k2;
        xisanal = [xisanal_1 xisanal_2];
    end
    %Analytical static torsional solution for the linear problem
    if UseSupportSprings==1
        if xibar==1 || k0==0
            thetaxsanal = k0*shat + k0*k3/Chatstheta;
        elseif xibar>0 && xibar<1 %Only executes if k0~=0
            LD = xibar;
            shat1plot = shat(1:round((length(shat)-1)*LD) + 1);
            shat2plot = shat(round((length(shat)-1)*LD) + 2:end); %first entry of the second vector is ignored
            %Very slight correction of xibar to match the vector entries
            xibarplot = shat1plot(end); %Name change because I dont want to change the actual value
            thetaxsanal_1 = k0*shat1plot + k0*k3/Chatstheta;
            thetaxsanal_2 = (k0*k3/Chatstheta + k0*xibarplot)*ones(1,length(shat2plot));
            thetaxsanal = [thetaxsanal_1 thetaxsanal_2];
        end
    elseif UseSupportSprings==0
        if xibar==1 || k0==0
            thetaxsanal = k0*shat;
        elseif xibar>0 && xibar<1 %Only executes if k0~=0
            LD = xibar;
            shat1plot = shat(1:round((length(shat)-1)*LD) + 1);
            shat2plot = shat(round((length(shat)-1)*LD) + 2:end); %first entry of the second vector is ignored
            %Very slight correction of xibar to match the vector entries
            xibarplot = shat1plot(end); %Name change because I dont want to change the actual value
            thetaxsanal_1 = k0*shat1plot;
            thetaxsanal_2 = k0*xibarplot*ones(1,length(shat2plot));
            thetaxsanal = [thetaxsanal_1 thetaxsanal_2];
        end
    end
    fontsize = 24;
    %Axial plot
    fig = figure();
    fig.Renderer='Painters';
    subplot(2,1,1)
    plot(shat,xis,'k','linewidth',1.0)
    pbaspect([3 1 1])
    ax = gca;
    %ax.YLim = [min(xis) max(xis)];
    % ax.YTick = [ ];
    %ax.XLim = [shat(1) shat(end)];
    % ax.XTick = [ ];
    ax.YAxis.FontSize = 15;
    ax.XAxis.FontSize = 15;
    ylab = ylabel('$\xi^{}_{s}$','rotation',0,'interpreter','latex','FontSize',fontsize);
    ylab.Position(1) = ylab.Position(1) + 0.05;
    ylab.Position(2) = ylab.Position(2) - 0;
    xlab = xlabel('$\hat{s}$','rotation',0,'interpreter','latex','FontSize',fontsize);
    hold on
    plot(shat,xisanal,'r','linewidth',0.5);
    h = legend('Nonlinear system','Linearized system','Location','northeast','FontSize',13);
    %Torsional plot
    subplot(2,1,2)
    plot(shat,thetaxs,'k','linewidth',1.0)
    pbaspect([3 1 1])
    ax = gca;
    %ax.YLim = [min(xis) max(xis)];
    % ax.YTick = [ ];
    %ax.XLim = [shat(1) shat(end)];
    % ax.XTick = [ ];
    ax.YAxis.FontSize = 15;
    ax.XAxis.FontSize = 15;
    ylab = ylabel('$\theta^{}_{x,s}$','rotation',0,'interpreter','latex','FontSize',fontsize);
    ylab.Position(1) = ylab.Position(1) -0.01;
    ylab.Position(2) = ylab.Position(2) + 0;
    xlab = xlabel('$\hat{s}$','rotation',0,'interpreter','latex','FontSize',fontsize);
    hold on
    plot(shat,thetaxsanal,'r','linewidth',0.5);
    hold on
    h = legend('Nonlinear system','Linearized system','Location','southeast','FontSize',13);
    %set(h,'interpreter','latex')
    print('Export\StaticSolutions',fig,'-dpdf','-fillpage')
    close all
end
%% DYNAMICAL SOLUTIONS
[t,q,AMS_frequency_vector,RMS_frequency_vector,TMS_frequency_vector,x0,xid,eta,zeta,thetaxd] = DynamicalSolutions_Main(numberofdomains,PlotModalShapeFunctions,UseSupportSprings,Na,Nr,Nt,shat,k0,k1,k2,k3,k4,u,mnhat,xibar,Chatstheta,beta,Chatsy,Chatsz,k5,Ihat,chatx,chaty,chatz,chattheta,xis,xisD1,xisD2,thetaxs,thetaxsD1,thetaxsD2,time,InitialConditions);
%% PLOTS AND EXPORT OF THE DYNAMICAL SOLUTIONS
if PlotDynamicSolutions == 1
    % Time series of the displacements of the free end
    fontsizelabelfig = 20;
    fontsizeticksfig = 15;

    fig = figure();
    fig.Renderer='Painters';

    subplot(4,1,1)
    plot(t,xid(end,:),'k','linewidth',1.0);
    ax = gca;
    ax.XLim = [t(1) t(end)];
    % ax.XTick = [ ];
    % ax.YLim = [ ];
    % ax.YTick = [ ];
    ax.YAxis.FontSize = fontsizeticksfig;
    ax.XAxis.FontSize = fontsizeticksfig;
    xlab = xlabel('$\tau$','rotation',0,'interpreter','latex','FontSize',fontsizelabelfig);
    ylab = ylabel('$\xi_{d}^{}(\hat{s} = 1,\tau)$','rotation',0,'interpreter','latex','FontSize',fontsizelabelfig);
    %ylab.Position(1) = ylab.Position(1) + 0;
    %ylab.Position(2) = ylab.Position(2) + 0;
    %ylim([-0.1 0.1])

    subplot(4,1,2)
    plot(t,eta(end,:),'k','linewidth',1.0);
    ax = gca;
    %ax.XLim = [90 100];
    % ax.XTick = [ ];
    % ax.YLim = [ ];
    % ax.YTick = [ ];
    ax.YAxis.FontSize = fontsizeticksfig;
    ax.XAxis.FontSize = fontsizeticksfig;
    xlab = xlabel('$\tau$','rotation',0,'interpreter','latex','FontSize',fontsizelabelfig);
    ylab = ylabel('$\eta(\hat{s} = 1,\tau)$','rotation',0,'interpreter','latex','FontSize',fontsizelabelfig);
    %ylab.Position(1) = ylab.Position(1) + 0;
    %ylab.Position(2) = ylab.Position(2) + 0;

    subplot(4,1,3)
    plot(t,zeta(end,:),'k','linewidth',1.0);
    ax = gca;
    %ax.XLim = [90 100];
    % ax.XTick = [ ];
    % ax.YLim = [ ];
    % ax.YTick = [ ];
    ax.YAxis.FontSize = fontsizeticksfig;

    ax.XAxis.FontSize = fontsizeticksfig;
    xlab = xlabel('$\tau$','rotation',0,'interpreter','latex','FontSize',fontsizelabelfig);
    ylab = ylabel('$\zeta(\hat{s} = 1,\tau)$','rotation',0,'interpreter','latex','FontSize',fontsizelabelfig);
    %ylab.Position(1) = ylab.Position(1) + 0;
    %ylab.Position(2) = ylab.Position(2) + 0;

    subplot(4,1,4)
    plot(t,thetaxd(end,:),'k','linewidth',1.0);
    ax = gca;
    ax.XLim = [t(1) t(end)];
    % ax.XTick = [ ];
    % ax.YLim = [ ];
    % ax.YTick = [ ];
    ax.YAxis.FontSize = fontsizeticksfig;
    ax.XAxis.FontSize = fontsizeticksfig;
    xlab = xlabel('$\tau$','rotation',0,'interpreter','latex','FontSize',fontsizelabelfig);
    ylab = ylabel('$\theta_{x,d}^{}(\tau)$','rotation',0,'interpreter','latex','FontSize',fontsizelabelfig);
    ylab.Position(1) = ylab.Position(1) + 0;
    ylab.Position(2) = ylab.Position(2) + 0;
    %ylim([-0.1 0.1])
    print('Export\DynamicalSolutions',fig,'-dpdf','-fillpage')
end
% dlmwrite('Export\xi.csv',xid,'delimiter',',','precision',16)
% dlmwrite('Export\eta.csv',eta,'delimiter',',','precision',16)
% dlmwrite('Export\zeta.csv',zeta,'delimiter',',','precision',16)
% dlmwrite('Export\theta.csv',thetaxd,'delimiter',',','precision',16)
% dlmwrite('Export\t.csv',t,'delimiter',',','precision',16)
%% 3D ANIMATION OF THE CARTESIAN COORDINATES
if Make3DAnimation == 1
    % Cartesian Coordinates
    xis_animation = zeros(length(shat),length(t));
    thetaxs_animation = zeros(length(shat),length(t));
    for i = 1:length(t)
        xis_animation(:,i) = xis;
        thetaxs_animation(:,i) = thetaxs;
    end
    X = x0 + xis_animation + xid;
    Y = eta;
    Z = zeta;
    thetax = thetaxs_animation + thetaxd;
    fig = figure();
    fig.Position = [10 10 1800 900];
    coef = 5;
    for tim = 1:floor(length(t)/coef)%length(t)
        plot3(Y(:,coef*tim),Z(:,coef*tim),X(:,coef*tim),'k','linewidth',1.5)
        xlim([-1,1])
        ylim([-1,1])
        zlim([0,1.12])
        set(gca,'Zdir','reverse')
        xlabel('Y');
        ylabel('Z');
        zlabel('X');
        hold on
        plot3(Y(:,coef*tim), 1*ones(size(Z(:,coef*tim))), X(:,coef*tim),'r','LineWidth', 1.5); 
        quiver3(Y(end,coef*tim),1*ones(size(Z(end,coef*tim))),X(end,coef*tim),Y(end,coef*tim) - Y(end-1,coef*tim),0,X(end,coef*tim) - X(end-1,coef*tim),100,'b','MaxHeadSize',10,'LineWidth',1.0)
        plot3(1*ones(size(Y(:,coef*tim))), Z(:,coef*tim), X(:,coef*tim),'r','LineWidth', 1.5); 
        quiver3(1*ones(size(Y(end,coef*tim))),Z(end,coef*tim),X(end,coef*tim),0,Z(end,coef*tim) - Z(end-1,coef*tim),X(end,coef*tim) - X(end-1,coef*tim),100,'b','MaxHeadSize',10,'LineWidth',1.0)
        plot3(Y(:,coef*tim), Z(:,coef*tim), 1.12*ones(size(X(:,coef*tim))),'r','LineWidth', 1.5);
        quiver3(Y(end,coef*tim),Z(end,coef*tim),1.12*ones(size(X(end,coef*tim))),Y(end,coef*tim) - Y(end-1,coef*tim),Z(end,coef*tim) - Z(end-1,coef*tim),0,100,'b','MaxHeadSize',10,'LineWidth',1.0)
        grid on
        quiver3(Y(end,coef*tim),Z(end,coef*tim),X(end,coef*tim),Y(end,coef*tim) - Y(end-1,coef*tim),Z(end,coef*tim) - Z(end-1,coef*tim),X(end,coef*tim) - X(end-1,coef*tim),100,'b','MaxHeadSize',10,'LineWidth',1.0)
        hold off
        F(tim) = getframe(fig); 
    end
    writerObj = VideoWriter('Export\3DAnimation.avi');
    writerObj.FrameRate = 30;
    %writerObj.Quality = 100;
    open(writerObj);
    writeVideo(writerObj, F(1:floor(length(t)/coef)))
    close(writerObj);
end
close all

%%
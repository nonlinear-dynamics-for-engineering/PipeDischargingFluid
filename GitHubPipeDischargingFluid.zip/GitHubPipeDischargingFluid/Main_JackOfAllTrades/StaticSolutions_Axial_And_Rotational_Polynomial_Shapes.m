function [numberofdomains,AMS_1_matrix,AMSD1_1_matrix,AMSD2_1_matrix,AMS_2_matrix,AMSD1_2_matrix,AMSD2_2_matrix,RMS_1_matrix,RMSD1_1_matrix,RMSD2_1_matrix,RMS_2_matrix,RMSD1_2_matrix,RMSD2_2_matrix,shat1,shat2] = StaticSolutions_Axial_And_Rotational_Polynomial_Shapes(UseSupportSprings,Nas,Nrs,shat,mnhat,k0,xibar)
	if (mnhat==0 && k0==0) || xibar == 1
        %% ONE DOMAIN
        numberofdomains = 1;
        disp('------------------------------------------------------')    
        disp('Evaluating Axial and Torsional Polynomial Shapes Using ONE Domain...')
        tic
        shat1 = shat;
        %for the output only
        shat2 = nan;
        %% SHAPES AND DERIVATIVES FOR THE AXIAL STATIC SOLUTION
        AMS_1_matrix = zeros(Nas,length(shat1));
        AMSD1_1_matrix = zeros(Nas,length(shat1));
        AMSD2_1_matrix = zeros(Nas,length(shat1));
        for i = 1:Nas
            if i == 1   
                AMS_1_matrix(i,:) = shat1;
                AMSD1_1_matrix(i,:) = ones(length(shat1),1);
                AMSD2_1_matrix(i,:) = zeros(length(shat1),1);

            else
                AMS_1_matrix(i,:) = shat1.^i;
                AMSD1_1_matrix(i,:) = i*shat1.^(i-1);
                AMSD2_1_matrix(i,:) = i*(i-1)*shat1.^(i-2);
            end
        end
        %% SHAPES AND DERIVATIVES FOR THE TORSIONAL STATIC SOLUTION
        RMS_1_matrix = zeros(Nrs,length(shat1));
        RMSD1_1_matrix = zeros(Nrs,length(shat1));
        RMSD2_1_matrix = zeros(Nrs,length(shat1));
        for i = 1:Nrs
            if i == 1   
                RMS_1_matrix(i,:) = shat1;
                RMSD1_1_matrix(i,:) = ones(length(shat1),1);
                RMSD2_1_matrix(i,:) = zeros(length(shat1),1);
            elseif i < Nrs
                RMS_1_matrix(i,:) = shat1.^i;
                RMSD1_1_matrix(i,:) = i*shat1.^(i-1);
                RMSD2_1_matrix(i,:) = i*(i-1)*shat1.^(i-2);
            else 
                if UseSupportSprings == 1
                    RMS_1_matrix(i,:) = ones(length(shat1),1);
                    RMSD1_1_matrix(i,:) = zeros(length(shat1),1);
                    RMSD2_1_matrix(i,:) = zeros(length(shat1),1);
                end
                if UseSupportSprings == 0
                    RMS_1_matrix(i,:) = shat1.^i;
                    RMSD1_1_matrix(i,:) = i*shat1.^(i-1);
                    RMSD2_1_matrix(i,:) = i*(i-1)*shat1.^(i-2);
                end
            end
        end
        %% SETTING SECOND-DOMAIN SHAPE FUNCTIONS AS NANs TO MATCH FUNCTION OUTPUT
        AMS_2_matrix = nan;
        AMSD1_2_matrix = nan;
        AMSD2_2_matrix = nan;
        RMS_2_matrix = nan;
        RMSD1_2_matrix = nan;
        RMSD2_2_matrix = nan;
	end
    
    if (mnhat~=0 || k0~=0) && xibar > 0 && xibar < 1
        %% TWO DOMAINS
        numberofdomains = 2;
        disp('------------------------------------------------------')    
        disp('Evaluating Axial and Torsional Polynomial Shapes Using TWO Domains...')
        tic
        %Domain definition
        LD = xibar;
        shat1 = shat(1:round((length(shat)-1)*LD) + 1);
        shat2 = shat(round((length(shat)-1)*LD) + 1:end);
        %Very slight correction of LD to match the vector entries
        LD = shat1(end);
        %% SHAPES AND DERIVATIVES FOR THE AXIAL STATIC SOLUTION
        %First domain
        AMS_1_matrix = zeros(Nas,length(shat1));
        AMSD1_1_matrix = zeros(Nas,length(shat1));
        AMSD2_1_matrix = zeros(Nas,length(shat1));
        for i = 1:Nas
            if i == 1   
                AMS_1_matrix(i,:) = shat1/LD;
                AMSD1_1_matrix(i,:) = ones(length(shat1),1)/LD;
                AMSD2_1_matrix(i,:) = zeros(length(shat1),1);

            else
                AMS_1_matrix(i,:) = (shat1/LD).^i;
                AMSD1_1_matrix(i,:) = (i/LD)*(shat1/LD).^(i-1);
                AMSD2_1_matrix(i,:) = (i/LD^2)*(i-1)*(shat1/LD).^(i-2);
            end
        end
        %Second domain
        AMS_2_matrix = zeros(Nas,length(shat2));
        AMSD1_2_matrix = zeros(Nas,length(shat2));
        AMSD2_2_matrix = zeros(Nas,length(shat2));
        for i = 1:Nas
            if i == 1   
                AMS_2_matrix(i,:) = (shat2 - LD)/(1 - LD);
                AMSD1_2_matrix(i,:) = ones(length(shat2),1)/(1 - LD);
                AMSD2_2_matrix(i,:) = zeros(length(shat2),1);

            else
                AMS_2_matrix(i,:) = ((shat2 - LD)/(1 - LD)).^i;
                AMSD1_2_matrix(i,:) = (i/(1 - LD))*((shat2 - LD)/(1 - LD)).^(i-1);
                AMSD2_2_matrix(i,:) = (i/(1 - LD)^2)*(i-1)*((shat2 - LD)/(1 - LD)).^(i-2);
            end
        end
        %% SHAPES AND DERIVATIVES FOR THE TORSIONAL STATIC SOLUTION
        %First domain - the only one with rigid body shape if UseSupportSprings = 1
        RMS_1_matrix = zeros(Nrs,length(shat1));
        RMSD1_1_matrix = zeros(Nrs,length(shat1));
        RMSD2_1_matrix = zeros(Nrs,length(shat1));
        for i = 1:Nrs
            if i == 1   
                RMS_1_matrix(i,:) = shat1/LD;
                RMSD1_1_matrix(i,:) = ones(length(shat1),1)/LD;
                RMSD2_1_matrix(i,:) = zeros(length(shat1),1);

            elseif i < Nrs
                RMS_1_matrix(i,:) = (shat1/LD).^i;
                RMSD1_1_matrix(i,:) = (i/LD)*(shat1/LD).^(i-1);
                RMSD2_1_matrix(i,:) = (i/LD^2)*(i-1)*(shat1/LD).^(i-2);
            else 
                if UseSupportSprings == 1
                    RMS_1_matrix(i,:) = ones(length(shat1),1);
                    RMSD1_1_matrix(i,:) = zeros(length(shat1),1);
                    RMSD2_1_matrix(i,:) = zeros(length(shat1),1);
                end
                if UseSupportSprings == 0
                    RMS_1_matrix(i,:) = (shat1/LD).^i;
                RMSD1_1_matrix(i,:) = (i/LD)*(shat1/LD).^(i-1);
                RMSD2_1_matrix(i,:) = (i/LD^2)*(i-1)*(shat1/LD).^(i-2);
                end
            end
        end
        %Second domain
        RMS_2_matrix = zeros(Nrs,length(shat2));
        RMSD1_2_matrix = zeros(Nrs,length(shat2));
        RMSD2_2_matrix = zeros(Nrs,length(shat2));
        for i = 1:Nas
            if i == 1   
                RMS_2_matrix(i,:) = (shat2 - LD)/(1 - LD);
                RMSD1_2_matrix(i,:) = ones(length(shat2),1)/(1 - LD);
                RMSD2_2_matrix(i,:) = zeros(length(shat2),1);

            else
                RMS_2_matrix(i,:) = ((shat2 - LD)/(1 - LD)).^i;
                RMSD1_2_matrix(i,:) = (i/(1 - LD))*((shat2 - LD)/(1 - LD)).^(i-1);
                RMSD2_2_matrix(i,:) = (i/(1 - LD)^2)*(i-1)*((shat2 - LD)/(1 - LD)).^(i-2);
            end
        end
    end
    toc 
end
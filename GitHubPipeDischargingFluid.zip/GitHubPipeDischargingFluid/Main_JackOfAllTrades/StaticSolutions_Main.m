function [xis,xisD1,xisD2,thetaxs,thetaxsD1,thetaxsD2,numberofdomains] = StaticSolutions_Main(PlotPolynomialShapes,UseSupportSprings,Nas,Nrs,shat,gamma,k0,k1,k2,k3,k4,mnhat,xibar,Chatstheta,u,MaxIterations_fsolve,MaxFunctionEvaluations_fsolve)
    disp('______________________________________________________')
    disp('EVALUATION OF THE AXIAL AND TORSIONAL STATIC SOLUTIONS')
    tstaticsolutions = tic;    
    %% POLYNOMIAL SHAPES AND DERIVATIVES - ALSO DEFINES THE numberofdomains TO BE USED IN THE FOLLOWING SECTIONS
    [numberofdomains,AMS_1_matrix,AMSD1_1_matrix,AMSD2_1_matrix,AMS_2_matrix,AMSD1_2_matrix,AMSD2_2_matrix,RMS_1_matrix,RMSD1_1_matrix,RMSD2_1_matrix,RMS_2_matrix,RMSD1_2_matrix,RMSD2_2_matrix,shat1,shat2] = StaticSolutions_Axial_And_Rotational_Polynomial_Shapes(UseSupportSprings,Nas,Nrs,shat,mnhat,k0,xibar);
    %% PLOTS OF THE POLYNOMIAL SHAPES CHECKING THE numberofdomains
    if numberofdomains == 1 %Case with one domain
        if PlotPolynomialShapes == 1
            fig = figure();
            fig.Renderer='Painters';
            subplot(2,1,1)
            for i = 1:Nas
                plot(shat1,AMS_1_matrix(i,:),'linewidth',1.0)
                ax = gca;
                %ax.YLim = [min(xis) max(xis)];
                % ax.YTick = [ ];
                %ax.XLim = [shat(1) shat(end)];
                % ax.XTick = [ ];
                ax.YAxis.FontSize = 12;
                ax.XAxis.FontSize = 12;
                ylab = ylabel('$\phi^{}_{s,n}$','rotation',0,'interpreter','latex','FontSize',20);
                %ylab.Position(1) = ylab.Position(1) -0.01;
                %ylab.Position(2) = ylab.Position(2) + 1;
                xlab = xlabel('$\hat{s}$','rotation',0,'interpreter','latex','FontSize',20);
                hold on
            end
            subplot(2,1,2)
            for i = 1:Nrs
                plot(shat1,RMS_1_matrix(i,:),'linewidth',1.0)
                ax = gca;
                %ax.YLim = [min(xis) max(xis)];
                % ax.YTick = [ ];
                %ax.XLim = [shat(1) shat(end)];
                % ax.XTick = [ ];
                ax.YAxis.FontSize = 12;
                ax.XAxis.FontSize = 12;
                ylab = ylabel('$\Theta^{}_{s,n}$','rotation',0,'interpreter','latex','FontSize',20);
                %ylab.Position(1) = ylab.Position(1) -0.01;
                %ylab.Position(2) = ylab.Position(2) + 1;
                xlab = xlabel('$\hat{s}$','rotation',0,'interpreter','latex','FontSize',20);
                hold on
            end
            print('Export\PolynomialShapes',fig,'-dpdf','-fillpage')
        end
    end
    if numberofdomains == 2 %Case with two domains
        if PlotPolynomialShapes == 1
            fig = figure();
            fig.Renderer='Painters';
            subplot(2,1,1)
            for i = 1:Nas
                plot(shat1,AMS_1_matrix(i,:),'linewidth',1.0)
                hold on
                plot(shat2,AMS_2_matrix(i,:),'linewidth',1.0)
                ax = gca;
                %ax.YLim = [min(xis) max(xis)];
                % ax.YTick = [ ];
                %ax.XLim = [shat(1) shat(end)];
                % ax.XTick = [ ];
                ax.YAxis.FontSize = 12;
                ax.XAxis.FontSize = 12;
                ylab = ylabel('$\phi^{}_{s,n}$','rotation',0,'interpreter','latex','FontSize',20);
                %ylab.Position(1) = ylab.Position(1) -0.01;
                %ylab.Position(2) = ylab.Position(2) + 1;
                xlab = xlabel('$\hat{s}$','rotation',0,'interpreter','latex','FontSize',20);
                hold on
            end
            subplot(2,1,2)
            for i = 1:Nrs
                plot(shat1,RMS_1_matrix(i,:),'linewidth',1.0)
                hold on
                plot(shat2,RMS_2_matrix(i,:),'linewidth',1.0)
                ax = gca;
                %ax.YLim = [min(xis) max(xis)];
                % ax.YTick = [ ];
                %ax.XLim = [shat(1) shat(end)];
                % ax.XTick = [ ];
                ax.YAxis.FontSize = 12;
                ax.XAxis.FontSize = 12;
                ylab = ylabel('$\Theta^{}_{s,n}$','rotation',0,'interpreter','latex','FontSize',20);
                %ylab.Position(1) = ylab.Position(1) -0.01;
                %ylab.Position(2) = ylab.Position(2) + 1;
                xlab = xlabel('$\hat{s}$','rotation',0,'interpreter','latex','FontSize',20);
                hold on
            end
            print('Export\PolynomialShapes',fig,'-dpdf','-fillpage')
        end
    end
    close all
    %% EVALUATION OF THE COEFFICIENTS FOR THE NONLINEAR ALGEBRAIC EQUATIONS 
    [V1s,V2s,V3s,V4s,V5s,V6s,V7s,V8s,V9s,V10s,V11s,V12s,V13s,V14s,V15s,V16s,V17s,V18s,V19s,V20s] = StaticSolutions_Galerkin_Matrices_Evaluation(numberofdomains,UseSupportSprings,shat1,shat2,Nas,Nrs,gamma,k0,k1,k2,k3,k4,u,mnhat,Chatstheta,AMS_1_matrix,AMSD1_1_matrix,AMSD2_1_matrix,AMS_2_matrix,AMSD1_2_matrix,AMSD2_2_matrix,RMS_1_matrix,RMSD1_1_matrix,RMSD2_1_matrix,RMS_2_matrix,RMSD1_2_matrix,RMSD2_2_matrix);
    %% SOLVING THE NONLINEAR SYSTEM OF ALGEBRAIC EQUATIONS - ONE OR TWO OR THREE DOMAINS
    %% ONE DOMAIN - Eqn set Is
    if numberofdomains == 1
        %Initial guesses for the gen. coord. - solutions of the linear case
        Gs0 = zeros(1*(Nas + Nrs),1);
        Gs0(1) = (gamma - u^2)/k2;
        Gs0(2) = -gamma/(2*k2);
        Gs0(Nas + 1) = k0;
        if UseSupportSprings == 1
            Gs0(Nas + Nrs) = k0*k3/Chatstheta;
        end
        %Obtaining the solutions
        disp('------------------------------------------------------')
        disp('Solving The System of Algebraic Nonlinear Equations Using ONE Domain...')
        options = optimoptions('fsolve'); 
        options.MaxIterations = MaxIterations_fsolve;
        options.MaxFunctionEvaluations = MaxFunctionEvaluations_fsolve;
        tic
        disp('Using eqn set number Is.');
        Gssol = fsolve(@(Gs) StaticSolutions_Nonlinear_Algebraic_Equations_I(Gs,V1s,V2s,V3s,V4s,V5s,V6s,V7s), Gs0,options);
        toc
        disp('------------------------------------------------------')
        %Reconstruction of the displacements fields then assembly into one vector
        xis_1 = (Gssol(1:Nas)'*AMS_1_matrix)';
        xis_1 = xis_1';
        xis = xis_1;

        thetaxs_1 = (Gssol((Nas+1):(Nas+Nrs))'*RMS_1_matrix)';
        thetaxs_1 = thetaxs_1';
        thetaxs = thetaxs_1;

        %First and second derivatives then assembly into one vector
        xisD1_1 = (Gssol(1:Nas)'*AMSD1_1_matrix)';
        xisD1_1 = xisD1_1';
        xisD1 = xisD1_1;
        
        thetaxsD1_1 = (Gssol((Nas+1):(Nas+Nrs))'*RMSD1_1_matrix)';
        thetaxsD1_1 = thetaxsD1_1';
        thetaxsD1 = thetaxsD1_1;
        
        xisD2_1 = (Gssol(1:Nas)'*AMSD2_1_matrix)';
        xisD2_1 = xisD2_1';
        xisD2 = xisD2_1;
        
        thetaxsD2_1 = (Gssol((Nas+1):(Nas+Nrs))'*RMSD2_1_matrix)';
        thetaxsD2_1 = thetaxsD2_1';
        thetaxsD2 = thetaxsD2_1;
    end
    %% TWO DOMAINS - Eqn set IIs
    if numberofdomains == 2
        %Initial guesses for the gen. coord. - solutions of the linear case
        Gs0 = zeros(2*(Nas + Nrs),1);
        Gs0(1) = (gamma - u^2)/k2;
        Gs0(Nas + 1) = (gamma - u^2)/k2;

        Gs0(2) = -gamma/(2*k2);
        Gs0(Nas + 2) = -gamma/(2*k2);

        Gs0(2*Nas + 1) = k0;
        Gs0(2*Nas + Nrs + 1) = k0;
        if UseSupportSprings == 1
            Gs0(2*Nas + Nrs) = k0*k3/Chatstheta;
        end
        %Obtaining the solutions
        disp('------------------------------------------------------')
        disp('Solving The System of Algebraic Nonlinear Equations Using TWO Domains...')
        options = optimoptions('fsolve'); 
        options.MaxIterations = MaxIterations_fsolve;
        options.MaxFunctionEvaluations = MaxFunctionEvaluations_fsolve;
        tic
        disp('Using eqn set number IIs.');
        Gssol = fsolve(@(Gs) StaticSolutions_Nonlinear_Algebraic_Equations_II(Gs,V1s,V2s,V3s,V4s,V5s,V6s,V7s,V8s,V9s,V10s,V11s,V12s,V13s,V14s,V15s,V16s,V17s,V18s,V19s,V20s), Gs0,options);
        toc
        disp('------------------------------------------------------')
        %Initializing the final vectors
        xis = zeros(1,length(shat));
        xisD1 = zeros(1,length(shat));
        xisD2 = zeros(1,length(shat));
        thetaxs = zeros(1,length(shat));
        thetaxsD1 = zeros(1,length(shat));
        thetaxsD2 = zeros(1,length(shat));
        %Reconstruction of the displacements fields then assembly into one vector
        xis_1 = (Gssol(1:Nas)'*AMS_1_matrix)';
        xis_1 = xis_1';
        xis_2 = (Gssol((Nas + 1):2*Nas)'*AMS_2_matrix)' + (Gssol(1:Nas)'*AMS_1_matrix(:,end))';
        xis_2 = xis_2';
        xis(1:length(shat1)) = xis_1;
        xis((length(shat1) + 1):(length(shat1) + length(shat2) - 1)) = xis_2(2:end);

        thetaxs_1 = (Gssol((2*Nas+1):(2*Nas+Nrs))'*RMS_1_matrix)';
        thetaxs_1 = thetaxs_1';
        thetaxs_2 = (Gssol((2*Nas+Nrs + 1):(2*Nas+2*Nrs))'*RMS_2_matrix)' + (Gssol((2*Nas+1):(2*Nas+Nrs))'*RMS_1_matrix(:,end))';
        thetaxs_2 = thetaxs_2';
        thetaxs(1:length(shat1)) = thetaxs_1;
        thetaxs((length(shat1) + 1):(length(shat1) + length(shat2) - 1)) = thetaxs_2(2:end);

        %First and second derivatives then assembly into one vector - middle point is always the average
        xisD1_1 = (Gssol(1:Nas)'*AMSD1_1_matrix)';
        xisD1_1 = xisD1_1';
        xisD1_2 = (Gssol((Nas + 1):2*Nas)'*AMSD1_2_matrix)';
        xisD1_2 = xisD1_2';
        xisD1(1:length(shat1)-1) = xisD1_1(1:end-1);
        xisD1(length(shat1)) = (xisD1_1(end) + xisD1_2(1))/2; %average
        xisD1((length(shat1) + 1):(length(shat1) + length(shat2) - 1)) = xisD1_2(2:end);
        
        thetaxsD1_1 = (Gssol((2*Nas+1):(2*Nas+Nrs))'*RMSD1_1_matrix)';
        thetaxsD1_1 = thetaxsD1_1';
        thetaxsD1_2 = (Gssol((2*Nas+Nrs + 1):(2*Nas+2*Nrs))'*RMSD1_2_matrix)';
        thetaxsD1_2 = thetaxsD1_2';
        thetaxsD1(1:length(shat1)-1) = thetaxsD1_1(1:end-1);
        thetaxsD1(length(shat1)) = (thetaxsD1_1(end) + thetaxsD1_2(1))/2; %average
        thetaxsD1((length(shat1) + 1):(length(shat1) + length(shat2) - 1)) = thetaxsD1_2(2:end);
        
        xisD2_1 = (Gssol(1:Nas)'*AMSD2_1_matrix)';
        xisD2_1 = xisD2_1';
        xisD2_2 = (Gssol((Nas + 1):2*Nas)'*AMSD2_2_matrix)';
        xisD2_2 = xisD2_2';
        xisD2(1:length(shat1)-1) = xisD2_1(1:end-1);
        xisD2(length(shat1)) = (xisD2_1(end) + xisD2_2(1))/2; %average
        xisD2((length(shat1) + 1):(length(shat1) + length(shat2) - 1)) = xisD2_2(2:end);
        
        thetaxsD2_1 = (Gssol((2*Nas+1):(2*Nas+Nrs))'*RMSD2_1_matrix)';
        thetaxsD2_1 = thetaxsD2_1';
        thetaxsD2_2 = (Gssol((2*Nas+Nrs + 1):(2*Nas+2*Nrs))'*RMSD2_2_matrix)';
        thetaxsD2_2 = thetaxsD2_2';
        thetaxsD2(1:length(shat1)-1) = thetaxsD2_1(1:end-1);
        thetaxsD2(length(shat1)) = (thetaxsD2_1(end) + thetaxsD2_2(1))/2; %average
        thetaxsD2((length(shat1) + 1):(length(shat1) + length(shat2) - 1)) = thetaxsD2_2(2:end);
    end
    toc(tstaticsolutions);
    disp('______________________________________________________')
end
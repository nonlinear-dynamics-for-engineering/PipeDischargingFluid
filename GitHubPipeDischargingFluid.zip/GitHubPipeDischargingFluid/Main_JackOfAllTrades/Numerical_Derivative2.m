function [vectorD] = Numerical_Derivative2(vector,shat,mnhat,xibar,k0)  
    %% ONE DOMAIN
    if (mnhat==0 && k0==0) || xibar == 1
        delta = shat(2)-shat(1);
        vectorD = zeros(1,length(shat));
        vectorD(1) = (vector(2) - vector(1))/delta;
        vectorD(end) = (vector(end) - vector(end-1))/delta;
        for i = 2:(length(shat)-1)
            vectorD(i) = (vector(i+1) - vector(i-1))/(2*delta);
        end
    end
    %% TWO DOMAINS
    if (mnhat~=0 || k0~=0) && xibar > 0 && xibar < 1
        LD = xibar;
        shat1 = shat(1:round((length(shat)-1)*LD) + 1);
        shat2 = shat(round((length(shat)-1)*LD) + 1:end);
        %Separate vector into two
        vector_1 = vector(1:round((length(shat)-1)*LD) + 1);
        vector_2 = vector(round((length(shat)-1)*LD) + 1:end);
        %Very slight correction of LD to match the vector entries
        LD = shat1(end);
        %Numerical derivative in the first domain
        delta_1 = shat1(2)-shat1(1);
        vectorD_1 = zeros(1,length(shat1));
        vectorD_1(1) = (vector_1(2) - vector_1(1))/delta_1;
        vectorD_1(end-1) = (vector_1(end-1) - vector_1(end-2))/delta_1;
        vectorD_1(end) = (vector_1(end) - vector_1(end-1))/delta_1;
        for i = 2:(length(shat1)-2)
            vectorD_1(i) = (vector_1(i+1) - vector_1(i-1))/(2*delta_1);
        end
        %Numerical derivative in the second domain
        delta_2 = shat2(2)-shat2(1);
        vectorD_2 = zeros(1,length(shat2));
        vectorD_2(1) = (vector_2(2) - vector_2(1))/delta_2;
        vectorD_2(2) = (vector_2(3) - vector_2(2))/delta_2;
        vectorD_2(end) = (vector_2(end) - vector_2(end-1))/delta_2;
        for i = 3:(length(shat2)-1)
            vectorD_2(i) = (vector_2(i+1) - vector_2(i-1))/(2*delta_2);
        end
        vectorD(1:length(shat1)-1) = vectorD_1(1:end-1);
        vectorD(length(shat1)) = (vectorD_1(end-1) + vectorD_2(2))/2;
        vectorD((length(shat1)+1):(length(shat1) + length(shat2) - 1)) = vectorD_2(2:end);
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% PIPE DISCHARGING FLUID - MAIN %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ERROR ANALYSIS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
clc
%% MAIN SETUP - FIXED FOR THIS ANALYSIS, ONLY CASE 4.3.1)
Nas = 4;
Nrs = 4;

% Dimensionless arclength coordinate
resolution = 1001; % Discretization of the longitudinal axis
shat = linspace(0,1,resolution); % Longitudinal axis
% Relevant dimensionless parameters for the STATIC solutions

gamma = 200; % = (m + M)gL^3/(EIy) 
u = 5; % = sqrt(M/EIy)UL 

k0 = 2*pi; % = MtL/(GIp)
xibart = 0.8; % = xbart/L
mnhat = 0.3; % = mn/(m + M)L
xibar = 0.3; % = xbar/L

k1 = 2; % = EIp/(EIy)
k2 = 10000; % = EAL^2/(EIy)
k3 = 0.7; % = GIp/(EIy)
k4 = 0.001; % = EI4/(EIyL^2)
Chatstheta = 10; % = (Csx L)/(EIy)
% Relevant dimensionless parameters only for the DYNAMIC solutions
beta = 0.7; % M/(m + M)
Chatsy = 1000; % = (Csy L)/(EIy)
Chatsz = 1000; % = (Csz L)/(EIy)
k5 = 0.001; % = Jp/((m + M)L^2)
Ihat = 1; % = Iz/Iy
chatx = 0.0; % = (cx L^2)/sqrt(EIy(m + M))
chaty = 0.0; % = (cy L^2)/sqrt(EIy(m + M))
chatz = 0.0; % = (cz L^2)/sqrt(EIy(m + M))
chattheta = 0.0; % = ctheta/sqrt(EIy(m + M))
% Turn SUPPORT SPRINGS on(1)/off(0) - affects shape functions, galerkin matrices and NBC (for dynamic and static). Also affects the initial guess for the fsolve.
UseSupportSprings = 1;
%% AXIAL AND TORSIONAL STATIC SOLUTIONS
%Solver options for the fsolve and solution evaluation
MaxIterations_fsolve = 400; %400 is default
MaxFunctionEvaluations_fsolve = 2000; %2000 is default
[xis,xisD1,xisD2,thetaxs,thetaxsD1,thetaxsD2,xibarentry,xibartentry] = StaticSolutions_Main(UseSupportSprings,Nas,Nrs,shat,gamma,k0,xibart,k1,k2,k3,k4,mnhat,xibar,Chatstheta,u,MaxIterations_fsolve,MaxFunctionEvaluations_fsolve);
%% ERROR EVALUATION
%Numerical entries corresponding to xibar and xibart
xibarentry;
xibartentry;

absolute_internal_work = (trapz(shat,xisD1.*(-k2*xisD1 - (1/2)*k1*(thetaxsD1.^2))) ...
    + trapz(shat,thetaxsD1.*(-k1*xisD1.*thetaxsD1 - (1/2)*k4*(thetaxsD1.^3) - k3*thetaxsD1)))

absolute_error = abs(trapz(shat,xisD1.*(-k2*xisD1 - (1/2)*k1*(thetaxsD1.^2))) ...
    + trapz(shat,thetaxsD1.*(-k1*xisD1.*thetaxsD1 - (1/2)*k4*(thetaxsD1.^3) - k3*thetaxsD1)) ...
    + xis(end)*(-u^2)  ...
    + xis(xibarentry)*(mnhat*gamma)  ...
    + trapz(shat,gamma*xis) ...
    + thetaxs(xibartentry)*(k0*k3) ...
    + thetaxs(1)*(-Chatstheta* thetaxs(1)))

absolute_error_over_internal_work = absolute_error/absolute_internal_work
function [xis,xisD1,xisD2,thetaxs,thetaxsD1,thetaxsD2,xibarentry,xibartentry] = StaticSolutions_Main(UseSupportSprings,Nas,Nrs,shat,gamma,k0,xibart,k1,k2,k3,k4,mnhat,xibar,Chatstheta,u,MaxIterations_fsolve,MaxFunctionEvaluations_fsolve)
    disp('______________________________________________________')
    disp('EVALUATION OF THE AXIAL AND TORSIONAL STATIC SOLUTIONS')
    tstaticsolutions = tic;    
    %% POLYNOMIAL SHAPES AND DERIVATIVES - ALSO DEFINES THE casenumber TO BE USED IN THE FOLLOWING SECTIONS
    [casenumber,AMS_1_matrix,AMSD1_1_matrix,AMSD2_1_matrix,AMS_2_matrix,AMSD1_2_matrix,AMSD2_2_matrix,AMS_3_matrix,AMSD1_3_matrix,AMSD2_3_matrix,RMS_1_matrix,RMSD1_1_matrix,RMSD2_1_matrix,RMS_2_matrix,RMSD1_2_matrix,RMSD2_2_matrix,RMS_3_matrix,RMSD1_3_matrix,RMSD2_3_matrix,shat1,shat2,shat3] = StaticSolutions_Axial_And_Rotational_Polynomial_Shapes(UseSupportSprings,Nas,Nrs,shat,mnhat,xibar,k0,xibart);
    %% EVALUATION OF THE COEFFICIENTS FOR THE NONLINEAR ALGEBRAIC EQUATIONS 
    [V1s,V2s,V3s,V4s,V5s,V6s,V7s,V8s,V9s,V10s,V11s,V12s,V13s,V14s,V15s,V16s,V17s,V18s,V19s,V20s,V21s,V22s,V23s,V24s,V25s,V26s,V27s,V28s,V29s,V30s,V31s,V32s,V33s,V34s,V35s,V36s,V37s,V38s,V39s,V40s] = StaticSolutions_Galerkin_Matrices_Evaluation(casenumber,UseSupportSprings,shat1,shat2,shat3,Nas,Nrs,gamma,k0,k1,k2,k3,k4,u,mnhat,Chatstheta,AMS_1_matrix,AMSD1_1_matrix,AMSD2_1_matrix,AMS_2_matrix,AMSD1_2_matrix,AMSD2_2_matrix,AMS_3_matrix,AMSD1_3_matrix,AMSD2_3_matrix,RMS_1_matrix,RMSD1_1_matrix,RMSD2_1_matrix,RMS_2_matrix,RMSD1_2_matrix,RMSD2_2_matrix,RMS_3_matrix,RMSD1_3_matrix,RMSD2_3_matrix);
    %% SOLVING THE NONLINEAR SYSTEM OF ALGEBRAIC EQUATIONS - ONE, TWO OR THREE DOMAINS
    %% ONE DOMAINS - Eqn set I
    if casenumber==111 || casenumber==211 || casenumber==311 || casenumber==411
        %Initial guesses for the gen. coord. - solutions of the linear case
        Gs0 = zeros(1*(Nas + Nrs),1);
        Gs0(1) = (gamma - u^2)/k2;
        Gs0(2) = -gamma/(2*k2);
        Gs0(Nas + 1) = k0;
        if UseSupportSprings == 1
            Gs0(Nas + Nrs) = k0*k3/Chatstheta;
        end
        %Obtaining the solutions
        disp('------------------------------------------------------')
        disp('Solving The System of Algebraic Nonlinear Equations Using ONE Domain...')
        options = optimoptions('fsolve'); 
        options.MaxIterations = MaxIterations_fsolve;
        options.MaxFunctionEvaluations = MaxFunctionEvaluations_fsolve;
        tic
        disp('Using eqn set number I.');
        Gssol = fsolve(@(Gs) StaticSolutions_Nonlinear_Algebraic_Equations_I(Gs,V1s,V2s,V3s,V4s,V5s,V6s,V7s,V8s,V9s,V10s,V11s,V12s,V13s,V14s,V15s,V16s,V17s,V18s,V19s,V20s,V21s,V22s,V23s,V24s,V25s,V26s,V27s,V28s,V29s,V30s,V31s,V32s,V33s,V34s,V35s,V36s,V37s,V38s,V39s,V40s), Gs0,options);
        toc
        disp('------------------------------------------------------')
        %Reconstruction of the displacements fields then assembly into one vector
        xis_1 = (Gssol(1:Nas)'*AMS_1_matrix)';
        xis_1 = xis_1';
        xis = xis_1;

        thetaxs_1 = (Gssol((Nas+1):(Nas+Nrs))'*RMS_1_matrix)';
        thetaxs_1 = thetaxs_1';
        thetaxs = thetaxs_1;

        %First and second derivatives then assembly into one vector
        xisD1_1 = (Gssol(1:Nas)'*AMSD1_1_matrix)';
        xisD1_1 = xisD1_1';
        xisD1 = xisD1_1;
        
        thetaxsD1_1 = (Gssol((Nas+1):(Nas+Nrs))'*RMSD1_1_matrix)';
        thetaxsD1_1 = thetaxsD1_1';
        thetaxsD1 = thetaxsD1_1;
        
        xisD2_1 = (Gssol(1:Nas)'*AMSD2_1_matrix)';
        xisD2_1 = xisD2_1';
        xisD2(1:length(shat1)) = xisD2_1;
        
        thetaxsD2_1 = (Gssol((Nas+1):(Nas+Nrs))'*RMSD2_1_matrix)';
        thetaxsD2_1 = thetaxsD2_1';
        thetaxsD2 = thetaxsD2_1;
    end
    %% TWO DOMAINS - Eqn sets II, III and IV
    if casenumber==221 || casenumber==321 || casenumber==421 || casenumber==422 || casenumber==423
        %Initial guesses for the gen. coord. - solutions of the linear case
        Gs0 = zeros(2*(Nas + Nrs),1);
        Gs0(1) = (gamma - u^2)/k2;
        Gs0(Nas + 1) = (gamma - u^2)/k2;

        Gs0(2) = -gamma/(2*k2);
        Gs0(Nas + 2) = -gamma/(2*k2);

        Gs0(2*Nas + 1) = k0;
        Gs0(2*Nas + Nrs + 1) = k0;
        if UseSupportSprings == 1
            Gs0(2*Nas + Nrs) = k0*k3/Chatstheta;
        end
        %Obtaining the solutions
        disp('------------------------------------------------------')
        disp('Solving The System of Algebraic Nonlinear Equations Using TWO Domains...')
        options = optimoptions('fsolve'); 
        options.MaxIterations = MaxIterations_fsolve;
        options.MaxFunctionEvaluations = MaxFunctionEvaluations_fsolve;
        tic
        if casenumber==221 || casenumber==321 || casenumber==421
            disp('Using eqn set number II.');
            Gssol = fsolve(@(Gs) StaticSolutions_Nonlinear_Algebraic_Equations_II(Gs,V1s,V2s,V3s,V4s,V5s,V6s,V7s,V8s,V9s,V10s,V11s,V12s,V13s,V14s,V15s,V16s,V17s,V18s,V19s,V20s,V21s,V22s,V23s,V24s,V25s,V26s,V27s,V28s,V29s,V30s,V31s,V32s,V33s,V34s,V35s,V36s,V37s,V38s,V39s,V40s), Gs0,options);
        elseif casenumber==422
            disp('Using eqn set number III.');
            Gssol = fsolve(@(Gs) StaticSolutions_Nonlinear_Algebraic_Equations_III(Gs,V1s,V2s,V3s,V4s,V5s,V6s,V7s,V8s,V9s,V10s,V11s,V12s,V13s,V14s,V15s,V16s,V17s,V18s,V19s,V20s,V21s,V22s,V23s,V24s,V25s,V26s,V27s,V28s,V29s,V30s,V31s,V32s,V33s,V34s,V35s,V36s,V37s,V38s,V39s,V40s), Gs0,options);
        else %casenumber==423
            disp('Using eqn set number IV.');
            Gssol = fsolve(@(Gs) StaticSolutions_Nonlinear_Algebraic_Equations_IV(Gs,V1s,V2s,V3s,V4s,V5s,V6s,V7s,V8s,V9s,V10s,V11s,V12s,V13s,V14s,V15s,V16s,V17s,V18s,V19s,V20s,V21s,V22s,V23s,V24s,V25s,V26s,V27s,V28s,V29s,V30s,V31s,V32s,V33s,V34s,V35s,V36s,V37s,V38s,V39s,V40s), Gs0,options);
        end
        toc
        disp('------------------------------------------------------')
        %Reconstruction of the displacements fields then assembly into one vector
        xis_1 = (Gssol(1:Nas)'*AMS_1_matrix)';
        xis_1 = xis_1';
        xis_2 = (Gssol((Nas + 1):2*Nas)'*AMS_2_matrix)' + (Gssol(1:Nas)'*AMS_1_matrix(:,end))';
        xis_2 = xis_2';
        xis(1:length(shat1)) = xis_1;
        xis((length(shat1) + 1):(length(shat1) + length(shat2) - 1)) = xis_2(2:end);

        thetaxs_1 = (Gssol((2*Nas+1):(2*Nas+Nrs))'*RMS_1_matrix)';
        thetaxs_1 = thetaxs_1';
        thetaxs_2 = (Gssol((2*Nas+Nrs + 1):(2*Nas+2*Nrs))'*RMS_2_matrix)' + (Gssol((2*Nas+1):(2*Nas+Nrs))'*RMS_1_matrix(:,end))';
        thetaxs_2 = thetaxs_2';
        thetaxs(1:length(shat1)) = thetaxs_1;
        thetaxs((length(shat1) + 1):(length(shat1) + length(shat2) - 1)) = thetaxs_2(2:end);

        %First and second derivatives then assembly into one vector - middle point is always the average
        xisD1_1 = (Gssol(1:Nas)'*AMSD1_1_matrix)';
        xisD1_1 = xisD1_1';
        xisD1_2 = (Gssol((Nas + 1):2*Nas)'*AMSD1_2_matrix)';
        xisD1_2 = xisD1_2';
        xisD1(1:length(shat1)-1) = xisD1_1(1:end-1);
        xisD1(length(shat1)) = (xisD1_1(end) + xisD1_2(1))/2; %average
        xisD1((length(shat1) + 1):(length(shat1) + length(shat2) - 1)) = xisD1_2(2:end);
        
        thetaxsD1_1 = (Gssol((2*Nas+1):(2*Nas+Nrs))'*RMSD1_1_matrix)';
        thetaxsD1_1 = thetaxsD1_1';
        thetaxsD1_2 = (Gssol((2*Nas+Nrs + 1):(2*Nas+2*Nrs))'*RMSD1_2_matrix)';
        thetaxsD1_2 = thetaxsD1_2';
        thetaxsD1(1:length(shat1)-1) = thetaxsD1_1(1:end-1);
        thetaxsD1(length(shat1)) = (thetaxsD1_1(end) + thetaxsD1_2(1))/2; %average
        thetaxsD1((length(shat1) + 1):(length(shat1) + length(shat2) - 1)) = thetaxsD1_2(2:end);
        
        xisD2_1 = (Gssol(1:Nas)'*AMSD2_1_matrix)';
        xisD2_1 = xisD2_1';
        xisD2_2 = (Gssol((Nas + 1):2*Nas)'*AMSD2_2_matrix)';
        xisD2_2 = xisD2_2';
        xisD2(1:length(shat1)-1) = xisD2_1(1:end-1);
        xisD2(length(shat1)) = (xisD2_1(end) + xisD2_2(1))/2; %average
        xisD2((length(shat1) + 1):(length(shat1) + length(shat2) - 1)) = xisD2_2(2:end);
        
        thetaxsD2_1 = (Gssol((2*Nas+1):(2*Nas+Nrs))'*RMSD2_1_matrix)';
        thetaxsD2_1 = thetaxsD2_1';
        thetaxsD2_2 = (Gssol((2*Nas+Nrs + 1):(2*Nas+2*Nrs))'*RMSD2_2_matrix)';
        thetaxsD2_2 = thetaxsD2_2';
        thetaxsD2(1:length(shat1)-1) = thetaxsD2_1(1:end-1);
        thetaxsD2(length(shat1)) = (thetaxsD2_1(end) + thetaxsD2_2(1))/2; %average
        thetaxsD2((length(shat1) + 1):(length(shat1) + length(shat2) - 1)) = thetaxsD2_2(2:end);
    end
    %% THREE DOMAINS - Eqn sets V and VI
    if casenumber==431 || casenumber==432
        %Initial guesses for the gen. coord. - solutions of the linear case
        Gs0 = zeros(3*(Nas + Nrs),1);
        Gs0(1) = (gamma - u^2)/k2;
        Gs0(Nas + 1) = (gamma - u^2)/k2;
        Gs0(2*Nas + 1) = (gamma - u^2)/k2;

        Gs0(2) = -gamma/(2*k2);
        Gs0(Nas + 2) = -gamma/(2*k2);
        Gs0(2*Nas + 2) = -gamma/(2*k2);

        Gs0(3*Nas + 1) = k0;
        Gs0(3*Nas + Nrs + 1) = k0;
        Gs0(3*Nas + 2*Nrs + 1) = k0;
        if UseSupportSprings == 1
            Gs0(3*Nas + Nrs) = k0*k3/Chatstheta;
        end
        %Obtaining the solutions
        disp('------------------------------------------------------')
        disp('Solving The System of Algebraic Nonlinear Equations Using THREE Domains...')
        options = optimoptions('fsolve'); 
        options.MaxIterations = MaxIterations_fsolve;
        options.MaxFunctionEvaluations = MaxFunctionEvaluations_fsolve;
        tic
        if casenumber==431
            disp('Using eqn set number V.');
            Gssol = fsolve(@(Gs) StaticSolutions_Nonlinear_Algebraic_Equations_V_4(Gs,V1s,V2s,V3s,V4s,V5s,V6s,V7s,V8s,V9s,V10s,V11s,V12s,V13s,V14s,V15s,V16s,V17s,V18s,V19s,V20s,V21s,V22s,V23s,V24s,V25s,V26s,V27s,V28s,V29s,V30s,V31s,V32s,V33s,V34s,V35s,V36s,V37s,V38s,V39s,V40s), Gs0,options);
        else %casenumber==432
            disp('Using eqn set number VI.');
            Gssol = fsolve(@(Gs) StaticSolutions_Nonlinear_Algebraic_Equations_VI(Gs,V1s,V2s,V3s,V4s,V5s,V6s,V7s,V8s,V9s,V10s,V11s,V12s,V13s,V14s,V15s,V16s,V17s,V18s,V19s,V20s,V21s,V22s,V23s,V24s,V25s,V26s,V27s,V28s,V29s,V30s,V31s,V32s,V33s,V34s,V35s,V36s,V37s,V38s,V39s,V40s), Gs0,options);
        end
        toc
        disp('------------------------------------------------------')
        %Reconstruction of the displacements fields then assembly into one vector
        xis_1 = (Gssol(1:Nas)'*AMS_1_matrix)';
        xis_1 = xis_1';
        xis_2 = (Gssol((Nas + 1):2*Nas)'*AMS_2_matrix)' + (Gssol(1:Nas)'*AMS_1_matrix(:,end))';
        xis_2 = xis_2';
        xis_3 = (Gssol((2*Nas + 1):3*Nas)'*AMS_3_matrix)' + (Gssol((Nas + 1):2*Nas)'*AMS_2_matrix(:,end))' + (Gssol(1:Nas)'*AMS_1_matrix(:,end))';
        xis_3 = xis_3';
        xis(1:length(shat1)) = xis_1;
        xis((length(shat1) + 1):(length(shat1) + length(shat2) - 1)) = xis_2(2:end);
        xis((length(shat1) + length(shat2)):(length(shat1) + length(shat2) + length(shat3) - 2)) = xis_3(2:end);

        thetaxs_1 = (Gssol((3*Nas+1):(3*Nas+Nrs))'*RMS_1_matrix)';
        thetaxs_1 = thetaxs_1';
        thetaxs_2 = (Gssol((3*Nas+Nrs + 1):(3*Nas+2*Nrs))'*RMS_2_matrix)' + (Gssol((3*Nas+1):(3*Nas+Nrs))'*RMS_1_matrix(:,end))';
        thetaxs_2 = thetaxs_2';
        thetaxs_3 = (Gssol((3*Nas+2*Nrs + 1):(3*Nas+3*Nrs))'*RMS_3_matrix)' + (Gssol((3*Nas+Nrs + 1):(3*Nas+2*Nrs))'*RMS_2_matrix(:,end))' + (Gssol((3*Nas+1):(3*Nas+Nrs))'*RMS_1_matrix(:,end))';
        thetaxs_3 = thetaxs_3';
        thetaxs(1:length(shat1)) = thetaxs_1;
        thetaxs((length(shat1) + 1):(length(shat1) + length(shat2) - 1)) = thetaxs_2(2:end);
        thetaxs((length(shat1) + length(shat2)):(length(shat1) + length(shat2) + length(shat3) - 2)) = thetaxs_3(2:end);

        %First and second derivatives then assembly into one vector - middle point is always the average
        xisD1_1 = (Gssol(1:Nas)'*AMSD1_1_matrix)';
        xisD1_1 = xisD1_1';
        xisD1_2 = (Gssol((Nas + 1):2*Nas)'*AMSD1_2_matrix)';
        xisD1_2 = xisD1_2';
        xisD1_3 = (Gssol((2*Nas + 1):3*Nas)'*AMSD1_3_matrix)';
        xisD1_3 = xisD1_3';
        xisD1(1:length(shat1)-1) = xisD1_1(1:end-1);
        xisD1(length(shat1)) = (xisD1_1(end) + xisD1_2(1))/2; %average
        xisD1((length(shat1) + 1):(length(shat1) + length(shat2) - 2)) = xisD1_2(2:end-1);
        xisD1((length(shat1) + length(shat2) - 1)) = (xisD1_2(end) + xisD1_3(1))/2; %average
        xisD1((length(shat1) + length(shat2)):(length(shat1) + length(shat2) + length(shat3) - 2)) = xisD1_3(2:end);

        thetaxsD1_1 = (Gssol((3*Nas+1):(3*Nas+Nrs))'*RMSD1_1_matrix)';
        thetaxsD1_1 = thetaxsD1_1';
        thetaxsD1_2 = (Gssol((3*Nas+Nrs + 1):(3*Nas+2*Nrs))'*RMSD1_2_matrix)';
        thetaxsD1_2 = thetaxsD1_2';
        thetaxsD1_3 = (Gssol((3*Nas+2*Nrs + 1):(3*Nas+3*Nrs))'*RMSD1_3_matrix)';
        thetaxsD1_3 = thetaxsD1_3';
        thetaxsD1(1:length(shat1)-1) = thetaxsD1_1(1:end-1);
        thetaxsD1(length(shat1)) = (thetaxsD1_1(end) + thetaxsD1_2(1))/2; %average
        thetaxsD1((length(shat1) + 1):(length(shat1) + length(shat2) - 2)) = thetaxsD1_2(2:end-1);
        thetaxsD1((length(shat1) + length(shat2) - 1)) = (thetaxsD1_2(end) + thetaxsD1_3(1))/2; %average
        thetaxsD1((length(shat1) + length(shat2)):(length(shat1) + length(shat2) + length(shat3) - 2)) = thetaxsD1_3(2:end);

        xisD2_1 = (Gssol(1:Nas)'*AMSD2_1_matrix)';
        xisD2_1 = xisD2_1';
        xisD2_2 = (Gssol((Nas + 1):2*Nas)'*AMSD2_2_matrix)';
        xisD2_2 = xisD2_2';
        xisD2_3 = (Gssol((2*Nas + 1):3*Nas)'*AMSD2_3_matrix)';
        xisD2_3 = xisD2_3';
        xisD2(1:length(shat1)-1) = xisD2_1(1:end-1);
        xisD2(length(shat1)) = (xisD2_1(end) + xisD2_2(1))/2; %average
        xisD2((length(shat1) + 1):(length(shat1) + length(shat2) - 2)) = xisD2_2(2:end-1);
        xisD2((length(shat1) + length(shat2) - 1)) = (xisD2_2(end) + xisD2_3(1))/2; %average
        xisD2((length(shat1) + length(shat2)):(length(shat1) + length(shat2) + length(shat3) - 2)) = xisD2_3(2:end);

        thetaxsD2_1 = (Gssol((3*Nas+1):(3*Nas+Nrs))'*RMSD2_1_matrix)';
        thetaxsD2_1 = thetaxsD2_1';
        thetaxsD2_2 = (Gssol((3*Nas+Nrs + 1):(3*Nas+2*Nrs))'*RMSD2_2_matrix)';
        thetaxsD2_2 = thetaxsD2_2';
        thetaxsD2_3 = (Gssol((3*Nas+2*Nrs + 1):(3*Nas+3*Nrs))'*RMSD2_3_matrix)';
        thetaxsD2_3 = thetaxsD2_3';
        thetaxsD2(1:length(shat1)-1) = thetaxsD2_1(1:end-1);
        thetaxsD2(length(shat1)) = (thetaxsD2_1(end) + thetaxsD2_2(1))/2; %average
        thetaxsD2((length(shat1) + 1):(length(shat1) + length(shat2) - 2)) = thetaxsD2_2(2:end-1);
        thetaxsD2((length(shat1) + length(shat2) - 1)) = (thetaxsD2_2(end) + thetaxsD2_3(1))/2; %average
        thetaxsD2((length(shat1) + length(shat2)):(length(shat1) + length(shat2) + length(shat3) - 2)) = thetaxsD2_3(2:end);
    end
    xibarentry = length(shat1);
    xibartentry = (length(shat1) + length(shat2) - 1);
    toc(tstaticsolutions);
    disp('______________________________________________________')
end
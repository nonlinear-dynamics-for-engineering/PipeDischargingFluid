function [casenumber,AMS_1_matrix,AMSD1_1_matrix,AMSD2_1_matrix,AMS_2_matrix,AMSD1_2_matrix,AMSD2_2_matrix,AMS_3_matrix,AMSD1_3_matrix,AMSD2_3_matrix,RMS_1_matrix,RMSD1_1_matrix,RMSD2_1_matrix,RMS_2_matrix,RMSD1_2_matrix,RMSD2_2_matrix,RMS_3_matrix,RMSD1_3_matrix,RMSD2_3_matrix,shat1,shat2,shat3] = StaticSolutions_Axial_And_Rotational_Polynomial_Shapes(UseSupportSprings,Nas,Nrs,shat,mnhat,xibar,k0,xibart)
	if (mnhat==0 && k0==0) || (k0==0 && mnhat~=0 && xibar==1) || (mnhat==0 && k0~=0 && xibart==1) || (mnhat~=0 && xibar==1 && k0~=0 && xibart==1)
        %% ONE DOMAIN
        disp('------------------------------------------------------')    
        disp('Evaluating Axial and Torsional Polynomial Shapes Using ONE Domain...')
        tic
        %Now checking which one specifically
        if mnhat==0 && k0==0
            disp('Case 1.1.1) - no additions.');
            casenumber = 111;
        end
        if k0==0 && mnhat~=0 && xibar==1
            disp('Case 2.1.1) - only lumped mass addition at the free end.');
            casenumber = 211;
        end
        if mnhat==0 && k0~=0 && xibart==1
            disp('Case 3.1.1) - only torsional moment at the free end.');
            casenumber = 311;
        end
        if mnhat~=0 && xibar==1 && k0~=0 && xibart==1
            disp('Case 4.1.1) - both lumped mass and torsional moment additions at the free end.');
            casenumber = 411;
        end
        shat1 = shat;
        %for the output only
        shat2 = nan;
        shat3 = nan;
        %% SHAPES AND DERIVATIVES FOR THE AXIAL STATIC SOLUTION
        AMS_1_matrix = zeros(Nas,length(shat1));
        AMSD1_1_matrix = zeros(Nas,length(shat1));
        AMSD2_1_matrix = zeros(Nas,length(shat1));
        for i = 1:Nas
            if i == 1   
                AMS_1_matrix(i,:) = shat1;
                AMSD1_1_matrix(i,:) = ones(length(shat1),1);
                AMSD2_1_matrix(i,:) = zeros(length(shat1),1);

            else
                AMS_1_matrix(i,:) = shat1.^i;
                AMSD1_1_matrix(i,:) = i*shat1.^(i-1);
                AMSD2_1_matrix(i,:) = i*(i-1)*shat1.^(i-2);
            end
        end
        %% SHAPES AND DERIVATIVES FOR THE TORSIONAL STATIC SOLUTION
        RMS_1_matrix = zeros(Nrs,length(shat1));
        RMSD1_1_matrix = zeros(Nrs,length(shat1));
        RMSD2_1_matrix = zeros(Nrs,length(shat1));
        for i = 1:Nrs
            if i == 1   
                RMS_1_matrix(i,:) = shat1;
                RMSD1_1_matrix(i,:) = ones(length(shat1),1);
                RMSD2_1_matrix(i,:) = zeros(length(shat1),1);
            elseif i < Nrs
                RMS_1_matrix(i,:) = shat1.^i;
                RMSD1_1_matrix(i,:) = i*shat1.^(i-1);
                RMSD2_1_matrix(i,:) = i*(i-1)*shat1.^(i-2);
            else 
                if UseSupportSprings == 1
                    RMS_1_matrix(i,:) = ones(length(shat1),1);
                    RMSD1_1_matrix(i,:) = zeros(length(shat1),1);
                    RMSD2_1_matrix(i,:) = zeros(length(shat1),1);
                end
                if UseSupportSprings == 0
                    RMS_1_matrix(i,:) = shat1.^i;
                    RMSD1_1_matrix(i,:) = i*shat1.^(i-1);
                    RMSD2_1_matrix(i,:) = i*(i-1)*shat1.^(i-2);
                end
            end
        end
        %% SETTING SECOND- AND THIRD-DOMAIN SHAPE FUNCTIONS AS NANs TO MATCH FUNCTION OUTPUT
        AMS_2_matrix = nan;
        AMSD1_2_matrix = nan;
        AMSD2_2_matrix = nan;
        AMS_3_matrix = nan;
        AMSD1_3_matrix = nan;
        AMSD2_3_matrix = nan;
        RMS_2_matrix = nan;
        RMSD1_2_matrix = nan;
        RMSD2_2_matrix = nan;
        RMS_3_matrix = nan;
        RMSD1_3_matrix = nan;
        RMSD2_3_matrix = nan;
    end
    
    if (k0==0 && mnhat~=0 && xibar>0 && xibar<1) || (mnhat==0 && k0~=0 && xibart>0 && xibart<1) || (mnhat~=0 && xibar>0 && xibar<1 && k0~=0 && xibart>0 && xibart<1 && xibar==xibart) || (mnhat~=0 && xibar>0 && xibar<1 && k0~=0 && xibart==1) || (mnhat~=0 && xibar==1 && k0~=0 && xibart>0 && xibart<1)
        %% TWO DOMAINS
        disp('------------------------------------------------------')    
        disp('Evaluating Axial and Torsional Polynomial Shapes Using TWO Domains...')
        tic
        %Verification to check the lower division point (LD)
        if k0==0 && mnhat~=0 && xibar>0 && xibar<1
            disp('Case 2.2.1) - only lumped mass addition strictly at a point along the length.');
            LD = xibar;
            casenumber = 221;
        end
        if mnhat==0 && k0~=0 && xibart>0 && xibart<1
            disp('Case 3.2.1) - only torsional moment addition strictly at a point along the length.');
            LD = xibart;
            casenumber = 321;
        end
        if mnhat~=0 && xibar>0 && xibar<1 && k0~=0 && xibart>0 && xibart<1 && xibar==xibart
            disp('Case 4.2.1) - both lumped mass and torsional moment additions at the same point strictly along the length.');
            LD = xibar; %could be either
            casenumber = 421;
        end
        if mnhat~=0 && xibar>0 && xibar<1 && k0~=0 && xibart==1
            disp('Case 4.2.2) - lumped mass addition strictly at a point along the length and torsional moment addition at the free end.');
            LD = xibar;
            casenumber = 422;
        end
        if mnhat~=0 && xibar==1 && k0~=0 && xibart>0 && xibart<1
            disp('Case 4.2.3) - torsional moment addition strictly at a point along the length and lumped mass addition at the free end.');
            LD = xibart;
            casenumber = 423;
        end
        %Domain definition
        shat1 = shat(1:round((length(shat)-1)*LD) + 1);
        shat2 = shat(round((length(shat)-1)*LD) + 1:end);
        %for the output only
        shat3 = nan;
        %Very slight correction of LD to match the vector entries
        LD = shat1(end);
        %% SHAPES AND DERIVATIVES FOR THE AXIAL STATIC SOLUTION
        %First domain
        AMS_1_matrix = zeros(Nas,length(shat1));
        AMSD1_1_matrix = zeros(Nas,length(shat1));
        AMSD2_1_matrix = zeros(Nas,length(shat1));
        for i = 1:Nas
            if i == 1   
                AMS_1_matrix(i,:) = shat1/LD;
                AMSD1_1_matrix(i,:) = ones(length(shat1),1)/LD;
                AMSD2_1_matrix(i,:) = zeros(length(shat1),1);

            else
                AMS_1_matrix(i,:) = (shat1/LD).^i;
                AMSD1_1_matrix(i,:) = (i/LD)*(shat1/LD).^(i-1);
                AMSD2_1_matrix(i,:) = (i/LD^2)*(i-1)*(shat1/LD).^(i-2);
            end
        end
        %Second domain
        AMS_2_matrix = zeros(Nas,length(shat2));
        AMSD1_2_matrix = zeros(Nas,length(shat2));
        AMSD2_2_matrix = zeros(Nas,length(shat2));
        for i = 1:Nas
            if i == 1   
                AMS_2_matrix(i,:) = (shat2 - LD)/(1 - LD);
                AMSD1_2_matrix(i,:) = ones(length(shat2),1)/(1 - LD);
                AMSD2_2_matrix(i,:) = zeros(length(shat2),1);

            else
                AMS_2_matrix(i,:) = ((shat2 - LD)/(1 - LD)).^i;
                AMSD1_2_matrix(i,:) = (i/(1 - LD))*((shat2 - LD)/(1 - LD)).^(i-1);
                AMSD2_2_matrix(i,:) = (i/(1 - LD)^2)*(i-1)*((shat2 - LD)/(1 - LD)).^(i-2);
            end
        end
        %% SHAPES AND DERIVATIVES FOR THE TORSIONAL STATIC SOLUTION
        %First domain - the only one with rigid body shape if UseSupportSprings = 1
        RMS_1_matrix = zeros(Nrs,length(shat1));
        RMSD1_1_matrix = zeros(Nrs,length(shat1));
        RMSD2_1_matrix = zeros(Nrs,length(shat1));
        for i = 1:Nrs
            if i == 1   
                RMS_1_matrix(i,:) = shat1/LD;
                RMSD1_1_matrix(i,:) = ones(length(shat1),1)/LD;
                RMSD2_1_matrix(i,:) = zeros(length(shat1),1);

            elseif i < Nrs
                RMS_1_matrix(i,:) = (shat1/LD).^i;
                RMSD1_1_matrix(i,:) = (i/LD)*(shat1/LD).^(i-1);
                RMSD2_1_matrix(i,:) = (i/LD^2)*(i-1)*(shat1/LD).^(i-2);
            else 
                if UseSupportSprings == 1
                    RMS_1_matrix(i,:) = ones(length(shat1),1);
                    RMSD1_1_matrix(i,:) = zeros(length(shat1),1);
                    RMSD2_1_matrix(i,:) = zeros(length(shat1),1);
                end
                if UseSupportSprings == 0
                    RMS_1_matrix(i,:) = (shat1/LD).^i;
                RMSD1_1_matrix(i,:) = (i/LD)*(shat1/LD).^(i-1);
                RMSD2_1_matrix(i,:) = (i/LD^2)*(i-1)*(shat1/LD).^(i-2);
                end
            end
        end
        %Second domain
        RMS_2_matrix = zeros(Nrs,length(shat2));
        RMSD1_2_matrix = zeros(Nrs,length(shat2));
        RMSD2_2_matrix = zeros(Nrs,length(shat2));
        for i = 1:Nas
            if i == 1   
                RMS_2_matrix(i,:) = (shat2 - LD)/(1 - LD);
                RMSD1_2_matrix(i,:) = ones(length(shat2),1)/(1 - LD);
                RMSD2_2_matrix(i,:) = zeros(length(shat2),1);

            else
                RMS_2_matrix(i,:) = ((shat2 - LD)/(1 - LD)).^i;
                RMSD1_2_matrix(i,:) = (i/(1 - LD))*((shat2 - LD)/(1 - LD)).^(i-1);
                RMSD2_2_matrix(i,:) = (i/(1 - LD)^2)*(i-1)*((shat2 - LD)/(1 - LD)).^(i-2);
            end
        end
        %% SETTING THIRD-DOMAIN SHAPE FUNCTIONS AS NANs TO MATCH FUNCTION OUTPUT
        AMS_3_matrix =  nan;
        AMSD1_3_matrix =  nan;
        AMSD2_3_matrix =  nan;
        RMS_3_matrix =  nan;
        RMSD1_3_matrix =  nan;
        RMSD2_3_matrix =  nan;
    end
    
    if (mnhat~=0 && xibar>0 && xibar<1 && k0~=0 && xibart>0 && xibart<1 && xibar<xibart) || (mnhat~=0 && xibar>0 && xibar<1 && k0~=0 && xibart>0 && xibart<1 && xibart<xibar)
        %% THREE DOMAINS
        disp('------------------------------------------------------')    
        disp('Evaluating Axial and Torsional Polynomial Shapes Using THREE Domains...')
        tic
        %Verification to check lower and upper division points (LD and UD)
        if mnhat~=0 && xibar>0 && xibar<1 && k0~=0 && xibart>0 && xibart<1 && xibar<xibart
            disp('Case 4.3.1) - both additions strictly at a point along the length (lumped mass closer to support).');
            LD = xibar;
            UD = xibart;
            casenumber = 431;
        end
        if mnhat~=0 && xibar>0 && xibar<1 && k0~=0 && xibart>0 && xibart<1 && xibart<xibar
            disp('Case 4.3.2) - both additions strictly at a point along the length (torsional moment closer to support).');
            LD = xibart;
            UD = xibar;
            casenumber = 432;
        end
        %Domain definition
        shat1 = shat(1:round((length(shat)-1)*LD) + 1);
        shat2 = shat(round((length(shat)-1)*LD) + 1:round((length(shat)-1)*UD) + 1);
        shat3 = shat(round((length(shat)-1)*UD) + 1:end);
        %Very slight correction of the division points to match the vector entries
        LD = shat1(end);
        UD = shat2(end);
        %% SHAPES AND DERIVATIVES FOR THE AXIAL STATIC SOLUTION
        %First domain
        AMS_1_matrix = zeros(Nas,length(shat1));
        AMSD1_1_matrix = zeros(Nas,length(shat1));
        AMSD2_1_matrix = zeros(Nas,length(shat1));
        for i = 1:Nas
            if i == 1   
                AMS_1_matrix(i,:) = shat1/LD;
                AMSD1_1_matrix(i,:) = ones(length(shat1),1)/LD;
                AMSD2_1_matrix(i,:) = zeros(length(shat1),1);

            else
                AMS_1_matrix(i,:) = (shat1/LD).^i;
                AMSD1_1_matrix(i,:) = (i/LD)*(shat1/LD).^(i-1);
                AMSD2_1_matrix(i,:) = (i/LD^2)*(i-1)*(shat1/LD).^(i-2);
            end
        end
        %Second domain
        AMS_2_matrix = zeros(Nas,length(shat2));
        AMSD1_2_matrix = zeros(Nas,length(shat2));
        AMSD2_2_matrix = zeros(Nas,length(shat2));
        for i = 1:Nas
            if i == 1   
                AMS_2_matrix(i,:) = (shat2 - LD)/(UD - LD);
                AMSD1_2_matrix(i,:) = ones(length(shat2),1)/(UD - LD);
                AMSD2_2_matrix(i,:) = zeros(length(shat2),1);

            else
                AMS_2_matrix(i,:) = ((shat2 - LD)/(UD - LD)).^i;
                AMSD1_2_matrix(i,:) = (i/(UD - LD))*((shat2 - LD)/(UD - LD)).^(i-1);
                AMSD2_2_matrix(i,:) = (i/(UD - LD)^2)*(i-1)*((shat2 - LD)/(UD - LD)).^(i-2);
            end
        end
        %Third domain
        AMS_3_matrix = zeros(Nas,length(shat3));
        AMSD1_3_matrix = zeros(Nas,length(shat3));
        AMSD2_3_matrix = zeros(Nas,length(shat3));
        for i = 1:Nas
            if i == 1   
                AMS_3_matrix(i,:) = (shat3 - UD)/(1 - UD);
                AMSD1_3_matrix(i,:) = ones(length(shat3),1)/(1 - UD);
                AMSD2_3_matrix(i,:) = zeros(length(shat3),1);

            else
                AMS_3_matrix(i,:) = ((shat3 - UD)/(1 - UD)).^i;
                AMSD1_3_matrix(i,:) = (i/(1 - UD))*((shat3 - UD)/(1 - UD)).^(i-1);
                AMSD2_3_matrix(i,:) = (i/(1 - UD)^2)*(i-1)*((shat3 - UD)/(1 - UD)).^(i-2);
            end
        end
        %% SHAPES AND DERIVATIVES FOR THE TORSIONAL STATIC SOLUTION
        %First domain - the only one with rigid body shape if UseSupportSprings = 1
        RMS_1_matrix = zeros(Nrs,length(shat1));
        RMSD1_1_matrix = zeros(Nrs,length(shat1));
        RMSD2_1_matrix = zeros(Nrs,length(shat1));
        for i = 1:Nrs
            if i == 1   
                RMS_1_matrix(i,:) = shat1/LD;
                RMSD1_1_matrix(i,:) = ones(length(shat1),1)/LD;
                RMSD2_1_matrix(i,:) = zeros(length(shat1),1);

            elseif i < Nrs
                RMS_1_matrix(i,:) = (shat1/LD).^i;
                RMSD1_1_matrix(i,:) = (i/LD)*(shat1/LD).^(i-1);
                RMSD2_1_matrix(i,:) = (i/LD^2)*(i-1)*(shat1/LD).^(i-2);
            else 
                if UseSupportSprings == 1
                    RMS_1_matrix(i,:) = ones(length(shat1),1);
                    RMSD1_1_matrix(i,:) = zeros(length(shat1),1);
                    RMSD2_1_matrix(i,:) = zeros(length(shat1),1);
                end
                if UseSupportSprings == 0
                    RMS_1_matrix(i,:) = (shat1/LD).^i;
                RMSD1_1_matrix(i,:) = (i/LD)*(shat1/LD).^(i-1);
                RMSD2_1_matrix(i,:) = (i/LD^2)*(i-1)*(shat1/LD).^(i-2);
                end
            end
        end
        %Second domain
        RMS_2_matrix = zeros(Nrs,length(shat2));
        RMSD1_2_matrix = zeros(Nrs,length(shat2));
        RMSD2_2_matrix = zeros(Nrs,length(shat2));
        for i = 1:Nas
            if i == 1   
                RMS_2_matrix(i,:) = (shat2 - LD)/(UD - LD);
                RMSD1_2_matrix(i,:) = ones(length(shat2),1)/(UD - LD);
                RMSD2_2_matrix(i,:) = zeros(length(shat2),1);

            else
                RMS_2_matrix(i,:) = ((shat2 - LD)/(UD - LD)).^i;
                RMSD1_2_matrix(i,:) = (i/(UD - LD))*((shat2 - LD)/(UD - LD)).^(i-1);
                RMSD2_2_matrix(i,:) = (i/(UD - LD)^2)*(i-1)*((shat2 - LD)/(UD - LD)).^(i-2);
            end
        end
        %Third domain
        RMS_3_matrix = zeros(Nas,length(shat3));
        RMSD1_3_matrix = zeros(Nas,length(shat3));
        RMSD2_3_matrix = zeros(Nas,length(shat3));
        for i = 1:Nas
            if i == 1   
                RMS_3_matrix(i,:) = (shat3 - UD)/(1 - UD);
                RMSD1_3_matrix(i,:) = ones(length(shat3),1)/(1 - UD);
                RMSD2_3_matrix(i,:) = zeros(length(shat3),1);

            else
                RMS_3_matrix(i,:) = ((shat3 - UD)/(1 - UD)).^i;
                RMSD1_3_matrix(i,:) = (i/(1 - UD))*((shat3 - UD)/(1 - UD)).^(i-1);
                RMSD2_3_matrix(i,:) = (i/(1 - UD)^2)*(i-1)*((shat3 - UD)/(1 - UD)).^(i-2);
            end
        end
    end
    toc 
end